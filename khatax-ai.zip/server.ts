import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Modality, Type } from '@google/genai';
import dotenv from 'dotenv';
import {
  Business,
  Customer,
  Supplier,
  Transaction,
  Product,
  Property,
  Inquiry,
  AIAction,
  AuditLog,
  BusinessProfile,
  BusinessRule,
} from './src/types';

dotenv.config();

const PORT = 3000;
const app = express();
app.use(express.json({ limit: '10mb' }));

// Initialize Gemini Client
let geminiClient: GoogleGenAI | null = null;
function getGemini(): GoogleGenAI | null {
  if (!geminiClient && process.env.GEMINI_API_KEY) {
    geminiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return geminiClient;
}

// ----------------- IN-MEMORY DURABLE MULTI-BUSINESS STORE -----------------
const businesses: Business[] = [
  {
    id: 'biz_clothing_1',
    name: 'Taneer Collection',
    category: 'clothing_garments',
    description: 'Ladies and Gents premium clothing, unstiched & ready-to-wear boutique in Liberty Market.',
    currency: 'PKR',
    location: 'Gulberg III, Lahore',
    phone: '+92 300 4567890',
    ownerName: 'Umair Nasir',
    createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
    profile: {
      category: 'clothing_garments',
      categoryName: 'Clothing & Garments',
      industryTerminology: {
        product: 'Suit / Fabric / Article',
        unit: 'Pieces / Meters',
        customer: 'Walk-in / Boutique Customer',
        inventory: 'Stock in Godown & Display',
      },
      preferredUnits: ['Piece', 'Suit', 'Meter', 'Yard', 'Dozen'],
      activeModules: {
        jewellery: false,
        property: false,
        clothing: true,
        pharmacy: false,
        generalStore: false,
        electronics: false,
        inquiries: true,
        installments: false,
      },
      calculationFormulas: {
        taxRate: 0,
      },
      customMetrics: ['Total Suits Sold', 'Top Category', 'Low Stock Warning', 'Pending Boutique Orders'],
      voicePromptsSuggestion: [
        'Ayesha ko black suit medium size 3500 ka sell kiya',
        'Bilal se 10,000 payment receive hui',
        'Lawn collection ka stock check karo',
        'Fatima ki boutique inquiry kya thi?',
      ],
    },
    rules: [
      {
        id: 'rule_1',
        key: 'default_discount_limit',
        label: 'Max Discount Allowed Without Approval',
        value: 15,
        unit: '%',
        description: 'Maximum percentage discount staff can offer',
      },
      {
        id: 'rule_2',
        key: 'low_stock_threshold',
        label: 'Low Stock Alert Threshold',
        value: 5,
        unit: 'Pieces',
        description: 'Trigger low stock indicator when quantity drops below',
      },
    ],
    customFields: [
      {
        id: 'cf_1',
        key: 'fabric_type',
        label: 'Fabric Material',
        type: 'select',
        options: ['Lawn', 'Chiffon', 'Silk', 'Khaddar', 'Cotton', 'Organza'],
        required: true,
        module: 'product',
      },
      {
        id: 'cf_2',
        key: 'size',
        label: 'Size',
        type: 'select',
        options: ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'Unstitched'],
        required: true,
        module: 'product',
      },
    ],
  },
  {
    id: 'biz_jewellery_2',
    name: 'Al-Makkah Jewellers',
    category: 'jewellery_gold',
    description: 'Certified 21K & 22K Gold Jewellery, bridal sets, silver ornaments and gold exchange.',
    currency: 'PKR',
    location: 'Sarafa Bazaar, Karachi',
    phone: '+92 321 9876543',
    ownerName: 'Haji Muhammad Hamza',
    createdAt: new Date(Date.now() - 60 * 86400000).toISOString(),
    profile: {
      category: 'jewellery_gold',
      categoryName: 'Gold & Silver Jewellery',
      industryTerminology: {
        weight: 'Tola / Gram / Ratti / Masha',
        purity: 'Karat (24K, 22K, 21K, 18K)',
        rate: 'Sarafa Live Rate',
        wastage: 'Kanta / Kat / Wastage %',
        making: 'Banwai / Making Charges',
      },
      preferredUnits: ['Tola', 'Gram', 'Ratti', 'Masha'],
      activeModules: {
        jewellery: true,
        property: false,
        clothing: false,
        pharmacy: false,
        generalStore: false,
        electronics: false,
        inquiries: true,
        installments: false,
      },
      calculationFormulas: {
        goldValueFormula: '((weight_in_tola * rate_per_tola) + making_charges + (weight_in_tola * rate_per_tola * wastage_pct / 100))',
        makingChargesType: 'per_gram',
        defaultWastagePercent: 2.5,
      },
      customMetrics: ['Gold Rate (24K/22K)', 'Silver Rate', 'Total Gold Weight In Stock', 'Total Gold Receivable'],
      voicePromptsSuggestion: [
        'Ali ko 2 tola 22 karat gold ka set 450000 mein diya hai',
        'Ahmed ne 500 gram silver li hai',
        'Sarafa market ka gold rate update karo',
        'Zainab bibi ka gold balance kitna hai?',
      ],
    },
    rules: [
      {
        id: 'rule_g1',
        key: 'tola_in_grams',
        label: '1 Tola Weight Conversion',
        value: 11.664,
        unit: 'grams',
        description: 'Configured standard: 1 Tola = 11.664 Grams',
      },
      {
        id: 'rule_g2',
        key: 'gold_rate_24k',
        label: 'Current 24K Gold Rate',
        value: 295000,
        unit: 'PKR / Tola',
        description: 'Live Sarafa benchmark rate for 24K Gold',
      },
      {
        id: 'rule_g3',
        key: 'gold_rate_22k',
        label: 'Current 22K Gold Rate',
        value: 270400,
        unit: 'PKR / Tola',
        description: 'Standard working rate for 22K Gold jewellery',
      },
      {
        id: 'rule_g4',
        key: 'silver_rate_tola',
        label: 'Current Silver Rate',
        value: 3450,
        unit: 'PKR / Tola',
        description: 'Sarafa benchmark rate for pure silver',
      },
    ],
    customFields: [
      {
        id: 'cf_g1',
        key: 'karat',
        label: 'Purity Karat',
        type: 'select',
        options: ['24K', '22K', '21K', '18K'],
        required: true,
        module: 'product',
      },
      {
        id: 'cf_g2',
        key: 'making_charges',
        label: 'Making Charges (Banwai)',
        type: 'number',
        required: true,
        module: 'transaction',
      },
    ],
  },
  {
    id: 'biz_property_3',
    name: 'Prime Capital Real Estate',
    category: 'property_dealer',
    description: 'Residential & Commercial plot files, constructed houses, and installment schemes.',
    currency: 'PKR',
    location: 'DHA Phase 6, Islamabad',
    phone: '+92 333 1122334',
    ownerName: 'Chaudhry Kamran',
    createdAt: new Date(Date.now() - 90 * 86400000).toISOString(),
    profile: {
      category: 'property_dealer',
      categoryName: 'Property Dealer & Real Estate',
      industryTerminology: {
        property: 'Plot / House / Commercial File',
        unit: 'Marla / Kanal / SqFt / Acre',
        status: 'Available / Booked / Transferred',
        deal: 'Biyana / Token / Full Payment',
      },
      preferredUnits: ['Marla', 'Kanal', 'SqFt', 'Square Yard', 'Acre'],
      activeModules: {
        jewellery: false,
        property: true,
        clothing: false,
        pharmacy: false,
        generalStore: false,
        electronics: false,
        inquiries: true,
        installments: true,
      },
      calculationFormulas: {
        propertyMarlaRateFormula: 'size_in_marla * rate_per_marla',
      },
      customMetrics: ['Total Active Listings', 'Available Plots', 'Installments Due This Month', 'Total Portfolio Value'],
      voicePromptsSuggestion: [
        '10 marla ka plot Block A mein available hai',
        'Ali ne Block B ka 5 marla plot 85 lakh mein book kiya',
        'Ahmed ki 3 installments pending hain check karo',
        'DHA Phase 7 mein 1 kanal house search karo',
      ],
    },
    rules: [
      {
        id: 'rule_p1',
        key: 'sqft_in_marla',
        label: '1 Marla Area Conversion',
        value: 225,
        unit: 'sq. ft',
        description: 'Standard Marla definition in modern societies (225 sqft)',
      },
      {
        id: 'rule_p2',
        key: 'marla_in_kanal',
        label: '1 Kanal Marla Count',
        value: 20,
        unit: 'marlas',
        description: '1 Kanal = 20 Marlas',
      },
    ],
    customFields: [
      {
        id: 'cf_p1',
        key: 'society_name',
        label: 'Society / Project',
        type: 'text',
        required: true,
        module: 'property',
      },
      {
        id: 'cf_p2',
        key: 'block',
        label: 'Sector / Block',
        type: 'text',
        required: true,
        module: 'property',
      },
    ],
  },
];

const customers: Customer[] = [
  // Taneer Collection
  {
    id: 'cust_c1',
    businessId: 'biz_clothing_1',
    name: 'Ayesha Tariq',
    phone: '+92 301 5551234',
    email: 'ayesha.tariq@gmail.com',
    address: 'House 42, Model Town, Lahore',
    balance: 8500, // owes us
    creditLimit: 50000,
    totalPurchased: 45000,
    totalPaid: 36500,
    transactionCount: 7,
    tags: ['VIP', 'Regular', 'Boutique Client'],
    notes: 'Prefers pure silk and medium size unstitched articles.',
    lastTransactionDate: new Date(Date.now() - 2 * 86400000).toISOString(),
    createdAt: new Date(Date.now() - 40 * 86400000).toISOString(),
  },
  {
    id: 'cust_c2',
    businessId: 'biz_clothing_1',
    name: 'Bilal Hassan',
    phone: '+92 302 9998877',
    address: 'Cavallery Ground, Lahore Cantt',
    balance: 0,
    creditLimit: 30000,
    totalPurchased: 28000,
    totalPaid: 28000,
    transactionCount: 4,
    tags: ['Prompt Payer'],
    notes: 'Buys men kurta collection every Eid.',
    lastTransactionDate: new Date(Date.now() - 6 * 86400000).toISOString(),
    createdAt: new Date(Date.now() - 50 * 86400000).toISOString(),
  },
  {
    id: 'cust_c3',
    businessId: 'biz_clothing_1',
    name: 'Fatima Zahra',
    phone: '+92 303 7776655',
    address: 'Johar Town, Lahore',
    balance: 14200,
    creditLimit: 25000,
    totalPurchased: 34200,
    totalPaid: 20000,
    transactionCount: 5,
    tags: ['Pending Balance', 'Bridal Inquirer'],
    notes: 'Inquired about 3 bridal formal dresses.',
    lastTransactionDate: new Date(Date.now() - 10 * 86400000).toISOString(),
    createdAt: new Date(Date.now() - 60 * 86400000).toISOString(),
  },
  // Al-Makkah Jewellers
  {
    id: 'cust_j1',
    businessId: 'biz_jewellery_2',
    name: 'Ali Khan',
    phone: '+92 321 4443322',
    address: 'Clifton Block 4, Karachi',
    balance: 18500, // Rs 18,500 pending
    goldBalanceWeight: 1.5, // 1.5 tola deposit
    creditLimit: 500000,
    totalPurchased: 850000,
    totalPaid: 831500,
    transactionCount: 8,
    tags: ['VIP Gold Client', 'Gold Depositor'],
    notes: 'Family jeweller client for 5 years.',
    lastTransactionDate: new Date(Date.now() - 1 * 86400000).toISOString(),
    createdAt: new Date(Date.now() - 120 * 86400000).toISOString(),
  },
  {
    id: 'cust_j2',
    businessId: 'biz_jewellery_2',
    name: 'Ahmed Raza',
    phone: '+92 322 1112233',
    address: 'PECHS Block 2, Karachi',
    balance: 45000,
    creditLimit: 200000,
    totalPurchased: 245000,
    totalPaid: 200000,
    transactionCount: 3,
    tags: ['Silver Specialist'],
    notes: 'Purchases 500g - 1kg silver bars regularly.',
    lastTransactionDate: new Date(Date.now() - 4 * 86400000).toISOString(),
    createdAt: new Date(Date.now() - 45 * 86400000).toISOString(),
  },
  // Prime Capital Real Estate
  {
    id: 'cust_p1',
    businessId: 'biz_property_3',
    name: 'Ali Raza Chaudhry',
    phone: '+92 333 5558899',
    address: 'F-10/2, Islamabad',
    balance: 1500000, // 15 Lakhs installment pending
    creditLimit: 10000000,
    totalPurchased: 8500000,
    totalPaid: 7000000,
    transactionCount: 5,
    tags: ['Plot Investor', 'DHA Buyer'],
    notes: 'Booked 5 Marla Plot in Block B, paying installments.',
    lastTransactionDate: new Date(Date.now() - 3 * 86400000).toISOString(),
    createdAt: new Date(Date.now() - 70 * 86400000).toISOString(),
  },
  {
    id: 'cust_p2',
    businessId: 'biz_property_3',
    name: 'Ahmed Sheikh',
    phone: '+92 334 7772211',
    address: 'Bahria Town Phase 7, Rawalpindi',
    balance: 0,
    creditLimit: 50000000,
    totalPurchased: 22000000,
    totalPaid: 22000000,
    transactionCount: 2,
    tags: ['High Net Worth', 'House Seeker'],
    notes: 'Inquired for 10 Marla Luxury House in Block A with 2 Crore budget.',
    lastTransactionDate: new Date(Date.now() - 8 * 86400000).toISOString(),
    createdAt: new Date(Date.now() - 25 * 86400000).toISOString(),
  },
];

const suppliers: Supplier[] = [
  {
    id: 'supp_1',
    businessId: 'biz_clothing_1',
    name: 'Kohinoor Textile Mills',
    phone: '+92 42 111 786 000',
    company: 'Kohinoor Textiles Ltd',
    address: 'Multan Road, Lahore',
    balance: 85000, // payable to mill
    totalPurchased: 350000,
    totalPaid: 265000,
    notes: 'Wholesale pure lawn & cambric cotton supplier.',
    lastPurchaseDate: new Date(Date.now() - 7 * 86400000).toISOString(),
    createdAt: new Date(Date.now() - 90 * 86400000).toISOString(),
  },
  {
    id: 'supp_2',
    businessId: 'biz_jewellery_2',
    name: 'Bismillah Bullion Dealers',
    phone: '+92 21 3241 0000',
    company: 'Bismillah Bullion Karachi',
    address: 'Sarafa Bazaar, Karachi',
    balance: 150000,
    totalPurchased: 4500000,
    totalPaid: 4350000,
    notes: 'Certified 999.9 24K Swiss & ARY Gold Bar suppliers.',
    lastPurchaseDate: new Date(Date.now() - 5 * 86400000).toISOString(),
    createdAt: new Date(Date.now() - 100 * 86400000).toISOString(),
  },
];

const products: Product[] = [
  // Clothing
  {
    id: 'prod_c1',
    businessId: 'biz_clothing_1',
    name: 'Midnight Black Embroidered Suit',
    sku: 'TC-BLK-001',
    category: 'Formal Wear',
    brand: 'Taneer Luxury',
    purchasePrice: 2200,
    salePrice: 3500,
    stock: 18,
    minStockAlert: 5,
    unit: 'Piece',
    size: 'M',
    color: 'Black',
    fabric: 'Pure Lawn / Chiffon Dupatta',
    notes: 'Best seller article of Spring Collection.',
    createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
  },
  {
    id: 'prod_c2',
    businessId: 'biz_clothing_1',
    name: 'Royal Emerald Green 3-Piece',
    sku: 'TC-GRN-002',
    category: 'Party Wear',
    brand: 'Taneer Exclusive',
    purchasePrice: 3100,
    salePrice: 5200,
    stock: 8,
    minStockAlert: 4,
    unit: 'Piece',
    size: 'L',
    color: 'Emerald Green',
    fabric: 'Raw Silk',
    notes: 'Includes handwork crystal embroidery.',
    createdAt: new Date(Date.now() - 25 * 86400000).toISOString(),
  },
  {
    id: 'prod_c3',
    businessId: 'biz_clothing_1',
    name: 'Pearl White Gents Kurta',
    sku: 'TC-MEN-003',
    category: 'Mens Kurta',
    brand: 'Taneer Men',
    purchasePrice: 1600,
    salePrice: 2800,
    stock: 24,
    minStockAlert: 6,
    unit: 'Piece',
    size: 'XL',
    color: 'White',
    fabric: 'Egyptian Cotton',
    notes: 'Premium soft finish cotton.',
    createdAt: new Date(Date.now() - 20 * 86400000).toISOString(),
  },
  // Jewellery
  {
    id: 'prod_j1',
    businessId: 'biz_jewellery_2',
    name: '22K Bridal Gold Necklace Set',
    sku: 'AMJ-GLD-SET-01',
    category: 'Bridal Sets',
    purchasePrice: 380000,
    salePrice: 450000,
    stock: 4,
    minStockAlert: 2,
    unit: 'Set',
    metalType: 'gold',
    purity: '22K',
    weight: 2, // 2 Tolas
    notes: 'Traditional Kundan and Meenakari craftsmanship.',
    createdAt: new Date(Date.now() - 40 * 86400000).toISOString(),
  },
  {
    id: 'prod_j2',
    businessId: 'biz_jewellery_2',
    name: '21K Gold Bangles (Pair)',
    sku: 'AMJ-BNG-02',
    category: 'Bangles',
    purchasePrice: 240000,
    salePrice: 285000,
    stock: 6,
    minStockAlert: 2,
    unit: 'Pair',
    metalType: 'gold',
    purity: '21K',
    weight: 1.25, // 1.25 Tolas
    notes: 'Solid handcrafted 21 karat design.',
    createdAt: new Date(Date.now() - 35 * 86400000).toISOString(),
  },
  {
    id: 'prod_j3',
    businessId: 'biz_jewellery_2',
    name: '999 Fine Silver Bar 500g',
    sku: 'AMJ-SLV-500',
    category: 'Silver Bullion',
    purchasePrice: 135000,
    salePrice: 152000,
    stock: 12,
    minStockAlert: 3,
    unit: 'Bar',
    metalType: 'silver',
    purity: '999',
    weight: 500, // 500 Grams
    notes: 'Hallmarked 99.9% fine silver bullion cast.',
    createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
  },
];

const properties: Property[] = [
  {
    id: 'prop_1',
    businessId: 'biz_property_3',
    propertyIdCode: 'PRIME-BLK-A-10M',
    type: 'plot',
    location: 'Sector C, Main Boulevard',
    society: 'DHA Islamabad Phase 2',
    block: 'Block A',
    plotNumber: 'Plot #142',
    size: 10,
    unit: 'marla',
    askingPrice: 17500000, // 1.75 Crore
    purchasePrice: 15000000,
    ownerName: 'Col. (R) Tariq Mahmood',
    ownerPhone: '+92 300 8877665',
    status: 'AVAILABLE',
    documentationStatus: 'COMPLETE',
    features: ['Direct access to 100ft road', 'Near Commercial Hub', 'Possession Paid'],
    notes: 'Ready for immediate registry & construction.',
    createdAt: new Date(Date.now() - 15 * 86400000).toISOString(),
  },
  {
    id: 'prop_2',
    businessId: 'biz_property_3',
    propertyIdCode: 'PRIME-BLK-B-5M',
    type: 'plot',
    location: 'Park Avenue Sector',
    society: 'Bahria Town Phase 8',
    block: 'Block B',
    plotNumber: 'Plot #88',
    size: 5,
    unit: 'marla',
    askingPrice: 8500000, // 85 Lakhs
    salePrice: 8500000,
    ownerName: 'Malik Jahangir',
    buyerName: 'Ali Raza Chaudhry',
    buyerPhone: '+92 333 5558899',
    status: 'RESERVED',
    installmentPlan: {
      totalInstallments: 6,
      installmentAmount: 500000,
      paidInstallments: 3,
      pendingInstallments: 3,
      nextDueDate: new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0],
    },
    documentationStatus: 'IN_PROCESS',
    features: ['Facing Central Park', 'Underground Utilities', 'Sui Gas Approved'],
    notes: 'Booked with 70 Lakh down payment; 3 installments pending.',
    createdAt: new Date(Date.now() - 60 * 86400000).toISOString(),
  },
  {
    id: 'prop_3',
    businessId: 'biz_property_3',
    propertyIdCode: 'PRIME-BLK-A-HOUSE',
    type: 'house',
    location: 'Sector A-1 Street 5',
    society: 'DHA Phase 6',
    block: 'Block A',
    plotNumber: 'House #12-A',
    size: 10,
    unit: 'marla',
    askingPrice: 20000000, // 2.0 Crore
    ownerName: 'Dr. Shahzad Anjum',
    ownerPhone: '+92 321 4455667',
    status: 'AVAILABLE',
    documentationStatus: 'COMPLETE',
    features: ['5 Master Bedrooms', 'Imported Kitchen fittings', 'Solar 10kW Installed'],
    notes: 'Brand new luxury designer bungalow.',
    createdAt: new Date(Date.now() - 10 * 86400000).toISOString(),
  },
];

const inquiries: Inquiry[] = [
  {
    id: 'inq_1',
    businessId: 'biz_clothing_1',
    customerName: 'Fatima Zahra',
    customerPhone: '+92 303 7776655',
    customerId: 'cust_c3',
    requirement: '3 Bridal Raw Silk Suits with Heavy Handwork & Matching Shawls',
    productOrPropertyCategory: 'Bridal Couture',
    budget: 85000,
    quantityOrSize: '3 Suits (M, L)',
    followUpDate: new Date(Date.now() + 2 * 86400000).toISOString().split('T')[0],
    status: 'FOLLOW_UP',
    source: 'WALK_IN',
    notes: 'Requires delivery before 15th next month. Samples shown.',
    assignedPerson: 'Umair Nasir',
    createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
  },
  {
    id: 'inq_2',
    businessId: 'biz_jewellery_2',
    customerName: 'Zainab Bibi',
    customerPhone: '+92 333 4411223',
    requirement: 'Custom 22K Gold Bridal Choker & Jhumka Set with Ruby stones',
    productOrPropertyCategory: 'Gold Bridal Set',
    budget: 650000,
    quantityOrSize: '3.5 Tola Gold',
    followUpDate: new Date(Date.now() + 1 * 86400000).toISOString().split('T')[0],
    status: 'NEW',
    source: 'VOICE_ASSISTANT',
    notes: 'Customer deposited design photo on WhatsApp. Needs quote with 2.5% wastage rule.',
    assignedPerson: 'Haji Hamza',
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
  },
  {
    id: 'inq_3',
    businessId: 'biz_property_3',
    customerName: 'Ahmed Sheikh',
    customerPhone: '+92 334 7772211',
    customerId: 'cust_p2',
    requirement: '10 Marla Brand New Modern House in Block A or B',
    productOrPropertyCategory: 'Luxury House',
    budget: 20000000, // 2 Crore
    quantityOrSize: '10 Marla House',
    followUpDate: new Date(Date.now() + 1 * 86400000).toISOString().split('T')[0],
    status: 'FOLLOW_UP',
    source: 'VOICE_ASSISTANT',
    notes: 'Customer strictly wants 10 marla with 5 bedrooms and modern Spanish elevation. Follow-up scheduled for tomorrow.',
    assignedPerson: 'Chaudhry Kamran',
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
  },
];

const transactions: Transaction[] = [
  // Clothing
  {
    id: 'tx_c1',
    businessId: 'biz_clothing_1',
    invoiceNumber: 'INV-2026-0081',
    type: 'sale',
    customerId: 'cust_c1',
    customerName: 'Ayesha Tariq',
    amount: 3500,
    paymentMethod: 'cash',
    status: 'completed',
    items: [
      {
        id: 'item_1',
        name: 'Midnight Black Embroidered Suit (M)',
        quantity: 1,
        unit: 'Piece',
        unitPrice: 3500,
        subtotal: 3500,
        clothingDetails: {
          size: 'M',
          color: 'Black',
          fabric: 'Pure Lawn',
        },
      },
    ],
    notes: 'Sale recorded via Xara Voice Assistant',
    date: new Date(Date.now() - 2 * 86400000).toISOString(),
    createdSource: 'AI_VOICE',
    calculatedBreakdown: {
      total: 3500,
      previousBalance: 5000,
      newBalance: 8500,
    },
  },
  {
    id: 'tx_c2',
    businessId: 'biz_clothing_1',
    invoiceNumber: 'INV-2026-0082',
    type: 'payment_received',
    customerId: 'cust_c2',
    customerName: 'Bilal Hassan',
    amount: 10000,
    paymentMethod: 'bank_transfer',
    status: 'completed',
    items: [],
    notes: 'Bank Alfalah online transfer received against previous ledger credit.',
    date: new Date(Date.now() - 6 * 86400000).toISOString(),
    createdSource: 'MANUAL',
    calculatedBreakdown: {
      total: 10000,
      previousBalance: 10000,
      newBalance: 0,
    },
  },
  // Jewellery
  {
    id: 'tx_j1',
    businessId: 'biz_jewellery_2',
    invoiceNumber: 'GLD-2026-0104',
    type: 'sale',
    customerId: 'cust_j1',
    customerName: 'Ali Khan',
    amount: 450000,
    paymentMethod: 'cash',
    status: 'completed',
    items: [
      {
        id: 'item_j1',
        name: '22K Gold Bridal Necklace Set (2 Tola)',
        quantity: 1,
        unit: 'Set',
        unitPrice: 450000,
        subtotal: 450000,
        jewelleryDetails: {
          metalType: 'gold',
          weight: 2,
          unit: 'tola',
          purity: '22K',
          ratePerUnit: 220000,
          makingCharges: 8000,
          wastagePercent: 2.5,
          netWeightGrams: 23.328,
        },
      },
    ],
    notes: 'Ali ko 2 tola 22 karat gold ka set 450000 mein diya hai. Confirmed via Xara voice.',
    date: new Date(Date.now() - 1 * 86400000).toISOString(),
    createdSource: 'AI_VOICE',
    calculatedBreakdown: {
      rawPrice: 440000,
      makingCharges: 8000,
      wastageAmount: 2000,
      total: 450000,
      previousBalance: 0,
      newBalance: 18500,
    },
  },
  {
    id: 'tx_j2',
    businessId: 'biz_jewellery_2',
    invoiceNumber: 'SLV-2026-0105',
    type: 'sale',
    customerId: 'cust_j2',
    customerName: 'Ahmed Raza',
    amount: 152000,
    paymentMethod: 'credit',
    status: 'completed',
    items: [
      {
        id: 'item_j2',
        name: '999 Fine Silver Bar (500g)',
        quantity: 1,
        unit: 'Bar',
        unitPrice: 152000,
        subtotal: 152000,
        jewelleryDetails: {
          metalType: 'silver',
          weight: 500,
          unit: 'gram',
          purity: '999',
          ratePerUnit: 304,
          makingCharges: 0,
          wastagePercent: 0,
        },
      },
    ],
    notes: 'Ahmed ne 500 gram silver li hai. Udhar khata entry.',
    date: new Date(Date.now() - 4 * 86400000).toISOString(),
    createdSource: 'AI_VOICE',
    calculatedBreakdown: {
      total: 152000,
      previousBalance: 0,
      newBalance: 45000,
    },
  },
  // Property
  {
    id: 'tx_p1',
    businessId: 'biz_property_3',
    invoiceNumber: 'PROP-2026-0012',
    type: 'sale',
    customerId: 'cust_p1',
    customerName: 'Ali Raza Chaudhry',
    amount: 8500000,
    paymentMethod: 'bank_transfer',
    status: 'completed',
    items: [
      {
        id: 'item_p1',
        name: '5 Marla Plot Block B Bahria Town',
        quantity: 1,
        unit: 'Plot',
        unitPrice: 8500000,
        subtotal: 8500000,
        propertyDetails: {
          propertyIdCode: 'PRIME-BLK-B-5M',
          propertyType: 'plot',
          society: 'Bahria Town Phase 8',
          block: 'Block B',
          size: 5,
          unit: 'marla',
        },
      },
    ],
    notes: 'Ali ne Block B ka 5 marla plot 85 lakh mein book kiya hai. Down payment 70 Lakh received.',
    date: new Date(Date.now() - 3 * 86400000).toISOString(),
    createdSource: 'AI_VOICE',
    calculatedBreakdown: {
      total: 8500000,
      previousBalance: 0,
      newBalance: 1500000,
    },
  },
];

const auditLogs: AuditLog[] = [
  {
    id: 'log_1',
    businessId: 'biz_clothing_1',
    action: 'CREATE_SALE',
    tool: 'create_sale',
    inputSummary: 'Voice prompt: "Ayesha ko black suit medium size 3500 ka sell kiya"',
    resultSummary: 'Created Invoice INV-2026-0081, amount Rs. 3,500, updated Ayesha balance to Rs. 8,500',
    timestamp: new Date(Date.now() - 2 * 86400000).toISOString(),
    source: 'AI_VOICE',
    user: 'Umair Nasir',
  },
  {
    id: 'log_2',
    businessId: 'biz_jewellery_2',
    action: 'CREATE_SALE',
    tool: 'create_sale',
    inputSummary: 'Voice prompt: "Ali ko 2 tola 22 karat gold ka set 450000 mein diya hai"',
    resultSummary: 'Calculated 2 Tola 22K (Making: Rs. 8000, Wastage: 2.5%), Created GLD-2026-0104',
    timestamp: new Date(Date.now() - 1 * 86400000).toISOString(),
    source: 'AI_VOICE',
    user: 'Haji Hamza',
  },
  {
    id: 'log_3',
    businessId: 'biz_property_3',
    action: 'BOOK_PROPERTY',
    tool: 'create_property_transaction',
    inputSummary: 'Voice prompt: "Ali ne Block B ka 5 marla plot 85 lakh mein book kiya hai"',
    resultSummary: 'Reserved plot PRIME-BLK-B-5M for Ali Raza Chaudhry, created installment schedule',
    timestamp: new Date(Date.now() - 3 * 86400000).toISOString(),
    source: 'AI_VOICE',
    user: 'Chaudhry Kamran',
  },
];

// Helper to get business by ID
function findBusiness(id: string): Business {
  const b = businesses.find((x) => x.id === id);
  if (!b) return businesses[0];
  return b;
}

// ----------------- REST API ROUTES -----------------

// 1. Businesses
app.get('/api/businesses', (req, res) => {
  res.json({ success: true, data: businesses });
});

app.get('/api/businesses/:id', (req, res) => {
  const b = businesses.find((x) => x.id === req.params.id);
  if (!b) return res.status(404).json({ success: false, error: 'Business not found' });
  res.json({ success: true, data: b });
});

// Update business rules
app.put('/api/businesses/:id/rules', (req, res) => {
  const b = businesses.find((x) => x.id === req.params.id);
  if (!b) return res.status(404).json({ success: false, error: 'Business not found' });
  const { rules } = req.body;
  if (Array.isArray(rules)) {
    b.rules = rules;
  }
  res.json({ success: true, data: b });
});

// AI Business Profiler Engine: Natural Language Description -> Tailored Workspace
app.post('/api/businesses/analyze-description', async (req, res) => {
  try {
    const { description, category, businessName } = req.body;
    const ai = getGemini();

    if (ai) {
      const prompt = `You are KhataX AI's Business Profiling Engine.
Analyze the user's business description:
Business Name: "${businessName || 'My Business'}"
Category: "${category || 'other'}"
User Description: "${description}"

Generate a JSON object strictly matching this schema:
{
  "category": "jewellery_gold" | "silver" | "property_dealer" | "real_estate" | "clothing_garments" | "general_store" | "pharmacy" | "electronics" | "mobile_shop" | "hardware" | "auto_parts" | "wholesale" | "restaurant" | "cosmetics" | "furniture" | "construction" | "services" | "freelancer" | "other",
  "categoryName": "Friendly Category Title (e.g. Construction & Building Materials)",
  "industryTerminology": {
    "product": "What items are called (e.g. Bricks / Cement Bags / Iron Rods)",
    "unit": "Measurement unit (e.g. Bags / Tons / SqFt)",
    "customer": "Customer terminology (e.g. Builder / Contractor / Homeowner)",
    "inventory": "Inventory terminology (e.g. Warehouse Yard)"
  },
  "preferredUnits": ["Array", "of", "standard", "units", "like", "Bag", "Ton", "Piece"],
  "activeModules": {
    "jewellery": boolean,
    "property": boolean,
    "clothing": boolean,
    "pharmacy": boolean,
    "generalStore": boolean,
    "electronics": boolean,
    "inquiries": true,
    "installments": boolean
  },
  "calculationFormulas": {
    "goldValueFormula": string,
    "propertyMarlaRateFormula": string,
    "taxRate": number
  },
  "customMetrics": ["Array of 4 key dashboard metrics (e.g. Total Bags Sold, Pending Contractor Payments)"],
  "suggestedRules": [
    {
      "key": "rule_key",
      "label": "Human readable rule name",
      "value": number or string,
      "unit": "unit string",
      "description": "Why this rule is used"
    }
  ],
  "suggestedFields": [
    {
      "key": "field_key",
      "label": "Field Name",
      "type": "text" | "number" | "select",
      "options": ["optional", "list"],
      "required": boolean,
      "module": "product" | "transaction" | "customer"
    }
  ],
  "voicePromptsSuggestion": [
    "3 realistic voice commands in Urdu/Roman Urdu matching this business"
  ],
  "xaraGreeting": "A warm customized greeting in Roman Urdu from Xara explaining how she adapted the workspace."
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.3,
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      return res.json({ success: true, data: parsed });
    }

    // Smart fallback if AI key not configured
    const descLower = (description || '').toLowerCase();
    let detectedCategory = category || 'other';
    let catName = 'Custom Business';
    let units = ['Piece', 'Kg', 'Pack', 'Item'];
    let term = { product: 'Product / Item', unit: 'Unit', customer: 'Customer', inventory: 'Stock' };
    let metrics = ['Total Sales', 'Total Receivables', 'Stock Remaining', 'Active Customers'];
    let rules: BusinessRule[] = [];
    let customFields = [];

    if (descLower.includes('gold') || descLower.includes('jewel') || descLower.includes('chandi') || descLower.includes('tola')) {
      detectedCategory = 'jewellery_gold';
      catName = 'Gold & Silver Jewellery';
      units = ['Tola', 'Gram', 'Ratti', 'Masha'];
      term = { product: 'Jewellery Article', unit: 'Tola/Gram', customer: 'Gold Customer', inventory: 'Sarafa Vault' };
      metrics = ['Gold Rate (24K)', 'Total Gold Weight', 'Total Receivable', 'Daily Gold Sales'];
      rules = [
        { id: 'r1', key: 'tola_in_grams', label: '1 Tola Weight', value: 11.664, unit: 'grams', description: 'Standard Tola conversion' },
        { id: 'r2', key: 'gold_rate_24k', label: '24K Gold Rate', value: 295000, unit: 'PKR/Tola', description: 'Sarafa Rate' },
      ];
    } else if (descLower.includes('property') || descLower.includes('plot') || descLower.includes('house') || descLower.includes('marla')) {
      detectedCategory = 'property_dealer';
      catName = 'Property Dealer & Real Estate';
      units = ['Marla', 'Kanal', 'SqFt', 'Square Yard'];
      term = { product: 'Plot / House File', unit: 'Marla/Kanal', customer: 'Investor / Buyer', inventory: 'Property Portfolio' };
      metrics = ['Active Listings', 'Available Plots', 'Pending Installments', 'Total Portfolio Value'];
      rules = [
        { id: 'rp1', key: 'sqft_in_marla', label: '1 Marla Area', value: 225, unit: 'sq. ft', description: 'Society standard' },
      ];
    } else if (descLower.includes('cloth') || descLower.includes('suit') || descLower.includes('fabric') || descLower.includes('garment')) {
      detectedCategory = 'clothing_garments';
      catName = 'Clothing & Garments';
      units = ['Piece', 'Suit', 'Meter', 'Yard'];
      term = { product: 'Suit / Article', unit: 'Pieces', customer: 'Boutique Client', inventory: 'Display & Godown' };
      metrics = ['Suits Sold Today', 'Top Category', 'Low Stock Alert', 'Customer Receivables'];
    } else if (descLower.includes('cement') || descLower.includes('steel') || descLower.includes('brick') || descLower.includes('construction')) {
      detectedCategory = 'construction';
      catName = 'Construction & Building Materials';
      units = ['Bag', 'Ton', 'Truck', 'SqFt', 'Number'];
      term = { product: 'Material (Cement/Steel/Bricks)', unit: 'Bag/Ton', customer: 'Contractor / Builder', inventory: 'Material Yard' };
      metrics = ['Bags Delivered', 'Steel Stock (Tons)', 'Contractor Receivables', 'Active Site Inquiries'];
      rules = [
        { id: 'rc1', key: 'cement_bag_weight', label: 'Cement Bag Standard Weight', value: 50, unit: 'kg', description: 'Standard 50kg bag' },
      ];
      customFields = [
        { id: 'cf_c1', key: 'site_location', label: 'Construction Site Address', type: 'text' as const, required: true, module: 'transaction' as const },
      ];
    }

    res.json({
      success: true,
      data: {
        category: detectedCategory,
        categoryName: catName,
        industryTerminology: term,
        preferredUnits: units,
        activeModules: {
          jewellery: detectedCategory === 'jewellery_gold' || detectedCategory === 'silver',
          property: detectedCategory === 'property_dealer' || detectedCategory === 'real_estate',
          clothing: detectedCategory === 'clothing_garments',
          pharmacy: detectedCategory === 'pharmacy',
          generalStore: detectedCategory === 'general_store',
          electronics: detectedCategory === 'electronics' || detectedCategory === 'mobile_shop',
          inquiries: true,
          installments: detectedCategory === 'property_dealer' || detectedCategory === 'real_estate',
        },
        calculationFormulas: {},
        customMetrics: metrics,
        suggestedRules: rules,
        suggestedFields: customFields,
        voicePromptsSuggestion: [
          'Ali se payment receive hui 5000',
          'Naye customer ka account create karo',
          'Stock check karo',
        ],
        xaraGreeting: `Samajh gaya! Maine aapke business (${catName}) ke hisaab se KhataX AI workspace mukammal configure kar diya hai.`,
      },
    });
  } catch (err: any) {
    console.error('Error analyzing business description:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Create new business
app.post('/api/businesses', (req, res) => {
  const { name, category, description, currency, location, phone, ownerName, profile, rules, customFields } = req.body;
  const newBiz: Business = {
    id: `biz_${Date.now()}`,
    name: name || 'My Khata Business',
    category: category || 'other',
    description: description || '',
    currency: currency || 'PKR',
    location: location || 'Pakistan',
    phone: phone || '',
    ownerName: ownerName || 'Business Owner',
    createdAt: new Date().toISOString(),
    profile: profile || {
      category: category || 'other',
      categoryName: 'General Business',
      industryTerminology: { product: 'Item', unit: 'Unit', customer: 'Customer', inventory: 'Stock' },
      preferredUnits: ['Piece', 'Item', 'Kg'],
      activeModules: { jewellery: false, property: false, clothing: false, pharmacy: false, generalStore: true, electronics: false, inquiries: true, installments: false },
      calculationFormulas: {},
      customMetrics: ['Total Sales', 'Receivables', 'Payables', 'Stock'],
      voicePromptsSuggestion: ['Payment receive karo', 'Naya customer add karo'],
    },
    rules: rules || [],
    customFields: customFields || [],
  };

  businesses.push(newBiz);

  // Add default welcome customer
  customers.push({
    id: `cust_${Date.now()}`,
    businessId: newBiz.id,
    name: 'Walk-in Customer',
    phone: '+92 300 0000000',
    balance: 0,
    creditLimit: 10000,
    totalPurchased: 0,
    totalPaid: 0,
    transactionCount: 0,
    tags: ['Cash Client'],
    createdAt: new Date().toISOString(),
  });

  auditLogs.unshift({
    id: `log_${Date.now()}`,
    businessId: newBiz.id,
    action: 'CREATE_BUSINESS',
    tool: 'create_business',
    inputSummary: `Created business: ${newBiz.name} (${newBiz.profile.categoryName})`,
    resultSummary: 'Initialized workspace with customized terminology, rules, and AI memory.',
    timestamp: new Date().toISOString(),
    source: 'WEB',
    user: newBiz.ownerName,
  });

  res.json({ success: true, data: newBiz });
});

// 2. Customers
app.get('/api/customers', (req, res) => {
  const businessId = req.query.businessId as string;
  const list = customers.filter((c) => !businessId || c.businessId === businessId);
  res.json({ success: true, data: list });
});

app.post('/api/customers', (req, res) => {
  const { businessId, name, phone, email, address, creditLimit, notes, tags } = req.body;
  if (!name || !businessId) {
    return res.status(400).json({ success: false, error: 'Name and businessId are required' });
  }

  const newCust: Customer = {
    id: `cust_${Date.now()}`,
    businessId,
    name,
    phone: phone || '',
    email: email || '',
    address: address || '',
    balance: 0,
    creditLimit: Number(creditLimit) || 50000,
    totalPurchased: 0,
    totalPaid: 0,
    transactionCount: 0,
    tags: Array.isArray(tags) ? tags : ['New Customer'],
    notes: notes || '',
    createdAt: new Date().toISOString(),
  };

  customers.unshift(newCust);

  auditLogs.unshift({
    id: `log_${Date.now()}`,
    businessId,
    action: 'CREATE_CUSTOMER',
    tool: 'create_customer',
    inputSummary: `Added customer ${name} (${phone || 'No phone'})`,
    resultSummary: `Customer record initialized with balance Rs. 0`,
    timestamp: new Date().toISOString(),
    source: 'WEB',
    user: 'Owner',
  });

  res.json({ success: true, data: newCust });
});

app.put('/api/customers/:id', (req, res) => {
  const cust = customers.find((c) => c.id === req.params.id);
  if (!cust) return res.status(404).json({ success: false, error: 'Customer not found' });

  const { name, phone, email, address, creditLimit, notes, tags } = req.body;
  if (name) cust.name = name;
  if (phone !== undefined) cust.phone = phone;
  if (email !== undefined) cust.email = email;
  if (address !== undefined) cust.address = address;
  if (creditLimit !== undefined) cust.creditLimit = Number(creditLimit);
  if (notes !== undefined) cust.notes = notes;
  if (tags !== undefined) cust.tags = tags;

  res.json({ success: true, data: cust });
});

// Customer Intelligence Endpoint (Deep stats + AI summary)
app.get('/api/customers/:id/intelligence', async (req, res) => {
  const cust = customers.find((c) => c.id === req.params.id);
  if (!cust) return res.status(404).json({ success: false, error: 'Customer not found' });

  const custTx = transactions.filter((t) => t.customerId === cust.id || (t.customerName && t.customerName.toLowerCase() === cust.name.toLowerCase()));
  const custInquiries = inquiries.filter((i) => i.customerId === cust.id || (i.customerName && i.customerName.toLowerCase() === cust.name.toLowerCase()));
  const b = findBusiness(cust.businessId);

  // Generate intelligent AI summary
  let aiSummary = `${cust.name} is a valued customer of ${b.name}. Current outstanding balance is ${b.currency} ${cust.balance.toLocaleString()}. Total recorded transactions: ${custTx.length}.`;
  
  const ai = getGemini();
  if (ai) {
    try {
      const prompt = `You are Xara, the AI business operating assistant for "${b.name}" (${b.profile.categoryName}).
Generate a concise, friendly 2-sentence intelligence briefing in Roman Urdu & English about this customer for the shop owner.

Customer Profile:
Name: ${cust.name}
Phone: ${cust.phone || 'N/A'}
Current Balance: ${b.currency} ${cust.balance}
Total Purchased: ${b.currency} ${cust.totalPurchased}
Total Paid: ${b.currency} ${cust.totalPaid}
Transaction Count: ${custTx.length}
Recent Transactions: ${JSON.stringify(custTx.slice(0, 3).map((t) => ({ date: t.date, type: t.type, amount: t.amount, note: t.notes })))}
Open Inquiries: ${JSON.stringify(custInquiries.map((i) => ({ req: i.requirement, budget: i.budget, status: i.status })))}

Give a factual, natural summary. Example: "Ali aapka regular customer hai. Is month unhone 4 purchases ki hain aur current outstanding balance Rs. 18,500 hai."`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: prompt,
      });
      if (response.text) {
        aiSummary = response.text.trim();
      }
    } catch (e) {
      console.warn('Customer AI summary fallback:', e);
    }
  }

  res.json({
    success: true,
    data: {
      customer: cust,
      transactions: custTx,
      inquiries: custInquiries,
      aiSummary,
    },
  });
});

// 3. Suppliers
app.get('/api/suppliers', (req, res) => {
  const businessId = req.query.businessId as string;
  const list = suppliers.filter((s) => !businessId || s.businessId === businessId);
  res.json({ success: true, data: list });
});

app.post('/api/suppliers', (req, res) => {
  const { businessId, name, phone, company, address, notes } = req.body;
  if (!name || !businessId) {
    return res.status(400).json({ success: false, error: 'Name and businessId are required' });
  }

  const newSupp: Supplier = {
    id: `supp_${Date.now()}`,
    businessId,
    name,
    phone: phone || '',
    company: company || '',
    address: address || '',
    balance: 0,
    totalPurchased: 0,
    totalPaid: 0,
    notes: notes || '',
    createdAt: new Date().toISOString(),
  };

  suppliers.unshift(newSupp);
  res.json({ success: true, data: newSupp });
});

// 4. Products / Inventory
app.get('/api/products', (req, res) => {
  const businessId = req.query.businessId as string;
  const list = products.filter((p) => !businessId || p.businessId === businessId);
  res.json({ success: true, data: list });
});

app.post('/api/products', (req, res) => {
  const { businessId, name, sku, category, brand, purchasePrice, salePrice, stock, minStockAlert, unit, size, color, fabric, batchNumber, expiryDate, serialNumber, imei, warranty, metalType, purity, weight, notes } = req.body;

  const newProd: Product = {
    id: `prod_${Date.now()}`,
    businessId,
    name,
    sku: sku || `SKU-${Date.now().toString().slice(-4)}`,
    category: category || 'General',
    brand,
    purchasePrice: Number(purchasePrice) || 0,
    salePrice: Number(salePrice) || 0,
    stock: Number(stock) || 0,
    minStockAlert: Number(minStockAlert) || 2,
    unit: unit || 'Piece',
    size,
    color,
    fabric,
    batchNumber,
    expiryDate,
    serialNumber,
    imei,
    warranty,
    metalType,
    purity,
    weight: weight ? Number(weight) : undefined,
    notes,
    createdAt: new Date().toISOString(),
  };

  products.unshift(newProd);
  res.json({ success: true, data: newProd });
});

app.put('/api/products/:id', (req, res) => {
  const prod = products.find((p) => p.id === req.params.id);
  if (!prod) return res.status(404).json({ success: false, error: 'Product not found' });
  Object.assign(prod, req.body);
  res.json({ success: true, data: prod });
});

// 5. Properties
app.get('/api/properties', (req, res) => {
  const businessId = req.query.businessId as string;
  const list = properties.filter((p) => !businessId || p.businessId === businessId);
  res.json({ success: true, data: list });
});

app.post('/api/properties', (req, res) => {
  const { businessId, propertyIdCode, type, location, society, block, plotNumber, size, unit, askingPrice, purchasePrice, ownerName, ownerPhone, status, documentationStatus, features, notes } = req.body;

  const newProp: Property = {
    id: `prop_${Date.now()}`,
    businessId,
    propertyIdCode: propertyIdCode || `PROP-${block || 'BLK'}-${size || 5}M`,
    type: type || 'plot',
    location: location || '',
    society: society || 'Bahria / DHA',
    block: block || 'Block A',
    plotNumber: plotNumber || '',
    size: Number(size) || 5,
    unit: unit || 'marla',
    askingPrice: Number(askingPrice) || 0,
    purchasePrice: purchasePrice ? Number(purchasePrice) : undefined,
    ownerName: ownerName || 'Owner',
    ownerPhone,
    status: status || 'AVAILABLE',
    documentationStatus: documentationStatus || 'COMPLETE',
    features: Array.isArray(features) ? features : [],
    notes,
    createdAt: new Date().toISOString(),
  };

  properties.unshift(newProp);
  res.json({ success: true, data: newProp });
});

app.put('/api/properties/:id', (req, res) => {
  const prop = properties.find((p) => p.id === req.params.id);
  if (!prop) return res.status(404).json({ success: false, error: 'Property not found' });
  Object.assign(prop, req.body);
  res.json({ success: true, data: prop });
});

// 6. Inquiries (Smart Customer Inquiries)
app.get('/api/inquiries', (req, res) => {
  const businessId = req.query.businessId as string;
  const list = inquiries.filter((i) => !businessId || i.businessId === businessId);
  res.json({ success: true, data: list });
});

app.post('/api/inquiries', (req, res) => {
  const { businessId, customerName, customerPhone, customerId, requirement, productOrPropertyCategory, budget, quantityOrSize, followUpDate, status, source, notes, assignedPerson } = req.body;

  const newInq: Inquiry = {
    id: `inq_${Date.now()}`,
    businessId,
    customerName,
    customerPhone,
    customerId,
    requirement,
    productOrPropertyCategory,
    budget: Number(budget) || 0,
    quantityOrSize,
    followUpDate: followUpDate || new Date(Date.now() + 86400000).toISOString().split('T')[0],
    status: status || 'NEW',
    source: source || 'WALK_IN',
    notes: notes || '',
    assignedPerson,
    createdAt: new Date().toISOString(),
  };

  inquiries.unshift(newInq);

  auditLogs.unshift({
    id: `log_${Date.now()}`,
    businessId,
    action: 'CREATE_INQUIRY',
    tool: 'create_inquiry',
    inputSummary: `Inquiry by ${customerName}: "${requirement}" (Budget: ${budget || 0})`,
    resultSummary: `Recorded inquiry with follow-up on ${newInq.followUpDate}`,
    timestamp: new Date().toISOString(),
    source: 'WEB',
    user: 'Staff',
  });

  res.json({ success: true, data: newInq });
});

app.put('/api/inquiries/:id', (req, res) => {
  const inq = inquiries.find((i) => i.id === req.params.id);
  if (!inq) return res.status(404).json({ success: false, error: 'Inquiry not found' });
  Object.assign(inq, req.body);
  res.json({ success: true, data: inq });
});

// 7. Transactions & Digital Khata
app.get('/api/transactions', (req, res) => {
  const businessId = req.query.businessId as string;
  const customerId = req.query.customerId as string;
  let list = transactions.filter((t) => !businessId || t.businessId === businessId);
  if (customerId) {
    list = list.filter((t) => t.customerId === customerId);
  }
  res.json({ success: true, data: list });
});

app.post('/api/transactions', (req, res) => {
  const {
    businessId,
    type,
    customerId,
    customerName,
    supplierId,
    supplierName,
    amount,
    paymentMethod,
    items,
    notes,
    createdSource,
    calculatedBreakdown,
  } = req.body;

  const numAmount = Number(amount) || 0;
  const numInvoice = `INV-${new Date().getFullYear()}-${String(transactions.length + 101).padStart(4, '0')}`;

  let targetCustomer = customerId ? customers.find((c) => c.id === customerId) : null;
  if (!targetCustomer && customerName) {
    targetCustomer = customers.find((c) => c.businessId === businessId && c.name.toLowerCase() === customerName.toLowerCase());
  }

  let prevBal = targetCustomer ? targetCustomer.balance : 0;
  let newBal = prevBal;

  // Ledger calculation logic
  if (targetCustomer) {
    if (type === 'sale' || type === 'credit') {
      // Customer owes more
      if (paymentMethod === 'credit' || !paymentMethod || paymentMethod === 'cash') {
        // If sale with partial or credit:
        newBal = prevBal + numAmount;
      }
      targetCustomer.totalPurchased += numAmount;
      targetCustomer.transactionCount += 1;
      targetCustomer.lastTransactionDate = new Date().toISOString();
      targetCustomer.balance = newBal;
    } else if (type === 'payment_received') {
      // Customer paid off balance
      newBal = prevBal - numAmount;
      targetCustomer.totalPaid += numAmount;
      targetCustomer.transactionCount += 1;
      targetCustomer.lastTransactionDate = new Date().toISOString();
      targetCustomer.balance = newBal;
    } else if (type === 'payment_given') {
      newBal = prevBal + numAmount;
      targetCustomer.balance = newBal;
    }
  }

  // If supplier transaction
  let targetSupplier = supplierId ? suppliers.find((s) => s.id === supplierId) : null;
  if (targetSupplier) {
    if (type === 'purchase') {
      targetSupplier.balance += numAmount;
      targetSupplier.totalPurchased += numAmount;
      targetSupplier.lastPurchaseDate = new Date().toISOString();
    } else if (type === 'payment_given') {
      targetSupplier.balance -= numAmount;
      targetSupplier.totalPaid += numAmount;
    }
  }

  const newTx: Transaction = {
    id: `tx_${Date.now()}`,
    businessId,
    invoiceNumber: numInvoice,
    type: type || 'sale',
    customerId: targetCustomer?.id || customerId,
    customerName: targetCustomer?.name || customerName || 'Walk-in Customer',
    supplierId: targetSupplier?.id || supplierId,
    supplierName: targetSupplier?.name || supplierName,
    amount: numAmount,
    paymentMethod: paymentMethod || 'cash',
    status: 'completed',
    items: Array.isArray(items) ? items : [],
    notes: notes || '',
    date: new Date().toISOString(),
    createdSource: createdSource || 'MANUAL',
    calculatedBreakdown: calculatedBreakdown || {
      total: numAmount,
      previousBalance: prevBal,
      newBalance: newBal,
    },
  };

  transactions.unshift(newTx);

  // Update product inventory if items included
  if (Array.isArray(items)) {
    for (const item of items) {
      if (item.name) {
        const prod = products.find((p) => p.businessId === businessId && p.name.toLowerCase() === item.name.toLowerCase());
        if (prod) {
          if (type === 'sale') {
            prod.stock = Math.max(0, prod.stock - (item.quantity || 1));
          } else if (type === 'purchase' || type === 'return') {
            prod.stock += item.quantity || 1;
          }
        }
      }
    }
  }

  auditLogs.unshift({
    id: `log_${Date.now()}`,
    businessId,
    action: `RECORD_${type.toUpperCase()}`,
    tool: 'record_transaction',
    inputSummary: `${type.toUpperCase()}: ${numInvoice} for ${newTx.customerName || newTx.supplierName} - Rs. ${numAmount.toLocaleString()}`,
    resultSummary: `Ledger balance updated from Rs. ${prevBal.toLocaleString()} to Rs. ${newBal.toLocaleString()}`,
    timestamp: new Date().toISOString(),
    source: createdSource || 'WEB',
    user: 'User',
  });

  res.json({ success: true, data: newTx });
});

// 8. Dynamic Dashboard Summary
app.get('/api/dashboard-summary', (req, res) => {
  const businessId = req.query.businessId as string;
  const b = findBusiness(businessId);

  const bizCustomers = customers.filter((c) => c.businessId === b.id);
  const bizSuppliers = suppliers.filter((s) => s.businessId === b.id);
  const bizTx = transactions.filter((t) => t.businessId === b.id);
  const bizProducts = products.filter((p) => p.businessId === b.id);
  const bizProperties = properties.filter((p) => p.businessId === b.id);
  const bizInquiries = inquiries.filter((i) => i.businessId === b.id);

  const totalReceivable = bizCustomers.reduce((sum, c) => sum + (c.balance > 0 ? c.balance : 0), 0);
  const totalPayable = bizSuppliers.reduce((sum, s) => sum + s.balance, 0) + bizCustomers.reduce((sum, c) => sum + (c.balance < 0 ? Math.abs(c.balance) : 0), 0);

  // Today's Sales
  const todayStr = new Date().toISOString().split('T')[0];
  const todayTx = bizTx.filter((t) => t.date.startsWith(todayStr) && t.type === 'sale');
  const todaySalesAmount = todayTx.reduce((sum, t) => sum + t.amount, 0);

  // Monthly Sales
  const thisMonthStr = todayStr.substring(0, 7);
  const monthlyTx = bizTx.filter((t) => t.date.startsWith(thisMonthStr) && t.type === 'sale');
  const monthlySalesAmount = monthlyTx.reduce((sum, t) => sum + t.amount, 0);

  // Low stock products
  const lowStockCount = bizProducts.filter((p) => p.stock <= p.minStockAlert).length;

  // Active inquiries
  const openInquiriesCount = bizInquiries.filter((i) => i.status === 'NEW' || i.status === 'FOLLOW_UP').length;

  // Industry specific payload
  let industrySpecific: Record<string, any> = {};

  if (b.category === 'jewellery_gold' || b.category === 'silver') {
    const goldRule24 = b.rules.find((r) => r.key === 'gold_rate_24k')?.value || 295000;
    const goldRule22 = b.rules.find((r) => r.key === 'gold_rate_22k')?.value || 270400;
    const silverRule = b.rules.find((r) => r.key === 'silver_rate_tola')?.value || 3450;
    const totalGoldWeight = bizProducts.filter((p) => p.metalType === 'gold').reduce((sum, p) => sum + (p.weight || 0) * p.stock, 0);
    const totalSilverWeight = bizProducts.filter((p) => p.metalType === 'silver').reduce((sum, p) => sum + (p.weight || 0) * p.stock, 0);

    industrySpecific = {
      goldRate24K: goldRule24,
      goldRate22K: goldRule22,
      silverRate: silverRule,
      totalGoldStockTola: totalGoldWeight,
      totalSilverStockGram: totalSilverWeight,
      todayGoldSales: todayTx.filter((t) => t.items.some((i) => i.jewelleryDetails?.metalType === 'gold')).reduce((sum, t) => sum + t.amount, 0),
      todaySilverSales: todayTx.filter((t) => t.items.some((i) => i.jewelleryDetails?.metalType === 'silver')).reduce((sum, t) => sum + t.amount, 0),
    };
  } else if (b.category === 'property_dealer' || b.category === 'real_estate') {
    const availablePlots = bizProperties.filter((p) => p.type === 'plot' && p.status === 'AVAILABLE').length;
    const soldPlots = bizProperties.filter((p) => p.type === 'plot' && p.status === 'SOLD').length;
    const availableHouses = bizProperties.filter((p) => p.type === 'house' && p.status === 'AVAILABLE').length;
    const totalPortfolioValue = bizProperties.reduce((sum, p) => sum + p.askingPrice, 0);
    const installmentsDue = bizProperties.filter((p) => p.installmentPlan && p.installmentPlan.pendingInstallments > 0).length;

    industrySpecific = {
      totalProperties: bizProperties.length,
      availablePlots,
      soldPlots,
      availableHouses,
      totalPortfolioValue,
      installmentsDue,
    };
  } else if (b.category === 'clothing_garments') {
    industrySpecific = {
      totalSuitsInStock: bizProducts.reduce((sum, p) => sum + p.stock, 0),
      lowStockArticles: lowStockCount,
      bestSelling: bizProducts.slice(0, 3).map((p) => ({ name: p.name, stock: p.stock, price: p.salePrice })),
    };
  }

  res.json({
    success: true,
    data: {
      business: b,
      totalReceivable,
      totalPayable,
      todaySalesAmount,
      monthlySalesAmount,
      totalCustomers: bizCustomers.length,
      totalProducts: bizProducts.length,
      lowStockCount,
      openInquiriesCount,
      recentTransactions: bizTx.slice(0, 5),
      industrySpecific,
    },
  });
});

// 9. Audit Logs
app.get('/api/audit-logs', (req, res) => {
  const businessId = req.query.businessId as string;
  const list = auditLogs.filter((l) => !businessId || l.businessId === businessId);
  res.json({ success: true, data: list });
});

// ----------------- AI BRAIN, VOICE & INTENT ENGINE -----------------

// A. Voice Assistant Intent Extraction & Action Proposer
app.post('/api/ai/voice-intent', async (req, res) => {
  try {
    const { businessId, transcript, language } = req.body;
    if (!transcript) {
      return res.status(400).json({ success: false, error: 'Transcript required' });
    }

    const b = findBusiness(businessId);
    const bizCustomers = customers.filter((c) => c.businessId === b.id);
    const bizProducts = products.filter((p) => p.businessId === b.id);
    const bizProperties = properties.filter((p) => p.businessId === b.id);
    const bizInquiries = inquiries.filter((i) => i.businessId === b.id);
    const bizRules = b.rules;

    const ai = getGemini();
    let actionProposal: AIAction | null = null;
    let xaraReply = '';

    if (ai) {
      const systemInstruction = `You are Xara, the intelligent, friendly female AI voice assistant for KhataX AI.
You assist Pakistani shopkeepers, businessmen, jewellers, property dealers, boutique owners, and traders.
Personality: Warm, professional, fast, polite, speaking natural Roman Urdu mixed with English (or Urdu if preferred).
Business: "${b.name}"
Category: "${b.profile.categoryName}" (Key modules active: ${JSON.stringify(b.profile.activeModules)})
Currency: ${b.currency}
Configured Rules: ${JSON.stringify(bizRules)}
Existing Customers: ${JSON.stringify(bizCustomers.map((c) => ({ id: c.id, name: c.name, balance: c.balance, phone: c.phone })))}
Existing Products: ${JSON.stringify(bizProducts.map((p) => ({ id: p.id, name: p.name, price: p.salePrice, stock: p.stock, weight: p.weight, metal: p.metalType })))}
Existing Properties: ${JSON.stringify(bizProperties.map((p) => ({ id: p.id, code: p.propertyIdCode, type: p.type, society: p.society, block: p.block, size: p.size, price: p.askingPrice, status: p.status })))}
Existing Inquiries: ${JSON.stringify(bizInquiries.map((i) => ({ customer: i.customerName, req: i.requirement, budget: i.budget, status: i.status })))}

CRITICAL RULES:
1. Never invent or hallucinate data that does not exist.
2. For financial operations (sales, payments, credits, bookings), you MUST propose an action card for confirmation. DO NOT execute directly.
3. Show calculations with configured rules (e.g. 1 tola = 11.664g, 22K gold rate, marla rate, etc.).
4. Understand English, Urdu script, and Roman Urdu seamlessly (e.g., "Ali ke khate mein 5000 jama karo", "Ayesha ko medium black suit 3500 ka sell kiya", "2 tola 22 karat gold set ka hisaab karo", "Block B mein 10 marla plot dikhao", "Ahmed ne kya inquiry ki thi?").

Respond ONLY in JSON format matching this schema:
{
  "detectedLanguage": "Roman Urdu" | "English" | "Urdu",
  "intent": "payment_received" | "sale" | "credit" | "inquiry_save" | "inquiry_search" | "balance_check" | "property_search" | "gold_calc" | "general_qa",
  "xaraSpokenResponse": "Exact text Xara should speak to the user in friendly Roman Urdu / English",
  "needsConfirmation": boolean,
  "actionProposal": {
    "actionType": "create_payment" | "create_credit" | "create_sale" | "create_inquiry" | "create_property" | "update_inventory" | "calculate_gold_value",
    "title": "Short title of action (e.g. Confirm Payment of Rs. 5,000)",
    "summary": "Clear summary in Roman Urdu / English",
    "payload": {
      "customerId": "string (matched or new)",
      "customerName": "string",
      "amount": number,
      "type": "payment_received" | "sale" | "credit",
      "items": [],
      "requirement": "string for inquiry",
      "budget": number,
      "metalDetails": {},
      "propertyDetails": {}
    },
    "preview": {
      "customerName": "string",
      "amount": number,
      "previousBalance": number,
      "newBalance": number,
      "detailsList": [
        { "label": "string", "value": "string or number" }
      ],
      "breakdownText": "string showing math steps"
    }
  } or null
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: `User voice input: "${transcript}"`,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.2,
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      xaraReply = parsed.xaraSpokenResponse || 'Ji, batayein.';
      
      if (parsed.actionProposal && parsed.needsConfirmation) {
        actionProposal = {
          id: `act_${Date.now()}`,
          businessId: b.id,
          actionType: parsed.actionProposal.actionType || 'create_payment',
          title: parsed.actionProposal.title || 'Confirm Transaction',
          summary: parsed.actionProposal.summary || 'Please confirm this action.',
          payload: parsed.actionProposal.payload || {},
          preview: parsed.actionProposal.preview || {},
          status: 'PROPOSED',
          source: 'AI_VOICE',
          createdAt: new Date().toISOString(),
        };
      }

      return res.json({
        success: true,
        data: {
          transcript,
          xaraSpokenResponse: xaraReply,
          actionProposal,
          intent: parsed.intent,
        },
      });
    }

    // Smart Local Fallback Parser if Gemini key is not configured
    const tLower = transcript.toLowerCase();
    let matchedCust = bizCustomers.find((c) => tLower.includes(c.name.toLowerCase().split(' ')[0]));
    if (!matchedCust && tLower.includes('ali')) matchedCust = bizCustomers.find((c) => c.name.includes('Ali'));
    if (!matchedCust && tLower.includes('ayesha')) matchedCust = bizCustomers.find((c) => c.name.includes('Ayesha'));
    if (!matchedCust && tLower.includes('ahmed')) matchedCust = bizCustomers.find((c) => c.name.includes('Ahmed'));
    if (!matchedCust && tLower.includes('bilal')) matchedCust = bizCustomers.find((c) => c.name.includes('Bilal'));

    // Extract numbers
    const numMatch = transcript.match(/\d+[\d,]*/);
    let extractedAmount = numMatch ? parseInt(numMatch[0].replace(/,/g, ''), 10) : 0;
    if (tLower.includes('hazar') || tLower.includes('thousand')) {
      if (extractedAmount < 1000 && extractedAmount > 0) extractedAmount *= 1000;
    }
    if (tLower.includes('lakh') || tLower.includes('lac')) {
      if (extractedAmount < 100 && extractedAmount > 0) extractedAmount *= 100000;
    }
    if (tLower.includes('crore')) {
      if (extractedAmount < 100 && extractedAmount > 0) extractedAmount *= 10000000;
    }

    // Check Balance Query
    if (tLower.includes('balance') || tLower.includes('hisaab') || tLower.includes('kitna hai')) {
      if (matchedCust) {
        xaraReply = `${matchedCust.name} ka current balance ${b.currency} ${matchedCust.balance.toLocaleString()} hai.`;
      } else {
        const totalRec = bizCustomers.reduce((s, c) => s + (c.balance > 0 ? c.balance : 0), 0);
        xaraReply = `Aapka total business receivable ${b.currency} ${totalRec.toLocaleString()} hai.`;
      }
      return res.json({
        success: true,
        data: {
          transcript,
          xaraSpokenResponse: xaraReply,
          actionProposal: null,
          intent: 'balance_check',
        },
      });
    }

    // Check Inquiry Query ("Ahmed ne kya inquiry ki thi?")
    if (tLower.includes('inquiry') || tLower.includes('poocha tha')) {
      const matchInq = bizInquiries.find((i) => matchedCust && i.customerId === matchedCust.id) || bizInquiries[0];
      if (matchInq) {
        xaraReply = `${matchInq.customerName} ne ${matchInq.requirement} ke liye inquiry ki thi. Unka budget ${b.currency} ${matchInq.budget.toLocaleString()} tha. Follow-up ${matchInq.followUpDate} ko scheduled hai.`;
      } else {
        xaraReply = `Is waqt ${bizInquiries.length} customer inquiries active hain.`;
      }
      return res.json({
        success: true,
        data: {
          transcript,
          xaraSpokenResponse: xaraReply,
          actionProposal: null,
          intent: 'inquiry_search',
        },
      });
    }

    // Check Payment
    if (tLower.includes('jama') || tLower.includes('receive') || tLower.includes('payment')) {
      const custName = matchedCust ? matchedCust.name : 'Ali Khan';
      const prevBal = matchedCust ? matchedCust.balance : 12000;
      const amt = extractedAmount || 5000;
      const newBal = prevBal - amt;

      xaraReply = `${custName} ke khate mein ${b.currency} ${amt.toLocaleString()} jama karne hain. Confirm kar dein?`;
      actionProposal = {
        id: `act_${Date.now()}`,
        businessId: b.id,
        actionType: 'create_payment',
        title: `Confirm Payment: ${b.currency} ${amt.toLocaleString()}`,
        summary: `Receive payment from ${custName} and reduce outstanding balance.`,
        payload: {
          customerId: matchedCust?.id || 'cust_j1',
          customerName: custName,
          amount: amt,
          type: 'payment_received',
          paymentMethod: 'cash',
        },
        preview: {
          customerName: custName,
          amount: amt,
          previousBalance: prevBal,
          newBalance: newBal,
          detailsList: [
            { label: 'Customer', value: custName },
            { label: 'Payment Amount', value: `${b.currency} ${amt.toLocaleString()}` },
            { label: 'Previous Balance', value: `${b.currency} ${prevBal.toLocaleString()}` },
            { label: 'Updated Balance', value: `${b.currency} ${newBal.toLocaleString()}` },
          ],
          breakdownText: `Payment Received: ${b.currency} ${amt.toLocaleString()} | Old Balance: ${b.currency} ${prevBal.toLocaleString()} → New Balance: ${b.currency} ${newBal.toLocaleString()}`,
        },
        status: 'PROPOSED',
        source: 'AI_VOICE',
        createdAt: new Date().toISOString(),
      };

      return res.json({
        success: true,
        data: {
          transcript,
          xaraSpokenResponse: xaraReply,
          actionProposal,
          intent: 'payment_received',
        },
      });
    }

    // Check Sale / Udhar
    if (tLower.includes('sell') || tLower.includes('diya') || tLower.includes('becha') || tLower.includes('suit') || tLower.includes('gold')) {
      const custName = matchedCust ? matchedCust.name : 'Ayesha Tariq';
      const prevBal = matchedCust ? matchedCust.balance : 5000;
      const amt = extractedAmount || (b.category === 'jewellery_gold' ? 450000 : 3500);
      const newBal = prevBal + amt;

      xaraReply = `${custName} ko ${b.currency} ${amt.toLocaleString()} ki sale record karni hai. Confirm kar dein?`;
      actionProposal = {
        id: `act_${Date.now()}`,
        businessId: b.id,
        actionType: 'create_sale',
        title: `Confirm Sale: ${b.currency} ${amt.toLocaleString()}`,
        summary: `Record sale for ${custName} with automated digital khata update.`,
        payload: {
          customerId: matchedCust?.id || 'cust_c1',
          customerName: custName,
          amount: amt,
          type: 'sale',
          paymentMethod: 'credit',
        },
        preview: {
          customerName: custName,
          amount: amt,
          previousBalance: prevBal,
          newBalance: newBal,
          detailsList: [
            { label: 'Customer', value: custName },
            { label: 'Sale Amount', value: `${b.currency} ${amt.toLocaleString()}` },
            { label: 'Previous Balance', value: `${b.currency} ${prevBal.toLocaleString()}` },
            { label: 'New Balance (Receivable)', value: `${b.currency} ${newBal.toLocaleString()}` },
          ],
          breakdownText: `Sale of ${b.currency} ${amt.toLocaleString()} recorded. Added to customer ledger.`,
        },
        status: 'PROPOSED',
        source: 'AI_VOICE',
        createdAt: new Date().toISOString(),
      };

      return res.json({
        success: true,
        data: {
          transcript,
          xaraSpokenResponse: xaraReply,
          actionProposal,
          intent: 'sale',
        },
      });
    }

    // Default fallback
    xaraReply = `Ji, maine aapki baat samajh li: "${transcript}". Mazeed batayein kis customer ya khata ka kaam karna hai.`;
    res.json({
      success: true,
      data: {
        transcript,
        xaraSpokenResponse: xaraReply,
        actionProposal: null,
        intent: 'general_qa',
      },
    });
  } catch (err: any) {
    console.error('Error in voice intent:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// B. Execute Confirmed AI Action
app.post('/api/ai/execute-action', (req, res) => {
  const { actionProposal } = req.body as { actionProposal: AIAction };
  if (!actionProposal || !actionProposal.businessId) {
    return res.status(400).json({ success: false, error: 'Invalid action payload' });
  }

  const { businessId, actionType, payload, preview } = actionProposal;
  const b = findBusiness(businessId);

  let resultSummary = '';
  let customerUpdatedName = payload.customerName || 'Customer';

  if (actionType === 'create_payment' || actionType === 'create_sale' || actionType === 'create_credit') {
    const txType = actionType === 'create_payment' ? 'payment_received' : 'sale';
    const numAmount = Number(payload.amount) || preview.amount || 0;
    const numInvoice = `INV-${new Date().getFullYear()}-${String(transactions.length + 101).padStart(4, '0')}`;

    let targetCustomer = payload.customerId ? customers.find((c) => c.id === payload.customerId) : null;
    if (!targetCustomer && payload.customerName) {
      targetCustomer = customers.find((c) => c.businessId === businessId && c.name.toLowerCase() === payload.customerName.toLowerCase());
    }

    let prevBal = targetCustomer ? targetCustomer.balance : preview.previousBalance || 0;
    let newBal = prevBal;

    if (txType === 'payment_received') {
      newBal = prevBal - numAmount;
      if (targetCustomer) {
        targetCustomer.balance = newBal;
        targetCustomer.totalPaid += numAmount;
        targetCustomer.transactionCount += 1;
        targetCustomer.lastTransactionDate = new Date().toISOString();
      }
    } else {
      newBal = prevBal + numAmount;
      if (targetCustomer) {
        targetCustomer.balance = newBal;
        targetCustomer.totalPurchased += numAmount;
        targetCustomer.transactionCount += 1;
        targetCustomer.lastTransactionDate = new Date().toISOString();
      }
    }

    const newTx: Transaction = {
      id: `tx_${Date.now()}`,
      businessId,
      invoiceNumber: numInvoice,
      type: txType,
      customerId: targetCustomer?.id || payload.customerId,
      customerName: targetCustomer?.name || payload.customerName || 'Customer',
      amount: numAmount,
      paymentMethod: payload.paymentMethod || 'cash',
      status: 'completed',
      items: payload.items || [],
      notes: `Action confirmed via ${actionProposal.source}`,
      date: new Date().toISOString(),
      createdSource: actionProposal.source,
      calculatedBreakdown: {
        total: numAmount,
        previousBalance: prevBal,
        newBalance: newBal,
      },
    };

    transactions.unshift(newTx);
    resultSummary = `Done. ${newTx.customerName} ka new balance ${b.currency} ${newBal.toLocaleString()} hai. Invoice ${numInvoice} created.`;
  } else if (actionType === 'create_inquiry') {
    const newInq: Inquiry = {
      id: `inq_${Date.now()}`,
      businessId,
      customerName: payload.customerName || 'Inquiring Customer',
      customerPhone: payload.customerPhone,
      requirement: payload.requirement || 'General Requirement',
      budget: Number(payload.budget) || 0,
      followUpDate: payload.followUpDate || new Date(Date.now() + 86400000).toISOString().split('T')[0],
      status: 'NEW',
      source: 'VOICE_ASSISTANT',
      notes: payload.notes || 'Recorded via Xara Voice',
      createdAt: new Date().toISOString(),
    };
    inquiries.unshift(newInq);
    resultSummary = `Inquiry saved for ${newInq.customerName} with budget ${b.currency} ${newInq.budget.toLocaleString()}.`;
  }

  auditLogs.unshift({
    id: `log_${Date.now()}`,
    businessId,
    action: actionType.toUpperCase(),
    tool: actionType,
    inputSummary: actionProposal.summary,
    resultSummary,
    timestamp: new Date().toISOString(),
    source: actionProposal.source,
    user: 'Xara AI Assistant',
  });

  res.json({
    success: true,
    data: {
      message: resultSummary,
      actionId: actionProposal.id,
      executedAt: new Date().toISOString(),
    },
  });
});

// C. Business AI Chat
app.post('/api/ai/chat', async (req, res) => {
  try {
    const { businessId, message, conversationHistory } = req.body;
    const b = findBusiness(businessId);

    const bizCustomers = customers.filter((c) => c.businessId === b.id);
    const bizTx = transactions.filter((t) => t.businessId === b.id);
    const bizProducts = products.filter((p) => p.businessId === b.id);
    const bizProperties = properties.filter((p) => p.businessId === b.id);
    const bizInquiries = inquiries.filter((i) => i.businessId === b.id);
    const bizSuppliers = suppliers.filter((s) => s.businessId === b.id);

    const totalRec = bizCustomers.reduce((s, c) => s + (c.balance > 0 ? c.balance : 0), 0);
    const totalPay = bizSuppliers.reduce((s, c) => s + c.balance, 0);

    const ai = getGemini();
    if (ai) {
      const systemInstruction = `You are KhataX AI Business Operating Assistant for "${b.name}".
Category: ${b.profile.categoryName}
Currency: ${b.currency}
Total Customers: ${bizCustomers.length}
Total Receivables: ${b.currency} ${totalRec.toLocaleString()}
Total Payables: ${b.currency} ${totalPay.toLocaleString()}
Business Rules: ${JSON.stringify(b.rules)}
Active Customers: ${JSON.stringify(bizCustomers.map((c) => ({ name: c.name, balance: c.balance, phone: c.phone, totalBought: c.totalPurchased })))}
Active Inventory: ${JSON.stringify(bizProducts.map((p) => ({ name: p.name, stock: p.stock, price: p.salePrice })))}
Active Properties: ${JSON.stringify(bizProperties.map((p) => ({ code: p.propertyIdCode, type: p.type, society: p.society, size: p.size, price: p.askingPrice, status: p.status })))}
Inquiries: ${JSON.stringify(bizInquiries.map((i) => ({ customer: i.customerName, req: i.requirement, budget: i.budget, status: i.status, followUp: i.followUpDate })))}
Recent Transactions: ${JSON.stringify(bizTx.slice(0, 10).map((t) => ({ inv: t.invoiceNumber, customer: t.customerName, amt: t.amount, type: t.type, date: t.date })))}

RULES:
1. Always base answers STRICTLY on the actual database provided above. NEVER invent or hallucinate.
2. If asked "Ahmed ne kya inquiry ki thi?", look up Ahmed in the inquiries list and answer accurately with budget and follow up date.
3. If asked about receivables, top debtor, stock levels, or property availability, answer with exact data.
4. Speak warmly in polite English or Roman Urdu matching the user's prompt tone.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: message,
        config: {
          systemInstruction,
          temperature: 0.2,
        },
      });

      return res.json({
        success: true,
        data: {
          reply: response.text || 'KhataX AI business assistant at your service.',
          timestamp: new Date().toISOString(),
        },
      });
    }

    // Fallback response
    let reply = `Here is the current status of ${b.name}: Total receivables stand at ${b.currency} ${totalRec.toLocaleString()} across ${bizCustomers.length} registered customers.`;
    const mLower = message.toLowerCase();
    if (mLower.includes('inquiry')) {
      reply = `You have ${bizInquiries.length} recorded inquiries. The most recent is from ${bizInquiries[0]?.customerName || 'Ahmed'} regarding "${bizInquiries[0]?.requirement || 'requirement'}" with a budget of ${b.currency} ${bizInquiries[0]?.budget.toLocaleString()}.`;
    } else if (mLower.includes('outstanding') || mLower.includes('balance') || mLower.includes('receivable')) {
      const topDebtor = [...bizCustomers].sort((a, b) => b.balance - a.balance)[0];
      reply = `Your total outstanding receivable is ${b.currency} ${totalRec.toLocaleString()}. Top outstanding customer is ${topDebtor?.name || 'Ali'} (${b.currency} ${topDebtor?.balance.toLocaleString()}).`;
    }

    res.json({
      success: true,
      data: {
        reply,
        timestamp: new Date().toISOString(),
      },
    });
  } catch (err: any) {
    console.error('Error in AI chat:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// D. Smart Industry Calculator Engine
app.post('/api/ai/smart-calculator', (req, res) => {
  const { businessId, calculatorType, params } = req.body;
  const b = findBusiness(businessId);

  let result: Record<string, any> = {};

  if (calculatorType === 'gold_calculator') {
    const { weight, unit, purity, ratePerTola, makingCharges, makingType, wastagePercent } = params;
    const tolaRule = Number(b.rules.find((r) => r.key === 'tola_in_grams')?.value || 11.664);

    let weightInTola = Number(weight) || 0;
    if (unit === 'gram') {
      weightInTola = (Number(weight) || 0) / tolaRule;
    } else if (unit === 'ratti') {
      weightInTola = (Number(weight) || 0) / 96; // 96 Ratti = 1 Tola
    }

    const rate = Number(ratePerTola) || Number(b.rules.find((r) => r.key === 'gold_rate_24k')?.value || 295000);
    const rawGoldValue = weightInTola * rate;
    const wastageRate = Number(wastagePercent) || 0;
    const wastageValue = (rawGoldValue * wastageRate) / 100;

    let makingValue = Number(makingCharges) || 0;
    if (makingType === 'per_gram') {
      const grams = weightInTola * tolaRule;
      makingValue = grams * (Number(makingCharges) || 0);
    }

    const total = rawGoldValue + wastageValue + makingValue;

    result = {
      weightInTola: parseFloat(weightInTola.toFixed(4)),
      weightInGrams: parseFloat((weightInTola * tolaRule).toFixed(4)),
      rawGoldValue: Math.round(rawGoldValue),
      wastageValue: Math.round(wastageValue),
      makingValue: Math.round(makingValue),
      totalValue: Math.round(total),
      currency: b.currency,
      formulaUsed: `(${weightInTola.toFixed(3)} Tola × ${rate.toLocaleString()}) + ${wastageRate}% Wastage (${Math.round(wastageValue).toLocaleString()}) + Making (${Math.round(makingValue).toLocaleString()})`,
    };
  } else if (calculatorType === 'property_calculator') {
    const { size, unit, ratePerUnit, downPaymentPercent, installmentMonths } = params;
    const sizeNum = Number(size) || 0;
    const rateNum = Number(ratePerUnit) || 0;
    const totalCost = sizeNum * rateNum;

    const dpPct = Number(downPaymentPercent) || 20;
    const downPayment = (totalCost * dpPct) / 100;
    const remainingAmount = totalCost - downPayment;
    const months = Number(installmentMonths) || 12;
    const monthlyInstallment = months > 0 ? remainingAmount / months : 0;

    result = {
      totalCost: Math.round(totalCost),
      downPayment: Math.round(downPayment),
      remainingAmount: Math.round(remainingAmount),
      monthlyInstallment: Math.round(monthlyInstallment),
      installmentMonths: months,
      currency: b.currency,
    };
  } else {
    result = { message: 'Calculator executed.' };
  }

  res.json({ success: true, data: result });
});

// Start the Express + Vite server
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`KhataX AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
