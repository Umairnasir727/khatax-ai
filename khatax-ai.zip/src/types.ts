export type BusinessCategory =
  | 'jewellery_gold'
  | 'silver'
  | 'property_dealer'
  | 'real_estate'
  | 'clothing_garments'
  | 'general_store'
  | 'pharmacy'
  | 'electronics'
  | 'mobile_shop'
  | 'hardware'
  | 'auto_parts'
  | 'wholesale'
  | 'restaurant'
  | 'cosmetics'
  | 'furniture'
  | 'construction'
  | 'services'
  | 'freelancer'
  | 'other';

export interface BusinessRule {
  id?: string;
  key: string;
  label: string;
  value: number | string;
  unit?: string;
  description?: string;
  category?: string;
}

export interface BusinessField {
  id: string;
  key: string;
  label: string;
  type: 'text' | 'number' | 'select' | 'date' | 'boolean';
  options?: string[];
  required: boolean;
  module: 'product' | 'transaction' | 'customer' | 'property' | 'inquiry';
}

export interface BusinessProfile {
  category: BusinessCategory;
  categoryName: string;
  industryTerminology: Record<string, string>;
  preferredUnits: string[];
  activeModules: {
    jewellery: boolean;
    property: boolean;
    clothing: boolean;
    pharmacy: boolean;
    generalStore: boolean;
    electronics: boolean;
    inquiries: boolean;
    installments: boolean;
  };
  calculationFormulas: {
    goldValueFormula?: string;
    propertyMarlaRateFormula?: string;
    makingChargesType?: 'per_gram' | 'percentage' | 'fixed';
    defaultWastagePercent?: number;
    taxRate?: number;
  };
  customMetrics: string[];
  voicePromptsSuggestion: string[];
}

export interface Business {
  id: string;
  name: string;
  category: BusinessCategory;
  description: string;
  currency: string;
  location: string;
  city?: string;
  phone: string;
  ownerName: string;
  createdAt: string;
  profile: BusinessProfile;
  rules: BusinessRule[];
  customFields: BusinessField[];
}

export interface Customer {
  id: string;
  businessId: string;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  city?: string;
  balance: number; // positive = You'll get (Receivable), negative = You'll give (Payable)
  currentBalance?: number; // Alias for balance
  goldBalanceWeight?: number; // e.g. customer gold credit in tolas/grams
  creditLimit?: number;
  totalPurchased?: number;
  totalPurchases?: number;
  totalPaid?: number;
  transactionCount?: number;
  tags?: string[];
  notes?: string;
  lastTransactionDate?: string;
  createdAt?: string;
}

export interface Supplier {
  id: string;
  businessId: string;
  name: string;
  phone: string;
  company?: string;
  address?: string;
  city?: string;
  category?: string;
  balance: number; // positive = Payable (you owe supplier)
  currentBalance?: number;
  totalPurchased?: number;
  totalPaid?: number;
  notes?: string;
  lastPurchaseDate?: string;
  createdAt?: string;
}

export type TransactionType =
  | 'sale'
  | 'purchase'
  | 'payment_received'
  | 'payment_given'
  | 'credit'
  | 'return'
  | 'exchange'
  | 'GAVE'
  | 'GOT';

export interface JewelleryItemDetails {
  metalType?: 'gold' | 'silver' | 'platinum';
  weight?: number;
  unit?: 'tola' | 'gram' | 'ratti' | 'masha';
  purity?: '24K' | '22K' | '21K' | '18K' | '999' | '925' | 'custom';
  ratePerUnit?: number;
  makingCharges?: number;
  makingChargesType?: 'per_gram' | 'percentage' | 'fixed';
  wastagePercent?: number;
  netWeightGrams?: number;
}

export interface PropertyItemDetails {
  propertyIdCode?: string;
  propertyType?: 'plot' | 'house' | 'apartment' | 'commercial' | 'agricultural';
  society?: string;
  block?: string;
  plotNumber?: string;
  size?: number;
  unit?: 'marla' | 'kanal' | 'sqft' | 'sqyard' | 'acre';
  ratePerUnit?: number;
  installmentNo?: number;
}

export interface ClothingItemDetails {
  sku?: string;
  size?: 'XS' | 'S' | 'M' | 'L' | 'XL' | 'XXL' | 'Custom';
  color?: string;
  fabric?: string;
  brand?: string;
}

export interface PharmacyItemDetails {
  genericName?: string;
  batchNumber?: string;
  expiryDate?: string;
  dosageForm?: string;
}

export interface TransactionItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  discount?: number;
  tax?: number;
  subtotal: number;
  jewelleryDetails?: JewelleryItemDetails;
  propertyDetails?: PropertyItemDetails;
  clothingDetails?: ClothingItemDetails;
  pharmacyDetails?: PharmacyItemDetails;
}

export interface Transaction {
  id: string;
  businessId: string;
  invoiceNumber: string;
  type: TransactionType;
  customerId?: string;
  customerName?: string;
  supplierId?: string;
  supplierName?: string;
  amount: number;
  paymentMethod: 'cash' | 'bank_transfer' | 'credit' | 'cheque' | 'gold_exchange' | 'other';
  paymentMode?: string;
  status: 'completed' | 'pending' | 'cancelled';
  items: TransactionItem[];
  notes?: string;
  category?: string;
  date?: string;
  createdAt?: string;
  metadata?: Record<string, any>;
  source?: 'AI_VOICE' | 'AI_CHAT' | 'MANUAL' | 'DEMO' | 'WEB';
  createdSource?: 'AI_VOICE' | 'AI_CHAT' | 'MANUAL' | 'DEMO' | 'WEB';
  calculatedBreakdown?: {
    rawPrice?: number;
    makingCharges?: number;
    wastageAmount?: number;
    discount?: number;
    tax?: number;
    total: number;
    previousBalance?: number;
    newBalance?: number;
  };
}

export interface Property {
  id: string;
  businessId: string;
  propertyIdCode?: string;
  title?: string;
  type: 'plot' | 'house' | 'apartment' | 'commercial' | 'agricultural' | 'PLOT' | 'HOUSE' | 'COMMERCIAL' | 'FILE';
  location?: string;
  society: string;
  block?: string;
  plotNumber?: string;
  size?: number;
  sizeMarla?: number;
  unit?: 'marla' | 'kanal' | 'sqft' | 'sqyard' | 'acre';
  askingPrice?: number;
  totalPrice?: number;
  salePrice?: number;
  purchasePrice?: number;
  ownerName?: string;
  ownerPhone?: string;
  buyerName?: string;
  buyerPhone?: string;
  status: 'AVAILABLE' | 'RESERVED' | 'SOLD' | 'PURCHASED' | 'PENDING' | 'BOOKED';
  installmentPlan?: {
    totalInstallments: number;
    installmentAmount: number;
    paidInstallments: number;
    pendingInstallments: number;
    nextDueDate: string;
  };
  documentationStatus?: 'COMPLETE' | 'IN_PROCESS' | 'PENDING_REGISTRY' | 'FILE_ONLY';
  features?: string[];
  notes?: string;
  createdAt?: string;
}

export interface Product {
  id: string;
  businessId: string;
  name: string;
  title?: string;
  sku?: string;
  category: string;
  brand?: string;
  purchasePrice?: number;
  costPrice?: number;
  salePrice?: number;
  sellingPrice?: number;
  stock?: number;
  stockQuantity?: number;
  minStockAlert?: number;
  unit: string;
  size?: string;
  color?: string;
  fabric?: string;
  batchNumber?: string;
  expiryDate?: string;
  serialNumber?: string;
  imei?: string;
  warranty?: string;
  metalType?: 'gold' | 'silver' | 'platinum';
  purity?: string;
  weight?: number;
  customProperties?: Record<string, any>;
  images?: string[];
  notes?: string;
  createdAt?: string;
}

export type InquiryStatus = 'NEW' | 'CONTACTED' | 'FOLLOW_UP' | 'CONVERTED' | 'CANCELLED' | 'LOST';

export interface Inquiry {
  id: string;
  businessId: string;
  customerName: string;
  customerPhone?: string;
  customerId?: string;
  requirement: string;
  category?: string;
  productOrPropertyCategory?: string;
  budget?: number;
  quantityOrSize?: string;
  followUpDate?: string;
  status: InquiryStatus;
  source?: 'WALK_IN' | 'PHONE' | 'WHATSAPP' | 'REFERRAL' | 'VOICE_ASSISTANT';
  notes?: string;
  assignedPerson?: string;
  createdAt?: string;
}

export type ActionStatus = 'PROPOSED' | 'CONFIRMED' | 'REJECTED' | 'EXECUTED';

export interface AIAction {
  id: string;
  businessId: string;
  actionType:
    | 'create_payment'
    | 'create_credit'
    | 'create_sale'
    | 'create_purchase'
    | 'create_customer'
    | 'create_inquiry'
    | 'create_property'
    | 'update_inventory'
    | 'calculate_gold_value'
    | 'calculate_property_value';
  title: string;
  summary: string;
  payload: Record<string, any>;
  preview: {
    customerName?: string;
    amount?: number;
    previousBalance?: number;
    newBalance?: number;
    detailsList?: { label: string; value: string | number }[];
    breakdownText?: string;
  };
  status: ActionStatus;
  source: 'AI_VOICE' | 'AI_CHAT' | 'WEB' | 'MANUAL' | 'DEMO';
  createdAt: string;
  executedAt?: string;
}

export interface AuditLog {
  id: string;
  businessId: string;
  action?: string;
  actionType?: string;
  tool?: string;
  inputSummary?: string;
  details?: string;
  resultSummary?: string;
  status?: string;
  sourceTranscript?: string;
  timestamp: string;
  source: 'AI_VOICE' | 'AI_CHAT' | 'WEB' | 'MANUAL' | 'DEMO';
  user: string;
}

export type XaraVoiceState =
  | 'IDLE'
  | 'LISTENING'
  | 'UNDERSTANDING'
  | 'CONFIRMING'
  | 'EXECUTING'
  | 'SPEAKING'
  | 'ERROR';

export interface VoiceMessage {
  id: string;
  sender: 'user' | 'xara';
  text: string;
  timestamp: string;
  actionProposal?: AIAction;
  audioUrl?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  actionProposal?: AIAction;
  insightsData?: any;
}
