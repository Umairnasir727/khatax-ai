import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  ArrowDownLeft,
  ArrowUpRight,
  Gem,
  Building2,
  Shirt,
  Store,
  Users,
  AlertCircle,
  HelpCircle,
  Calculator,
  Mic,
  Plus,
  Sparkles,
  ArrowRight,
  Clock,
  CheckCircle2,
  DollarSign,
  Package,
} from 'lucide-react';
import { Business, Customer, Transaction, Inquiry, AIAction } from '../types';
import { api } from '../services/api';
import { TabType } from './Sidebar';

interface DynamicDashboardProps {
  currentBusiness: Business;
  onNavigateTab: (tab: TabType) => void;
  onOpenVoiceModal: () => void;
  onOpenActionDialog: (action: AIAction) => void;
  onOpenNewTransaction: () => void;
  onOpenNewCustomer: () => void;
  onOpenNewInquiry: () => void;
}

export const DynamicDashboard: React.FC<DynamicDashboardProps> = ({
  currentBusiness,
  onNavigateTab,
  onOpenVoiceModal,
  onOpenActionDialog,
  onOpenNewTransaction,
  onOpenNewCustomer,
  onOpenNewInquiry,
}) => {
  const [summaryData, setSummaryData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [quickCalcGrams, setQuickCalcGrams] = useState<number>(11.664);
  const [quickCalcMaking, setQuickCalcMaking] = useState<number>(3500);
  const [quickCalcResult, setQuickCalcResult] = useState<number | null>(null);

  const isJewellery = currentBusiness.category === 'jewellery_gold' || currentBusiness.category === 'silver';
  const isProperty = currentBusiness.category === 'property_dealer' || currentBusiness.category === 'real_estate';
  const isClothing = currentBusiness.category === 'clothing_garments';

  const loadDashboard = async () => {
    setIsLoading(true);
    try {
      const data = await api.getDashboardSummary(currentBusiness.id);
      setSummaryData(data);
    } catch (e) {
      console.error('Failed to load dashboard summary:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadDashboard();
  }, [currentBusiness.id]);

  // Gold live quick calculator helper
  useEffect(() => {
    if (isJewellery) {
      const rate24k = currentBusiness.rules.find((r) => r.key === 'gold_rate_24k')?.value || 248000;
      const tolaGram = currentBusiness.rules.find((r) => r.key === 'tola_in_grams')?.value || 11.664;
      const ratePerGram = rate24k / tolaGram;
      const metalCost = (quickCalcGrams || 0) * ratePerGram;
      const total = metalCost + (quickCalcMaking || 0);
      setQuickCalcResult(Math.round(total));
    }
  }, [quickCalcGrams, quickCalcMaking, currentBusiness.rules, isJewellery]);

  const goldRate24k = currentBusiness.rules.find((r) => r.key === 'gold_rate_24k')?.value || 248000;
  const goldRate22k = currentBusiness.rules.find((r) => r.key === 'gold_rate_22k')?.value || 227333;
  const silverRate = currentBusiness.rules.find((r) => r.key === 'silver_rate_tola')?.value || 2850;

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      
      {/* Welcome Banner & Quick Action Buttons */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-[#111111] p-6 rounded-2xl border border-white/5 shadow-xl relative overflow-hidden">
        <div className="space-y-1.5">
          <div className="flex items-center space-x-2">
            <span className="text-[11px] uppercase tracking-widest font-bold text-blue-400 bg-blue-500/10 px-2.5 py-0.5 rounded-full border border-blue-500/20">
              {currentBusiness.profile.categoryName} Workspace
            </span>
            <span className="text-gray-500 text-xs font-medium">• {currentBusiness.city}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Assalam-o-Alaikum, {currentBusiness.name}
          </h1>
          <p className="text-xs sm:text-sm text-gray-400">
            Digital Khata, inventory aur customer inquiries active hain. Xara Voice Assistant ready hai.
          </p>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            id="dash-talk-xara-btn"
            onClick={onOpenVoiceModal}
            className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-blue-600/20 transition active:scale-95 group border border-white/10"
          >
            <Mic className="w-4 h-4 group-hover:scale-110 transition-transform" />
            <span>Voice Entry (Xara)</span>
          </button>

          <button
            id="dash-add-trans-btn"
            onClick={onOpenNewTransaction}
            className="flex items-center space-x-1.5 px-3.5 py-2.5 rounded-xl bg-[#1a1a1a] hover:bg-white/5 text-gray-200 hover:text-white border border-white/10 font-bold text-xs uppercase tracking-wider transition"
          >
            <Plus className="w-4 h-4 text-blue-400" />
            <span>+ Transaction</span>
          </button>

          <button
            id="dash-add-cust-btn"
            onClick={onOpenNewCustomer}
            className="flex items-center space-x-1.5 px-3.5 py-2.5 rounded-xl bg-[#1a1a1a] hover:bg-white/5 text-gray-200 hover:text-white border border-white/10 font-bold text-xs uppercase tracking-wider transition"
          >
            <Users className="w-4 h-4 text-gray-300" />
            <span>+ Customer</span>
          </button>

          <button
            id="dash-add-inquiry-btn"
            onClick={onOpenNewInquiry}
            className="flex items-center space-x-1.5 px-3.5 py-2.5 rounded-xl bg-[#1a1a1a] hover:bg-white/5 text-gray-200 hover:text-white border border-white/10 font-bold text-xs uppercase tracking-wider transition"
          >
            <HelpCircle className="w-4 h-4 text-yellow-500" />
            <span>+ Inquiry</span>
          </button>
        </div>
      </div>

      {/* DYNAMIC INDUSTRY KPI METRICS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Metric 1: Total Receivables */}
        <div className="bg-[#161616] p-5 rounded-2xl border border-white/5">
          <div className="text-xs font-bold text-gray-500 uppercase mb-2">
            Total Receivable (Len-den)
          </div>
          <div className="text-2xl font-bold text-white">
            {(summaryData?.totalReceivable || 0).toLocaleString()} <span className="text-sm text-gray-500 font-normal">{currentBusiness.currency}</span>
          </div>
          <div className="mt-2 text-xs text-green-500 font-medium">
            ↑ Customer Khata Balance
          </div>
        </div>

        {/* Metric 2: Industry Specific Metric */}
        {isJewellery ? (
          <div className="bg-[#161616] p-5 rounded-2xl border border-white/5">
            <div className="text-xs font-bold text-gray-500 uppercase mb-2">
              Current Gold Rate (24K)
            </div>
            <div className="text-2xl font-bold font-mono text-yellow-500">
              {goldRate24k.toLocaleString()} <span className="text-sm text-gray-500 font-normal">{currentBusiness.currency} / tola</span>
            </div>
            <div className="mt-2 text-xs text-gray-400">
              22K: {goldRate22k.toLocaleString()} • Silver: {silverRate.toLocaleString()}
            </div>
          </div>
        ) : isProperty ? (
          <div className="bg-[#161616] p-5 rounded-2xl border border-white/5">
            <div className="text-xs font-bold text-gray-500 uppercase mb-2">
              Properties & Plots
            </div>
            <div className="text-2xl font-bold text-white">
              {summaryData?.totalProperties || 0} <span className="text-sm text-gray-500 font-normal">Listed</span>
            </div>
            <div className="mt-2 text-xs text-blue-400 font-medium">
              {summaryData?.availableProperties || 0} Available • {summaryData?.soldProperties || 0} Sold
            </div>
          </div>
        ) : (
          <div className="bg-[#161616] p-5 rounded-2xl border border-white/5">
            <div className="text-xs font-bold text-gray-500 uppercase mb-2">
              Total Products & Stock
            </div>
            <div className="text-2xl font-bold text-white">
              {summaryData?.totalProducts || 0} <span className="text-sm text-gray-500 font-normal">Items</span>
            </div>
            <div className="mt-2 text-xs text-blue-400 font-medium">
              Active catalog inventory
            </div>
          </div>
        )}

        {/* Metric 3: Active Customers */}
        <div className="bg-[#161616] p-5 rounded-2xl border border-white/5">
          <div className="text-xs font-bold text-gray-500 uppercase mb-2">
            Active Accounts
          </div>
          <div className="text-2xl font-bold text-white">
            {summaryData?.totalCustomers || 0} <span className="text-sm text-gray-500 font-normal">Customers</span>
          </div>
          <div className="mt-2 text-xs text-gray-400">
            Registered ledger accounts
          </div>
        </div>

        {/* Metric 4: Pending Inquiries & Follow-ups */}
        <div className="bg-[#161616] p-5 rounded-2xl border border-white/5">
          <div className="text-xs font-bold text-gray-500 uppercase mb-2">
            Pending Inquiries
          </div>
          <div className="text-2xl font-bold text-white">
            {summaryData?.pendingInquiries || 0} <span className="text-sm text-gray-500 font-normal">Deals</span>
          </div>
          <div className="mt-2 text-xs text-yellow-500 font-medium">
            High priority follow-ups
          </div>
        </div>

      </div>

      {/* AI INTELLIGENCE TICKER BANNER */}
      <div className="p-4 rounded-2xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-between shadow-lg">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center flex-shrink-0 font-bold">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-blue-400 tracking-widest block">
              Xara AI Business Intelligence
            </span>
            <p className="text-xs text-gray-200 font-medium">
              {isJewellery
                ? `Gold rates are updated to Rs. ${goldRate24k.toLocaleString()} / Tola. 3 gold orders are ready for delivery.`
                : isProperty
                ? `You have 4 prospective buyers for Bahria Town & DHA plots. Follow up today!`
                : `Total customer receivables stand at ${currentBusiness.currency} ${(summaryData?.totalReceivable || 0).toLocaleString()}. Send WhatsApp ledger reminders.`}
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigateTab('reports')}
          className="hidden md:flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-[#1a1a1a] hover:bg-white/5 text-xs font-bold uppercase tracking-wider text-blue-400 border border-white/10 transition flex-shrink-0"
        >
          <span>View Intel</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* CENTRAL 2-COLUMN SECTION: RECENT KHATA TRANSACTIONS + QUICK INDUSTRY TOOL */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column (2 Cols): Recent Digital Khata Ledger */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-white">Recent Ledger Transactions</h2>
            <button
              onClick={() => onNavigateTab('khata')}
              className="text-xs font-bold text-blue-400 uppercase tracking-widest hover:text-blue-300 transition"
            >
              View All
            </button>
          </div>

          <div className="bg-[#111111] rounded-2xl border border-white/5 overflow-hidden">
            <table className="w-full text-left text-sm">
              <thead className="bg-white/5 text-gray-400 text-xs uppercase">
                <tr>
                  <th className="px-6 py-4">Customer</th>
                  <th className="px-6 py-4">Details</th>
                  <th className="px-6 py-4">Category</th>
                  <th className="px-6 py-4 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {summaryData?.recentTransactions && summaryData.recentTransactions.length > 0 ? (
                  summaryData.recentTransactions.map((tx: Transaction) => (
                    <tr key={tx.id} className="hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4 font-semibold text-white">
                        <div className="flex items-center space-x-2">
                          <span>{tx.customerName}</span>
                          {tx.source === 'AI_VOICE' && (
                            <span className="text-[9px] uppercase px-1.5 py-0.2 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 font-bold">
                              🎙 Voice
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-gray-400 text-xs">
                        {tx.notes || (tx.type === 'GAVE' ? 'Udhaar Debit' : 'Cash Received')}
                      </td>
                      <td className="px-6 py-4 text-gray-400 text-xs font-mono">
                        {tx.category || (tx.type === 'GAVE' ? 'Debit' : 'Credit')}
                      </td>
                      <td className={`px-6 py-4 text-right font-bold font-mono ${
                        tx.type === 'GAVE' ? 'text-red-400' : 'text-green-400'
                      }`}>
                        {tx.type === 'GAVE' ? '-' : '+'} {currentBusiness.currency} {tx.amount.toLocaleString()}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="px-6 py-8 text-center text-gray-500 text-xs">
                      No recent transactions found. Create an entry via Voice Assistant or Khata Ledger.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column (1 Col): Dynamic Industry Quick Tool / Widget */}
        <div className="bg-[#161616] rounded-2xl border border-blue-500/30 flex flex-col overflow-hidden relative shadow-2xl shadow-blue-500/10">
          
          <div className="p-4 bg-blue-600/10 border-b border-blue-500/20 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-xs font-bold uppercase tracking-widest text-blue-400">Xara AI Assistant</span>
            </div>
            <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded text-gray-300 font-mono">ACTIVE</span>
          </div>

          <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
            {isJewellery ? (
              <div className="space-y-3">
                <div className="text-xs font-bold text-gray-500 uppercase">
                  Sarafa Gold Quick Math
                </div>

                <div className="space-y-2 text-xs">
                  <div>
                    <label className="text-gray-400 block mb-1">Weight in Grams</label>
                    <input
                      type="number"
                      step="0.001"
                      value={quickCalcGrams}
                      onChange={(e) => setQuickCalcGrams(parseFloat(e.target.value) || 0)}
                      className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-blue-500"
                    />
                    <span className="text-[10px] text-gray-500 mt-0.5 block font-mono">
                      = {(quickCalcGrams / 11.664).toFixed(3)} Tolas
                    </span>
                  </div>

                  <div>
                    <label className="text-gray-400 block mb-1">Making Charges (Mazdoori)</label>
                    <input
                      type="number"
                      value={quickCalcMaking}
                      onChange={(e) => setQuickCalcMaking(parseFloat(e.target.value) || 0)}
                      className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div className="p-3 bg-white/5 border border-white/10 rounded-xl text-center">
                    <span className="text-[10px] text-gray-400 uppercase tracking-wider font-bold block">
                      Calculated Total (24K)
                    </span>
                    <span className="text-xl font-bold text-yellow-500 font-mono mt-0.5 block">
                      {currentBusiness.currency} {(quickCalcResult || 0).toLocaleString()}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => onNavigateTab('calculator')}
                  className="w-full py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 font-bold text-xs uppercase tracking-wider border border-white/10 transition"
                >
                  Open Full Sarafa Calculator →
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="text-xs font-bold text-gray-500 uppercase">
                  Voice Command Example
                </div>
                <div className="p-4 bg-white/5 border border-white/10 rounded-xl space-y-2">
                  <p className="text-sm font-medium leading-relaxed italic text-gray-200">
                    "Ali ko 2 tola gold set 4 lakh mein diya hai udhaar"
                  </p>
                  <p className="text-[11px] text-blue-400">
                    Xara automatically extracts customer, metal, weight & updates khata!
                  </p>
                </div>
              </div>
            )}

            <div className="pt-2">
              <button
                onClick={onOpenVoiceModal}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white py-3 rounded-xl text-xs font-bold uppercase tracking-widest shadow-lg shadow-blue-600/20 transition flex items-center justify-center space-x-2"
              >
                <Mic className="w-4 h-4" />
                <span>🎙 Click to Talk to Xara</span>
              </button>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
