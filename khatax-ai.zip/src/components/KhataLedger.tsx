import React, { useState, useEffect } from 'react';
import {
  Plus,
  Search,
  Filter,
  ArrowDownLeft,
  ArrowUpRight,
  Share2,
  Printer,
  Download,
  Calendar,
  DollarSign,
  User,
  CheckCircle2,
  FileText,
  X,
  Sparkles,
  MessageCircle,
  Gem,
  Building2,
  Shirt,
} from 'lucide-react';
import { Business, Customer, Transaction, AIAction } from '../types';
import { api } from '../services/api';

interface KhataLedgerProps {
  currentBusiness: Business;
  onOpenVoiceModal: () => void;
  onOpenActionDialog: (action: AIAction) => void;
}

export const KhataLedger: React.FC<KhataLedgerProps> = ({
  currentBusiness,
  onOpenVoiceModal,
  onOpenActionDialog,
}) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | 'GAVE' | 'GOT'>('ALL');
  const [isNewTxModalOpen, setIsNewTxModalOpen] = useState(false);
  const [selectedTxForReceipt, setSelectedTxForReceipt] = useState<Transaction | null>(null);

  // New Transaction Form State
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('');
  const [txType, setTxType] = useState<'GAVE' | 'GOT'>('GOT');
  const [amount, setAmount] = useState<string>('');
  const [category, setCategory] = useState('Sale');
  const [notes, setNotes] = useState('');
  const [paymentMode, setPaymentMode] = useState<'CASH' | 'ONLINE' | 'BANK' | 'CREDIT'>('CASH');

  // Industry-specific transaction metadata
  const [goldWeightGrams, setGoldWeightGrams] = useState<string>('');
  const [goldKarat, setGoldKarat] = useState<string>('22K');
  const [propertyPlotNumber, setPropertyPlotNumber] = useState<string>('');
  const [garmentSize, setGarmentSize] = useState<string>('M');

  const isJewellery = currentBusiness.category === 'jewellery_gold' || currentBusiness.category === 'silver';
  const isProperty = currentBusiness.category === 'property_dealer' || currentBusiness.category === 'real_estate';
  const isClothing = currentBusiness.category === 'clothing_garments';

  const loadData = async () => {
    try {
      const [txList, custList] = await Promise.all([
        api.getTransactions(currentBusiness.id),
        api.getCustomers(currentBusiness.id),
      ]);
      setTransactions(txList);
      setCustomers(custList);
    } catch (e) {
      console.error('Failed to load ledger data:', e);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentBusiness.id]);

  const handleCreateTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || (!selectedCustomerId && !newCustomerName.trim())) return;

    let targetCustId = selectedCustomerId;
    let targetCustName = '';

    if (!targetCustId && newCustomerName.trim()) {
      // Create new customer first
      const newCust = await api.createCustomer({
        businessId: currentBusiness.id,
        name: newCustomerName.trim(),
        phone: newCustomerPhone.trim() || '0300-0000000',
        currentBalance: 0,
      });
      targetCustId = newCust.id;
      targetCustName = newCust.name;
    } else {
      const found = customers.find((c) => c.id === targetCustId);
      targetCustName = found ? found.name : 'Customer';
    }

    const metadata: Record<string, any> = {};
    if (isJewellery && goldWeightGrams) {
      metadata.weightGrams = parseFloat(goldWeightGrams);
      metadata.karat = goldKarat;
      metadata.tola = (parseFloat(goldWeightGrams) / 11.664).toFixed(3);
    }
    if (isProperty && propertyPlotNumber) {
      metadata.plotNumber = propertyPlotNumber;
    }
    if (isClothing && garmentSize) {
      metadata.size = garmentSize;
    }

    await api.createTransaction({
      businessId: currentBusiness.id,
      customerId: targetCustId,
      customerName: targetCustName,
      type: txType,
      amount: parseFloat(amount),
      category,
      notes,
      paymentMode,
      source: 'MANUAL',
      metadata,
    });

    setIsNewTxModalOpen(false);
    resetForm();
    loadData();
  };

  const resetForm = () => {
    setSelectedCustomerId('');
    setNewCustomerName('');
    setNewCustomerPhone('');
    setAmount('');
    setNotes('');
    setGoldWeightGrams('');
    setPropertyPlotNumber('');
  };

  // WhatsApp share builder
  const handleShareWhatsApp = (tx: Transaction) => {
    const cust = customers.find((c) => c.id === tx.customerId);
    const balance = cust?.currentBalance || 0;
    const msg = `*KhataX AI Receipt - ${currentBusiness.name}*\n` +
      `---------------------------\n` +
      `Customer: *${tx.customerName}*\n` +
      `Date: ${new Date(tx.createdAt).toLocaleDateString()}\n` +
      `Transaction: *${tx.type === 'GOT' ? 'Payment Received / Jama (+)' : 'Udhaar / Given (-)'} ${currentBusiness.currency} ${tx.amount.toLocaleString()}*\n` +
      `Payment Mode: ${tx.paymentMode}\n` +
      (tx.notes ? `Details: ${tx.notes}\n` : '') +
      `---------------------------\n` +
      `*Total Outstanding Balance:* ${currentBusiness.currency} ${balance.toLocaleString()}\n` +
      `_Powered by KhataX AI_`;

    const encoded = encodeURIComponent(msg);
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
  };

  const filteredTransactions = transactions.filter((tx) => {
    const matchesSearch =
      tx.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (tx.notes && tx.notes.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesType =
      filterType === 'ALL' ||
      (filterType === 'GAVE' && tx.type === 'GAVE') ||
      (filterType === 'GOT' && tx.type === 'GOT');
    return matchesSearch && matchesType;
  });

  const totalGot = transactions.filter((t) => t.type === 'GOT').reduce((s, t) => s + t.amount, 0);
  const totalGave = transactions.filter((t) => t.type === 'GAVE').reduce((s, t) => s + t.amount, 0);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-[#111111] p-6 rounded-2xl border border-white/5 shadow-xl">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-bold text-white tracking-tight">Digital Khata Ledger</h1>
            <span className="text-[11px] uppercase tracking-widest font-bold px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
              {currentBusiness.profile.categoryName}
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Complete records of payments, receivables, sales & customer accounts
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={onOpenVoiceModal}
            className="flex items-center space-x-1.5 px-3.5 py-2.5 rounded-xl bg-[#1a1a1a] hover:bg-white/5 text-blue-400 border border-white/10 text-xs font-bold uppercase tracking-wider transition"
          >
            <Sparkles className="w-4 h-4" />
            <span>Voice Entry (Xara)</span>
          </button>

          <button
            id="add-transaction-modal-btn"
            onClick={() => setIsNewTxModalOpen(true)}
            className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-blue-600/20 transition active:scale-95 border border-white/10"
          >
            <Plus className="w-4 h-4" />
            <span>+ Add Transaction</span>
          </button>
        </div>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#161616] p-5 rounded-2xl border border-white/5">
          <div className="flex items-center justify-between text-xs text-gray-500 font-bold uppercase mb-2">
            <span>Total Received (Jama)</span>
            <div className="p-1.5 rounded-lg bg-green-500/10 text-green-400">
              <ArrowDownLeft className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold font-mono text-green-400">
            + {totalGot.toLocaleString()} <span className="text-sm text-gray-500 font-normal font-sans">{currentBusiness.currency}</span>
          </p>
          <span className="text-xs text-green-500 mt-2 block font-medium">↑ Collected from customers</span>
        </div>

        <div className="bg-[#161616] p-5 rounded-2xl border border-white/5">
          <div className="flex items-center justify-between text-xs text-gray-500 font-bold uppercase mb-2">
            <span>Total Given (Udhaar / Credit)</span>
            <div className="p-1.5 rounded-lg bg-red-500/10 text-red-400">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold font-mono text-red-400">
            - {totalGave.toLocaleString()} <span className="text-sm text-gray-500 font-normal font-sans">{currentBusiness.currency}</span>
          </p>
          <span className="text-xs text-gray-400 mt-2 block">Pending receivables</span>
        </div>

        <div className="bg-[#161616] p-5 rounded-2xl border border-white/5">
          <div className="flex items-center justify-between text-xs text-gray-500 font-bold uppercase mb-2">
            <span>Net Balance Flow</span>
            <div className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold font-mono text-white">
            {(totalGot - totalGave).toLocaleString()} <span className="text-sm text-gray-500 font-normal font-sans">{currentBusiness.currency}</span>
          </p>
          <span className="text-xs text-gray-400 mt-2 block">All-time ledger volume</span>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="p-4 rounded-2xl bg-[#161616] border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            id="khata-search-input"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by customer name, notes, or item..."
            className="w-full bg-[#111111] border border-white/10 rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setFilterType('ALL')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition ${
              filterType === 'ALL'
                ? 'bg-blue-600 text-white'
                : 'bg-white/5 text-gray-400 hover:text-white border border-white/5'
            }`}
          >
            All ({transactions.length})
          </button>
          <button
            onClick={() => setFilterType('GOT')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition ${
              filterType === 'GOT'
                ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                : 'bg-white/5 text-gray-400 hover:text-white border border-white/5'
            }`}
          >
            Received (Jama)
          </button>
          <button
            onClick={() => setFilterType('GAVE')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition ${
              filterType === 'GAVE'
                ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                : 'bg-white/5 text-gray-400 hover:text-white border border-white/5'
            }`}
          >
            Given (Udhaar)
          </button>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="rounded-2xl bg-[#111111] border border-white/5 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-gray-300">
            <thead className="bg-white/5 text-gray-400 uppercase font-semibold text-[10px] tracking-wider border-b border-white/5">
              <tr>
                <th className="px-6 py-4">Customer & Details</th>
                <th className="px-6 py-4">Category / Specs</th>
                <th className="px-6 py-4">Mode / Source</th>
                <th className="px-6 py-4">Date & Time</th>
                <th className="px-6 py-4 text-right">Amount</th>
                <th className="px-6 py-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredTransactions.length > 0 ? (
                filteredTransactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-white/5 transition-colors">
                    
                    {/* Customer info */}
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs flex-shrink-0 ${
                          tx.type === 'GOT'
                            ? 'bg-green-500/10 text-green-400 border border-green-500/20'
                            : 'bg-red-500/10 text-red-400 border border-red-500/20'
                        }`}>
                          {tx.customerName.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="font-bold text-white text-sm">
                              {tx.customerName}
                            </span>
                            {tx.source === 'AI_VOICE' && (
                              <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 font-bold">
                                🎙 Xara
                              </span>
                            )}
                          </div>
                          {tx.notes && (
                            <p className="text-[11px] text-gray-400 mt-0.5">{tx.notes}</p>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Category & Custom Metadata */}
                    <td className="px-6 py-4">
                      <span className="px-2 py-0.5 rounded-md bg-white/5 text-gray-300 font-medium">
                        {tx.category || 'General'}
                      </span>
                      {tx.metadata && (
                        <div className="mt-1 text-[11px] text-gray-400 space-x-2 font-mono">
                          {tx.metadata.weightGrams && (
                            <span>{tx.metadata.weightGrams}g ({tx.metadata.karat})</span>
                          )}
                          {tx.metadata.tola && <span>{tx.metadata.tola} Tolas</span>}
                          {tx.metadata.plotNumber && <span>Plot: {tx.metadata.plotNumber}</span>}
                          {tx.metadata.size && <span>Size: {tx.metadata.size}</span>}
                        </div>
                      )}
                    </td>

                    {/* Mode & Source */}
                    <td className="px-6 py-4">
                      <span className="text-gray-300 font-medium">{tx.paymentMode}</span>
                    </td>

                    {/* Date */}
                    <td className="px-6 py-4 text-gray-400 font-mono">
                      {new Date(tx.createdAt).toLocaleDateString([], {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                      })}
                    </td>

                    {/* Amount */}
                    <td className="px-6 py-4 text-right">
                      <span className={`text-sm font-bold font-mono ${
                        tx.type === 'GOT' ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {tx.type === 'GOT' ? '+' : '-'} {currentBusiness.currency} {tx.amount.toLocaleString()}
                      </span>
                      <span className="text-[10px] text-gray-500 block">
                        {tx.type === 'GOT' ? 'Jama (Received)' : 'Udhaar (Given)'}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="px-6 py-4 text-center">
                      <div className="flex items-center justify-center space-x-2">
                        <button
                          onClick={() => handleShareWhatsApp(tx)}
                          className="p-1.5 rounded-lg bg-green-500/10 hover:bg-green-500/20 text-green-400 border border-green-500/20 transition"
                          title="Share WhatsApp Receipt"
                        >
                          <MessageCircle className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setSelectedTxForReceipt(tx)}
                          className="p-1.5 rounded-lg bg-[#1a1a1a] hover:bg-white/10 text-gray-300 border border-white/10 transition"
                          title="Print Digital Slip"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                      </div>
                    </td>

                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-gray-500">
                    No transactions match your search query.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* NEW TRANSACTION MODAL */}
      {isNewTxModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-xl rounded-2xl bg-[#161616] border border-white/10 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="px-6 py-4 bg-[#111111] border-b border-white/10 flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Plus className="w-5 h-5 text-blue-400" />
                <span>Nayi Transaction / Khata Entry</span>
              </h3>
              <button
                onClick={() => setIsNewTxModalOpen(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTransaction} className="p-6 space-y-4">
              
              {/* Type Switcher: GOT (Jama) vs GAVE (Udhaar) */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setTxType('GOT')}
                  className={`py-3 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 border transition ${
                    txType === 'GOT'
                      ? 'bg-green-500/20 text-green-300 border-green-500 shadow-md shadow-green-500/10'
                      : 'bg-[#111111] text-gray-400 border-white/10'
                  }`}
                >
                  <ArrowDownLeft className="w-4 h-4 text-green-400" />
                  <span>Payment Received (Jama)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setTxType('GAVE')}
                  className={`py-3 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 border transition ${
                    txType === 'GAVE'
                      ? 'bg-red-500/20 text-red-300 border-red-500 shadow-md shadow-red-500/10'
                      : 'bg-[#111111] text-gray-400 border-white/10'
                  }`}
                >
                  <ArrowUpRight className="w-4 h-4 text-red-400" />
                  <span>Credit Given (Udhaar / Sale)</span>
                </button>
              </div>

              {/* Customer Selector or Create */}
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">
                  Customer Select Karein
                </label>
                <select
                  value={selectedCustomerId}
                  onChange={(e) => setSelectedCustomerId(e.target.value)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="">-- Ya Naya Customer Niche Likhein --</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.phone || 'No phone'}) - Bal: {currentBusiness.currency} {c.currentBalance.toLocaleString()}
                    </option>
                  ))}
                </select>
              </div>

              {!selectedCustomerId && (
                <div className="grid grid-cols-2 gap-3 p-3.5 rounded-xl bg-white/5 border border-white/10">
                  <div>
                    <label className="block text-[11px] text-gray-400 mb-1">Naye Customer Ka Naam</label>
                    <input
                      type="text"
                      value={newCustomerName}
                      onChange={(e) => setNewCustomerName(e.target.value)}
                      placeholder="e.g. Usman Bhai"
                      className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-400 mb-1">Mobile / WhatsApp</label>
                    <input
                      type="text"
                      value={newCustomerPhone}
                      onChange={(e) => setNewCustomerPhone(e.target.value)}
                      placeholder="0300-1234567"
                      className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>
              )}

              {/* Amount & Category */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">
                    Amount ({currentBusiness.currency}) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="e.g. 50000"
                    className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm font-bold text-white font-mono focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">Payment Mode</label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value as any)}
                    className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="CASH">Cash in Hand</option>
                    <option value="ONLINE">Online / JazzCash / EasyPaisa</option>
                    <option value="BANK">Bank Transfer / Cheque</option>
                    <option value="CREDIT">Khata Credit / Udhaar</option>
                  </select>
                </div>
              </div>

              {/* Industry-specific dynamic fields */}
              {isJewellery && (
                <div className="p-3.5 rounded-xl bg-yellow-500/10 border border-yellow-500/30 grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-yellow-300 font-semibold mb-1">Gold Weight (Grams)</label>
                    <input
                      type="number"
                      step="0.001"
                      value={goldWeightGrams}
                      onChange={(e) => setGoldWeightGrams(e.target.value)}
                      placeholder="e.g. 11.664"
                      className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-yellow-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-yellow-300 font-semibold mb-1">Gold Karat</label>
                    <select
                      value={goldKarat}
                      onChange={(e) => setGoldKarat(e.target.value)}
                      className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-yellow-500"
                    >
                      <option value="24K">24K (Pure Gold)</option>
                      <option value="22K">22K (Sarafa Standard)</option>
                      <option value="21K">21K (Gulf / Arab Gold)</option>
                      <option value="18K">18K (Diamond Jewellery)</option>
                    </select>
                  </div>
                </div>
              )}

              {isProperty && (
                <div className="p-3.5 rounded-xl bg-blue-500/10 border border-blue-500/30">
                  <label className="block text-[11px] text-blue-300 font-semibold mb-1">Plot / File / Property Number</label>
                  <input
                    type="text"
                    value={propertyPlotNumber}
                    onChange={(e) => setPropertyPlotNumber(e.target.value)}
                    placeholder="e.g. Plot 412, Block B, DHA Phase 6"
                    className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              )}

              {/* Notes */}
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">
                  Details / Item Description (Tafseelat)
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Gold set advance payment, or suit stitched bill..."
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="pt-2 flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setIsNewTxModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider text-gray-300 bg-[#1a1a1a] hover:bg-white/5 border border-white/10"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider text-white bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-600/20 border border-white/10"
                >
                  Save to Digital Khata
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* PRINT RECEIPT SLIP PREVIEW MODAL */}
      {selectedTxForReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-2xl bg-[#161616] text-gray-100 p-6 border border-white/10 shadow-2xl space-y-4">
            <div className="flex justify-between items-start border-b border-white/10 pb-3">
              <div>
                <h3 className="font-bold text-lg text-white">{currentBusiness.name}</h3>
                <p className="text-xs text-gray-400">{currentBusiness.profile.categoryName} • {currentBusiness.city}</p>
              </div>
              <button
                onClick={() => setSelectedTxForReceipt(null)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-2 text-center border-b border-white/10">
              <span className="text-xs uppercase font-bold tracking-wider text-gray-500 block">Digital Khata Slip</span>
              <span className="text-2xl font-bold font-mono text-white mt-1 block">
                {currentBusiness.currency} {selectedTxForReceipt.amount.toLocaleString()}
              </span>
              <span className="text-xs font-semibold text-green-400">
                {selectedTxForReceipt.type === 'GOT' ? 'PAYMENT RECEIVED (JAMA)' : 'CREDIT SALE (UDHAAR)'}
              </span>
            </div>

            <div className="text-xs space-y-1.5 py-1 text-gray-300">
              <div className="flex justify-between">
                <span className="text-gray-400">Customer:</span>
                <span className="font-bold text-white">{selectedTxForReceipt.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Date:</span>
                <span className="font-mono">{new Date(selectedTxForReceipt.createdAt).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Payment Mode:</span>
                <span className="font-semibold text-white">{selectedTxForReceipt.paymentMode}</span>
              </div>
              {selectedTxForReceipt.notes && (
                <div className="flex justify-between">
                  <span className="text-gray-400">Notes:</span>
                  <span>{selectedTxForReceipt.notes}</span>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-white/10 flex items-center justify-between">
              <button
                onClick={() => window.print()}
                className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-wider flex items-center space-x-1.5 border border-white/10"
              >
                <Printer className="w-4 h-4" />
                <span>Print Slip</span>
              </button>
              <button
                onClick={() => handleShareWhatsApp(selectedTxForReceipt)}
                className="px-4 py-2.5 rounded-xl bg-green-600 hover:bg-green-500 text-white font-bold text-xs uppercase tracking-wider flex items-center space-x-1.5 shadow-lg shadow-green-600/20"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Send WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
