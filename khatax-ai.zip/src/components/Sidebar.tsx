import React from 'react';
import {
  LayoutDashboard,
  BookOpen,
  Users,
  Truck,
  Package,
  Building2,
  Gem,
  Shirt,
  HelpCircle,
  Calculator,
  BarChart3,
  Mic,
  ShieldCheck,
  Settings,
  Sparkles,
} from 'lucide-react';
import { Business } from '../types';

export type TabType =
  | 'dashboard'
  | 'khata'
  | 'customers'
  | 'suppliers'
  | 'inventory'
  | 'inquiries'
  | 'calculator'
  | 'reports'
  | 'voice_hub'
  | 'audit_logs'
  | 'settings';

interface SidebarProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  currentBusiness: Business;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  currentBusiness,
}) => {
  const isJewellery = currentBusiness.category === 'jewellery_gold' || currentBusiness.category === 'silver';
  const isProperty = currentBusiness.category === 'property_dealer' || currentBusiness.category === 'real_estate';
  const isClothing = currentBusiness.category === 'clothing_garments';

  const getInventoryLabel = () => {
    if (isJewellery) return 'Gold & Silver Vault';
    if (isProperty) return 'Property Portfolio';
    if (isClothing) return 'Garments & Sizes';
    return 'Products & Inventory';
  };

  const getInventoryIcon = () => {
    if (isJewellery) return <Gem className="w-4 h-4" />;
    if (isProperty) return <Building2 className="w-4 h-4" />;
    if (isClothing) return <Shirt className="w-4 h-4" />;
    return <Package className="w-4 h-4" />;
  };

  const navItems = [
    {
      id: 'dashboard' as TabType,
      label: 'Dashboard',
      icon: <LayoutDashboard className="w-4 h-4" />,
      badge: currentBusiness.profile.categoryName,
    },
    {
      id: 'khata' as TabType,
      label: 'Digital Khata',
      icon: <BookOpen className="w-4 h-4" />,
    },
    {
      id: 'customers' as TabType,
      label: 'Customers & Intel',
      icon: <Users className="w-4 h-4" />,
    },
    {
      id: 'suppliers' as TabType,
      label: 'Suppliers',
      icon: <Truck className="w-4 h-4" />,
    },
    {
      id: 'inventory' as TabType,
      label: getInventoryLabel(),
      icon: getInventoryIcon(),
      highlight: true,
    },
    {
      id: 'inquiries' as TabType,
      label: 'Smart Inquiries',
      icon: <HelpCircle className="w-4 h-4" />,
      badge: 'AI Memory',
    },
    {
      id: 'calculator' as TabType,
      label: 'Smart Calculator',
      icon: <Calculator className="w-4 h-4" />,
    },
    {
      id: 'voice_hub' as TabType,
      label: 'Xara Voice Hub',
      icon: <Mic className="w-4 h-4" />,
      badge: 'Voice AI',
    },
    {
      id: 'reports' as TabType,
      label: 'Reports & Statements',
      icon: <BarChart3 className="w-4 h-4" />,
    },
    {
      id: 'audit_logs' as TabType,
      label: 'Audit & AI Logs',
      icon: <ShieldCheck className="w-4 h-4" />,
    },
    {
      id: 'settings' as TabType,
      label: 'Rules & Settings',
      icon: <Settings className="w-4 h-4" />,
    },
  ];

  return (
    <aside className="w-64 bg-[#111111] border-r border-white/5 flex flex-col justify-between flex-shrink-0 h-[calc(100vh-4rem)] sticky top-16 overflow-y-auto">
      <div className="p-4 space-y-1">
        
        {/* Active Industry Badge */}
        <div className="px-3.5 py-2 mb-3 rounded-xl bg-[#161616] border border-white/10 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            <span className="text-xs font-semibold text-gray-200 truncate max-w-[120px]">
              {currentBusiness.profile.categoryName}
            </span>
          </div>
          <span className="text-[10px] font-mono font-bold uppercase bg-black/40 px-2 py-0.5 rounded text-gray-300 border border-white/5">
            {currentBusiness.currency}
          </span>
        </div>

        <div className="text-xs font-bold text-gray-500 uppercase px-3 py-2">
          Main Menu
        </div>

        {/* Navigation list */}
        <nav className="space-y-1">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`sidebar-tab-${item.id}`}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-medium transition-colors group ${
                  isActive
                    ? 'bg-white/5 text-blue-400 font-semibold border-l-2 border-blue-500 pl-3'
                    : 'text-gray-400 hover:text-gray-100 hover:bg-white/5 border-l-2 border-transparent pl-3'
                }`}
              >
                <div className="flex items-center space-x-3 truncate">
                  <span className={`${isActive ? 'text-blue-400' : 'text-gray-400 group-hover:text-gray-200'}`}>
                    {item.icon}
                  </span>
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[9px] px-2 py-0.5 rounded-full bg-[#1a1a1a] text-gray-400 font-semibold border border-white/10 truncate">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Voice Assistant bottom status card matching Design HTML */}
      <div className="p-4 mt-auto border-t border-white/5 bg-black/20">
        <div 
          onClick={() => onSelectTab('voice_hub')}
          className="flex items-center gap-3 p-3 bg-blue-500/10 rounded-xl border border-blue-500/20 cursor-pointer hover:bg-blue-500/15 transition-colors"
        >
          <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-lg shadow-lg shadow-blue-600/30 flex-shrink-0 text-white font-bold">
            👩
          </div>
          <div className="truncate">
            <div className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">
              Voice Agent
            </div>
            <div className="text-xs font-bold text-white truncate">
              Xara is active
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};
