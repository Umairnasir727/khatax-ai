import React from 'react';
import {
  Store,
  ChevronDown,
  Mic,
  MessageSquare,
  Calculator,
  Plus,
  Building2,
  Gem,
  Shirt,
  Pill,
  Sparkles,
  MapPin,
  Check,
} from 'lucide-react';
import { Business } from '../types';

interface NavbarProps {
  currentBusiness: Business;
  allBusinesses: Business[];
  onSelectBusiness: (business: Business) => void;
  onOpenNewBusinessModal: () => void;
  onOpenVoiceModal: () => void;
  onOpenAIChat: () => void;
  onOpenCalculator: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentBusiness,
  allBusinesses,
  onSelectBusiness,
  onOpenNewBusinessModal,
  onOpenVoiceModal,
  onOpenAIChat,
  onOpenCalculator,
}) => {
  const [dropdownOpen, setDropdownOpen] = React.useState(false);
  const dropdownRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getCategoryIcon = (cat: string) => {
    if (cat.includes('jewel') || cat.includes('silver')) return <Gem className="w-4 h-4 text-amber-400" />;
    if (cat.includes('property') || cat.includes('estate')) return <Building2 className="w-4 h-4 text-cyan-400" />;
    if (cat.includes('cloth')) return <Shirt className="w-4 h-4 text-pink-400" />;
    if (cat.includes('pharmacy')) return <Pill className="w-4 h-4 text-emerald-400" />;
    return <Store className="w-4 h-4 text-indigo-400" />;
  };

  return (
    <header className="sticky top-0 z-30 bg-[#111111] border-b border-white/5 text-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Brand & Business Switcher */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white shadow-lg shadow-blue-600/20 text-sm">
              K
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-semibold text-lg tracking-tight uppercase text-white">
                  KhataX <span className="text-blue-400">AI</span>
                </span>
                <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  v2.5
                </span>
              </div>
            </div>
          </div>

          <div className="h-6 w-px bg-white/10 hidden md:block" />

          {/* Business Switcher Dropdown */}
          <div className="relative" ref={dropdownRef}>
            <button
              id="business-switcher-btn"
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-[#1a1a1a] hover:bg-[#222222] border border-white/10 hover:border-white/20 transition text-sm text-left group"
            >
              <div className="p-1 rounded-full bg-white/5">
                {getCategoryIcon(currentBusiness.category)}
              </div>
              <div className="max-w-[130px] sm:max-w-[180px]">
                <span className="text-[10px] uppercase tracking-wider text-gray-400 block font-medium">
                  Business:
                </span>
                <span className="font-semibold text-white truncate block text-xs sm:text-sm">
                  {currentBusiness.name}
                </span>
              </div>
              <ChevronDown className={`w-3.5 h-3.5 text-gray-400 group-hover:text-white transition-transform duration-200 ${dropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {dropdownOpen && (
              <div className="absolute left-0 mt-2 w-72 rounded-2xl bg-[#161616] border border-white/10 shadow-2xl z-50 overflow-hidden py-1 divide-y divide-white/5 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3.5 py-2 text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Switch Workspace ({allBusinesses.length})
                </div>
                <div className="max-h-64 overflow-y-auto py-1">
                  {allBusinesses.map((biz) => {
                    const isSelected = biz.id === currentBusiness.id;
                    return (
                      <button
                        key={biz.id}
                        id={`biz-item-${biz.id}`}
                        onClick={() => {
                          onSelectBusiness(biz);
                          setDropdownOpen(false);
                        }}
                        className={`w-full px-3.5 py-2.5 flex items-center justify-between text-left transition hover:bg-white/5 ${
                          isSelected ? 'bg-blue-600/10 text-blue-400 font-semibold' : 'text-gray-300'
                        }`}
                      >
                        <div className="flex items-center space-x-2.5 truncate">
                          <div className="p-1.5 rounded-lg bg-[#111111] border border-white/10">
                            {getCategoryIcon(biz.category)}
                          </div>
                          <div className="truncate">
                            <p className="text-sm font-semibold truncate leading-tight text-white">
                              {biz.name}
                            </p>
                            <p className="text-[11px] text-gray-400 truncate">
                              {biz.profile.categoryName} • {biz.currency}
                            </p>
                          </div>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-blue-400 flex-shrink-0 ml-2" />}
                      </button>
                    );
                  })}
                </div>

                <div className="p-2">
                  <button
                    id="add-new-business-btn"
                    onClick={() => {
                      setDropdownOpen(false);
                      onOpenNewBusinessModal();
                    }}
                    className="w-full flex items-center justify-center space-x-2 py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-md transition"
                  >
                    <Plus className="w-4 h-4" />
                    <span>+ Add New Business</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Tools & Xara Voice CTA */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          
          {/* Quick Smart Calculator */}
          <button
            id="quick-calculator-btn"
            onClick={onOpenCalculator}
            className="p-2 px-3 rounded-xl bg-[#1a1a1a] hover:bg-white/5 text-gray-300 hover:text-white border border-white/10 transition hidden sm:flex items-center space-x-1.5 text-xs font-semibold uppercase tracking-wider"
            title="Industry Calculator"
          >
            <Calculator className="w-4 h-4 text-yellow-500" />
            <span>Calculator</span>
          </button>

          {/* AI Chat Drawer Button */}
          <button
            id="open-ai-chat-btn"
            onClick={onOpenAIChat}
            className="p-2 px-3 rounded-xl bg-[#1a1a1a] hover:bg-white/5 text-gray-300 hover:text-white border border-white/10 transition flex items-center space-x-1.5 text-xs font-semibold uppercase tracking-wider"
            title="Ask AI Business Brain"
          >
            <Sparkles className="w-4 h-4 text-blue-400" />
            <span className="hidden md:inline">AI Brain</span>
          </button>

          {/* Primary CTA: Talk to Xara Voice */}
          <button
            id="navbar-talk-to-xara-btn"
            onClick={onOpenVoiceModal}
            className="relative flex items-center space-x-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm uppercase tracking-wider shadow-lg shadow-blue-600/20 active:scale-95 transition-all group border border-white/10"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            <Mic className="w-4 h-4 group-hover:scale-110 transition-transform" />
            <span>Talk to Xara</span>
          </button>
        </div>

      </div>
    </header>
  );
};
