import React, { useState } from 'react';
import {
  Store,
  Gem,
  Building2,
  Shirt,
  Pill,
  Smartphone,
  Truck,
  Utensils,
  Wrench,
  Car,
  Sparkles,
  Layers,
  ArrowRight,
  CheckCircle2,
  Loader2,
  X,
  Sliders,
  DollarSign,
  MapPin,
  FileText,
} from 'lucide-react';
import { Business, BusinessRule } from '../types';
import { api } from '../services/api';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBusinessCreated: (newBiz: Business) => void;
}

interface CategoryOption {
  id: string;
  title: string;
  urduTitle: string;
  icon: React.ReactNode;
  description: string;
  samplePrompt: string;
}

const CATEGORY_OPTIONS: CategoryOption[] = [
  {
    id: 'jewellery_gold',
    title: 'Jewellery & Gold',
    urduTitle: 'سونے اور جیولری کا کاروبار',
    icon: <Gem className="w-5 h-5 text-amber-400" />,
    description: 'Gold/Silver tola & gram calculations, 24K/22K/18K karat rates, Sarafa making charges & wastage.',
    samplePrompt: 'Meri sarafa jewellery shop hai jahan 22K aur 24K gold ornaments, tola aur gram mein sell aur purchase hoti hain.',
  },
  {
    id: 'property_dealer',
    title: 'Property & Real Estate',
    urduTitle: 'پراپرٹی ڈیلر اور رئیل اسٹیٹ',
    icon: <Building2 className="w-5 h-5 text-cyan-400" />,
    description: 'Marla/Kanal rate calculations, plots, house files, token bayana & monthly installment schedules.',
    samplePrompt: 'Main real estate aur property consultancy karta hoon. Plots, files, bayana aur installment plans manage karne hain.',
  },
  {
    id: 'clothing_garments',
    title: 'Clothing & Garments',
    urduTitle: 'کپڑے، بوتیک اور ریڈی میڈ گارمنٹس',
    icon: <Shirt className="w-5 h-5 text-pink-400" />,
    description: 'Sizes (XS-XXL), fabric type, unstitched & stitched collections, color variants and customer advance.',
    samplePrompt: 'Hamara women clothing boutique aur ready-made garments store hai jahan sizes, fabric aur unstitched suit bikte hain.',
  },
  {
    id: 'general_store',
    title: 'General & Kiryana Store',
    urduTitle: 'جنرل و کریانہ اسٹور',
    icon: <Store className="w-5 h-5 text-emerald-400" />,
    description: 'Quick daily digital ledger, khata udhaar limits, supplier bills, item stock & wholesale rates.',
    samplePrompt: 'Main kiryana aur general retail store chalata hoon. Rozana ke customer udhaar aur supplier payments record karni hain.',
  },
  {
    id: 'pharmacy',
    title: 'Pharmacy & Medical',
    urduTitle: 'فارمیسی اور میڈیکل اسٹور',
    icon: <Pill className="w-5 h-5 text-teal-400" />,
    description: 'Medicine batches, expiry date tracking, distributor supplier ledger, doctor prescriptions & strip pricing.',
    samplePrompt: 'Medical store aur pharmacy ledger jahan distributor bills, batch expiry aur customer khata track ho.',
  },
  {
    id: 'mobile_electronics',
    title: 'Mobile & Electronics',
    urduTitle: 'موبائل اور الیکٹرانکس',
    icon: <Smartphone className="w-5 h-5 text-blue-400" />,
    description: 'IMEI tracking, warranty cards, mobile accessories, repair tickets & customer installment khata.',
    samplePrompt: 'Mobile accessories, smartphones aur electronics shop jahan IMEI tracking aur easy installments khata manage ho.',
  },
  {
    id: 'wholesale_distribution',
    title: 'Wholesale & Distribution',
    urduTitle: 'ہول سیل اور ڈسٹری بیوشن',
    icon: <Truck className="w-5 h-5 text-indigo-400" />,
    description: 'Bulk cartons, master packing, territory van delivery, supply chain invoices and recovery agents.',
    samplePrompt: 'FMCG distribution business hai jahan carton packaging aur market retailer credit ledger track karna hai.',
  },
  {
    id: 'restaurant_cafe',
    title: 'Restaurant & Cafe',
    urduTitle: 'ریستوران اور کیفے',
    icon: <Utensils className="w-5 h-5 text-amber-500" />,
    description: 'Raw kitchen ingredient purchases, vendor khata, catering booking advances and daily cash balances.',
    samplePrompt: 'Restaurant aur catering service jahan meat/vegetable vendor bills aur event catering booking advance track ho.',
  },
  {
    id: 'hardware_sanitary',
    title: 'Hardware & Sanitary',
    urduTitle: 'ہارڈ ویئر اور سینیٹری',
    icon: <Wrench className="w-5 h-5 text-slate-400" />,
    description: 'Pipe lengths, cement bags, sanitary fittings, contractor credit khata and bulk project billing.',
    samplePrompt: 'Sanitary fittings aur building hardware shop jahan plumbers aur contractors ka udhaar khata chalta hai.',
  },
  {
    id: 'custom_business',
    title: 'Custom / Other Industry',
    urduTitle: 'کوئی بھی دیگر کاروبار',
    icon: <Sparkles className="w-5 h-5 text-purple-400" />,
    description: 'KhataX AI will dynamically profile your unique workflow, units, terms & mathematical rules using Gemini AI.',
    samplePrompt: 'Mera auto workshop aur spare parts ka kaam hai.',
  },
];

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onClose,
  onBusinessCreated,
}) => {
  const [step, setStep] = useState<'SELECT' | 'DESCRIBE' | 'REVIEW'>('SELECT');
  const [selectedCategory, setSelectedCategory] = useState<string>('jewellery_gold');
  const [businessName, setBusinessName] = useState('');
  const [city, setCity] = useState('Lahore');
  const [currency, setCurrency] = useState('PKR');
  const [description, setDescription] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [analyzedProfile, setAnalyzedProfile] = useState<any>(null);

  if (!isOpen) return null;

  const handleSelectCategory = (cat: CategoryOption) => {
    setSelectedCategory(cat.id);
    if (!description) {
      setDescription(cat.samplePrompt);
    }
    if (!businessName) {
      if (cat.id === 'jewellery_gold') setBusinessName('Nagina Sarafa Jewellers');
      else if (cat.id === 'property_dealer') setBusinessName('Al-Madina Real Estate & Builders');
      else if (cat.id === 'clothing_garments') setBusinessName('Noor Fashion Boutique');
      else if (cat.id === 'general_store') setBusinessName('Bismillah Super Store');
      else setBusinessName('My Business Workspace');
    }
    setStep('DESCRIBE');
  };

  const handleRunAIAnalysis = async () => {
    if (!description.trim()) return;
    setIsAnalyzing(true);
    try {
      const profile = await api.analyzeBusinessDescription({
        description,
        category: selectedCategory,
        businessName: businessName || 'KhataX Workspace',
      });
      setAnalyzedProfile(profile);
      setStep('REVIEW');
    } catch (e) {
      console.error('Failed to analyze business:', e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleCreateBusiness = async () => {
    setIsCreating(true);
    try {
      const newBusiness = await api.createBusiness({
        name: businessName || analyzedProfile?.categoryName || 'New Business Khata',
        category: (analyzedProfile?.category || selectedCategory) as any,
        currency,
        city,
        profile: analyzedProfile || {
          category: selectedCategory,
          categoryName: businessName,
          primaryUnits: ['Piece', 'Item'],
          supportedTerms: ['Khata', 'Bill'],
          customFields: [],
          customCalculators: [],
          voicePromptsSuggestion: ['Khate mein entry karo'],
          industrySpecificModules: ['khata', 'customers', 'inventory'],
        },
      });

      onBusinessCreated(newBusiness);
      onClose();
    } catch (e) {
      console.error('Failed to create business:', e);
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        id="onboarding-business-modal"
        className="w-full max-w-3xl rounded-2xl bg-[#161616] border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="px-6 py-4 bg-[#111111] border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 font-bold text-lg shadow-lg shadow-blue-500/10">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Multi-Business Workspace Setup
              </h2>
              <p className="text-xs text-gray-400">
                Aap kis business ka khata manage karna chahte hain?
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator */}
        <div className="px-6 py-3 bg-[#111111] border-b border-white/5 flex items-center justify-between text-xs">
          <div className="flex items-center space-x-6">
            <button
              onClick={() => setStep('SELECT')}
              className={`flex items-center space-x-2 font-semibold ${
                step === 'SELECT' ? 'text-blue-400' : 'text-gray-400'
              }`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step === 'SELECT' ? 'bg-blue-600 text-white font-bold' : 'bg-white/5 text-gray-400'
              }`}>
                1
              </span>
              <span>Select Industry</span>
            </button>

            <ArrowRight className="w-3.5 h-3.5 text-gray-600" />

            <button
              onClick={() => setStep('DESCRIBE')}
              disabled={step === 'SELECT'}
              className={`flex items-center space-x-2 font-semibold ${
                step === 'DESCRIBE' ? 'text-blue-400' : 'text-gray-400 disabled:opacity-50'
              }`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step === 'DESCRIBE' ? 'bg-blue-600 text-white font-bold' : 'bg-white/5 text-gray-400'
              }`}>
                2
              </span>
              <span>Describe & Customize</span>
            </button>

            <ArrowRight className="w-3.5 h-3.5 text-gray-600" />

            <span className={`flex items-center space-x-2 font-semibold ${
              step === 'REVIEW' ? 'text-blue-400' : 'text-gray-500'
            }`}>
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step === 'REVIEW' ? 'bg-blue-600 text-white font-bold' : 'bg-white/5 text-gray-400'
              }`}>
                3
              </span>
              <span>AI Profiler Review</span>
            </span>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 flex-1 overflow-y-auto bg-[#161616]">
          
          {/* STEP 1: CATEGORY SELECTION */}
          {step === 'SELECT' && (
            <div className="space-y-4">
              <div className="text-center max-w-md mx-auto mb-4">
                <h3 className="text-lg font-extrabold text-white tracking-tight">
                  Choose your business type
                </h3>
                <p className="text-xs text-gray-400 mt-1">
                  KhataX AI will configure units (Tola/Marla/Sizes), vocabulary, calculations, and voice intelligence for your exact sector.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {CATEGORY_OPTIONS.map((cat) => (
                  <button
                    key={cat.id}
                    id={`onboarding-cat-${cat.id}`}
                    onClick={() => handleSelectCategory(cat)}
                    className="p-4 rounded-2xl bg-[#111111] hover:bg-white/[0.03] border border-white/5 hover:border-blue-500/50 transition-all text-left group flex items-start space-x-3.5"
                  >
                    <div className="p-2.5 rounded-xl bg-[#161616] border border-white/5 group-hover:scale-105 transition-transform flex-shrink-0">
                      {cat.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-bold text-gray-100 group-hover:text-blue-400 transition-colors">
                          {cat.title}
                        </h4>
                        <span className="text-[11px] font-medium text-gray-400 font-serif">
                          {cat.urduTitle}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400 mt-1 line-clamp-2 leading-relaxed">
                        {cat.description}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2: DESCRIBE BUSINESS */}
          {step === 'DESCRIBE' && (
            <div className="space-y-5 max-w-xl mx-auto">
              <div className="text-center">
                <h3 className="text-lg font-extrabold text-white tracking-tight">
                  Apna Business Detail Mein Batayein
                </h3>
                <p className="text-xs text-gray-400 mt-1">
                  Tell KhataX AI how your business operates. You can write in Roman Urdu or English.
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-gray-300 mb-1.5">
                    Business Name (Karobaar Ka Naam)
                  </label>
                  <input
                    type="text"
                    id="new-business-name-input"
                    value={businessName}
                    onChange={(e) => setBusinessName(e.target.value)}
                    placeholder="e.g. Al-Madina Jewellers, Royal Builders, etc."
                    className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-gray-300 mb-1.5">
                      City / Location
                    </label>
                    <input
                      type="text"
                      id="new-business-city-input"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="e.g. Lahore, Karachi, Islamabad"
                      className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-gray-300 mb-1.5">
                      Currency
                    </label>
                    <select
                      id="new-business-currency-select"
                      value={currency}
                      onChange={(e) => setCurrency(e.target.value)}
                      className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                    >
                      <option value="PKR">PKR (Rs.)</option>
                      <option value="USD">USD ($)</option>
                      <option value="AED">AED (AED)</option>
                      <option value="SAR">SAR (SAR)</option>
                      <option value="INR">INR (₹)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-gray-300 mb-1.5 flex items-center justify-between">
                    <span>Describe your workflow & items (AI Profiling Prompt)</span>
                    <span className="text-blue-400 font-normal text-[11px]">Gemini AI Engine</span>
                  </label>
                  <textarea
                    id="new-business-description-input"
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="e.g. Meri gold ki shop hai. Main 22 karat gold jewellery tola aur gram mein bechta hoon aur custom order par bridal sets banata hoon..."
                    className="w-full bg-[#111111] border border-white/10 rounded-xl p-3.5 text-xs text-white focus:outline-none focus:border-blue-500 leading-relaxed font-sans"
                  />
                  <p className="text-[11px] text-gray-400 mt-1">
                    Tip: Mention your custom units (Tolas, Marlalas, Meters, Strips), making charges, wastage, or token bayana terms.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: AI REVIEW */}
          {step === 'REVIEW' && analyzedProfile && (
            <div className="space-y-4 max-w-2xl mx-auto">
              <div className="p-4 rounded-2xl bg-green-500/10 border border-green-500/20 flex items-center space-x-3.5">
                <div className="p-2.5 rounded-xl bg-green-500 text-slate-950 font-bold">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-green-400">
                    AI Business Profile Synthesized
                  </span>
                  <h3 className="text-base font-extrabold text-white">
                    {analyzedProfile.categoryName} Workspace Ready
                  </h3>
                  <p className="text-xs text-gray-300 mt-0.5">
                    KhataX AI customized your digital ledger modules, math rules, and voice commands.
                  </p>
                </div>
              </div>

              {/* Units & Terminology */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-4 rounded-2xl bg-[#111111] border border-white/5">
                  <span className="text-[11px] uppercase tracking-wider text-gray-400 font-semibold block mb-2">
                    Configured Units & Dimensions
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {analyzedProfile.primaryUnits?.map((unit: string, i: number) => (
                      <span key={i} className="px-2.5 py-1 rounded-lg bg-[#161616] border border-white/10 text-green-400 text-xs font-semibold">
                        {unit}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-[#111111] border border-white/5">
                  <span className="text-[11px] uppercase tracking-wider text-gray-400 font-semibold block mb-2">
                    Industry Vocabulary
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {analyzedProfile.supportedTerms?.map((term: string, i: number) => (
                      <span key={i} className="px-2.5 py-1 rounded-lg bg-[#161616] border border-white/10 text-blue-400 text-xs font-medium">
                        {term}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Suggested Voice Prompts */}
              {analyzedProfile.voicePromptsSuggestion && (
                <div className="p-4 rounded-2xl bg-[#111111] border border-white/5">
                  <span className="text-[11px] uppercase tracking-wider text-gray-400 font-semibold block mb-2">
                    Xara Voice Assistant Auto-Tuned Prompts
                  </span>
                  <div className="space-y-1.5">
                    {analyzedProfile.voicePromptsSuggestion.map((prompt: string, i: number) => (
                      <div key={i} className="text-xs text-gray-300 flex items-center space-x-2 bg-[#161616] px-3 py-1.5 rounded-lg border border-white/5">
                        <Sparkles className="w-3 h-3 text-yellow-400 flex-shrink-0" />
                        <span>"{prompt}"</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer Navigation */}
        <div className="px-6 py-4 bg-[#111111] border-t border-white/5 flex items-center justify-between">
          {step !== 'SELECT' ? (
            <button
              onClick={() => setStep(step === 'REVIEW' ? 'DESCRIBE' : 'SELECT')}
              disabled={isAnalyzing || isCreating}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-gray-300 hover:text-white bg-[#161616] hover:bg-white/5 border border-white/10 transition"
            >
              Back
            </button>
          ) : <div />}

          <div className="flex items-center space-x-3">
            {step === 'DESCRIBE' && (
              <button
                id="run-ai-profiler-btn"
                onClick={handleRunAIAnalysis}
                disabled={isAnalyzing || !description.trim()}
                className="px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-600/20 flex items-center space-x-2 transition disabled:opacity-50"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Analyzing with Gemini AI...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Analyze & Adapt Workspace</span>
                  </>
                )}
              </button>
            )}

            {step === 'REVIEW' && (
              <button
                id="launch-workspace-btn"
                onClick={handleCreateBusiness}
                disabled={isCreating}
                className="px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-600/20 flex items-center space-x-2 transition disabled:opacity-50"
              >
                {isCreating ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    <span>Launching Workspace...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Create & Open Workspace</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
