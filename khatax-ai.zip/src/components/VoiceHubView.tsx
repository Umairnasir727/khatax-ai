import React, { useState } from 'react';
import {
  Mic,
  MicOff,
  Sparkles,
  Volume2,
  VolumeX,
  Play,
  RotateCcw,
  CheckCircle2,
  HelpCircle,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { Business, AIAction } from '../types';
import { api } from '../services/api';
import { voiceService } from '../services/voice';

interface VoiceHubViewProps {
  currentBusiness: Business;
  onActionProposed: (action: AIAction) => void;
}

export const VoiceHubView: React.FC<VoiceHubViewProps> = ({
  currentBusiness,
  onActionProposed,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [lastResponse, setLastResponse] = useState<string>('');
  const [lastAction, setLastAction] = useState<AIAction | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleStartRecording = () => {
    setTranscript('');
    setIsListening(true);
    voiceService.startListening(
      (liveTranscript, isFinal) => {
        setTranscript(liveTranscript);
        if (isFinal) {
          handleExecuteVoiceCommand(liveTranscript);
        }
      },
      (err) => {
        console.error('Voice hub error:', err);
        setIsListening(false);
      },
      () => {
        setIsListening(false);
      }
    );
  };

  const handleStopRecording = () => {
    voiceService.stopListening();
    setIsListening(false);
    if (transcript.trim()) {
      handleExecuteVoiceCommand(transcript);
    }
  };

  const handleExecuteVoiceCommand = async (command: string) => {
    if (!command.trim()) return;
    setIsProcessing(true);
    voiceService.stopListening();
    setIsListening(false);

    try {
      const res = await api.processVoiceTranscript(currentBusiness.id, command);
      setLastResponse(res.xaraSpokenResponse);
      setLastAction(res.actionProposal);

      voiceService.speak(res.xaraSpokenResponse, () => {
        if (res.actionProposal) {
          onActionProposed(res.actionProposal);
        }
      });
    } catch (e: any) {
      setLastResponse('Maazrat, command process nahi ho saki.');
    } finally {
      setIsProcessing(false);
    }
  };

  const sampleCategories = [
    {
      title: 'Digital Khata Commands',
      prompts: [
        'Ali ke khate mein 5000 jama karo',
        'Bilal ko 12000 ka udhaar diya',
        'Haji Sahib ka balance kitna hai?',
      ],
    },
    {
      title: 'Sales & Inventory Commands',
      prompts: [
        'Ayesha ko 2 tola 22 karat gold set sell kiya',
        'Customer ko 3 unstitched suit diye 8500 mein',
        'Stock mein kitne plots available hain?',
      ],
    },
    {
      title: 'Inquiry & Customer Intel',
      prompts: [
        'Ahmed ne 10 marla plot ki inquiry ki thi',
        'Sab se zyada shopping kisne ki?',
        'Konse customers ki payments pending hain?',
      ],
    },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Xara Voice AI Hub</h1>
            <span className="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
              Conversational Engine
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Voice-powered business assistant supporting Urdu, Roman Urdu & English dialects
          </p>
        </div>
      </div>

      {/* Main Interactive Stage */}
      <div className="rounded-2xl bg-[#161616] border border-white/5 p-8 shadow-2xl flex flex-col items-center justify-center text-center space-y-6 relative overflow-hidden">
        <div className="absolute w-96 h-96 rounded-full bg-blue-500/5 blur-3xl pointer-events-none" />

        <div className="max-w-md space-y-2 relative z-10">
          <span className="text-xs uppercase font-bold tracking-wider text-blue-400">
            {isListening ? '🎙 Sun rahi hoon... (Listening)' : isProcessing ? '✨ Processing with Gemini AI...' : 'Tap & Speak to Xara'}
          </span>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            "Ali ke khate mein 5000 jama karo"
          </h2>
          <p className="text-xs text-gray-400">
            Speak naturally in Urdu or English. Xara parses entities, calculates balances, and proposes confirmed ledger updates.
          </p>
        </div>

        {/* Big Mic Button */}
        <div className="relative z-10">
          {isListening && (
            <>
              <span className="absolute -inset-4 rounded-full border-2 border-red-500/40 animate-ping opacity-60 pointer-events-none" />
              <span className="absolute -inset-8 rounded-full border border-red-500/20 animate-pulse pointer-events-none" />
            </>
          )}

          <button
            id="voice-hub-main-mic"
            onClick={isListening ? handleStopRecording : handleStartRecording}
            className={`w-28 h-28 rounded-full flex items-center justify-center text-white shadow-2xl transition-all duration-300 cursor-pointer ${
              isListening
                ? 'bg-red-500 scale-110 shadow-red-500/50 animate-pulse'
                : 'bg-blue-600 hover:bg-blue-500 hover:scale-105 shadow-blue-600/30'
            }`}
          >
            {isListening ? <MicOff className="w-12 h-12" /> : <Mic className="w-12 h-12" />}
          </button>
        </div>

        {transcript && (
          <div className="p-3.5 rounded-xl bg-[#111111] border border-white/10 max-w-lg text-xs font-mono text-gray-200 relative z-10">
            "{transcript}"
          </div>
        )}

        {lastResponse && (
          <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/20 max-w-lg text-xs space-y-2 relative z-10">
            <span className="text-[10px] uppercase font-bold text-green-400 block">Xara Voice Response</span>
            <p className="text-white font-medium">{lastResponse}</p>
            {lastAction && (
              <button
                onClick={() => onActionProposed(lastAction)}
                className="mt-2 px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg transition"
              >
                Review Proposed Action →
              </button>
            )}
          </div>
        )}
      </div>

      {/* Preset Prompts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {sampleCategories.map((cat, idx) => (
          <div key={idx} className="p-5 rounded-2xl bg-[#161616] border border-white/5 shadow-xl space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400">{cat.title}</h3>
            <div className="space-y-2">
              {cat.prompts.map((p, pIdx) => (
                <button
                  key={pIdx}
                  onClick={() => handleExecuteVoiceCommand(p)}
                  className="w-full p-3 rounded-xl bg-[#111111] hover:bg-white/5 border border-white/5 text-left text-xs text-gray-300 hover:text-white transition flex items-center justify-between group"
                >
                  <span className="truncate">"{p}"</span>
                  <Play className="w-3.5 h-3.5 text-blue-400 group-hover:scale-110 transition-transform flex-shrink-0 ml-2" />
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
