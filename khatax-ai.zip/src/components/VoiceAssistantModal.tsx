import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  X,
  Sparkles,
  Send,
  RefreshCw,
  Loader2,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { Business, AIAction, XaraVoiceState, VoiceMessage } from '../types';
import { api } from '../services/api';
import { voiceService } from '../services/voice';

interface VoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBusiness: Business;
  onActionProposed: (action: AIAction) => void;
}

export const VoiceAssistantModal: React.FC<VoiceAssistantModalProps> = ({
  isOpen,
  onClose,
  currentBusiness,
  onActionProposed,
}) => {
  const [voiceState, setVoiceState] = useState<XaraVoiceState>('IDLE');
  const [transcript, setTranscript] = useState('');
  const [messages, setMessages] = useState<VoiceMessage[]>([
    {
      id: 'welcome_msg',
      sender: 'xara',
      text: `Ji, Assalam-o-Alaikum! Main Xara hoon — ${currentBusiness.name} ki AI Voice Assistant. Batayein, kis khata, sale ya inquiry ka kaam karna hai?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [manualInput, setManualInput] = useState('');
  const [isAudioMuted, setIsAudioMuted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      // Scroll to bottom
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isOpen, messages, voiceState]);

  if (!isOpen) return null;

  const handleStartListening = () => {
    setErrorMessage('');
    setTranscript('');
    setVoiceState('LISTENING');

    voiceService.startListening(
      (liveTranscript, isFinal) => {
        setTranscript(liveTranscript);
        if (isFinal && liveTranscript.trim().length > 0) {
          handleProcessVoiceInput(liveTranscript);
        }
      },
      (err) => {
        console.warn('Voice error:', err);
        setVoiceState('ERROR');
        setErrorMessage(typeof err === 'string' ? err : 'Microphone unavailable. You can click any sample command below or type.');
        voiceService.playTone('error');
      },
      () => {
        if (voiceState === 'LISTENING' && !transcript) {
          setVoiceState('IDLE');
        }
      }
    );
  };

  const handleStopListening = () => {
    voiceService.stopListening();
    if (transcript.trim().length > 0) {
      handleProcessVoiceInput(transcript);
    } else {
      setVoiceState('IDLE');
    }
  };

  const handleProcessVoiceInput = async (userInput: string) => {
    const text = userInput.trim();
    if (!text) return;

    voiceService.stopListening();
    setVoiceState('UNDERSTANDING');

    // Add user message
    const userMsg: VoiceMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, userMsg]);
    setTranscript('');

    try {
      const res = await api.processVoiceTranscript(currentBusiness.id, text);
      const xaraReply = res.xaraSpokenResponse || 'Samajh gaya!';
      const action = res.actionProposal;

      const xaraMsg: VoiceMessage = {
        id: `xar_${Date.now()}`,
        sender: 'xara',
        text: xaraReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        actionProposal: action,
      };

      setMessages((prev) => [...prev, xaraMsg]);

      // Speak response if not muted
      if (!isAudioMuted) {
        setVoiceState('SPEAKING');
        voiceService.speak(xaraReply, () => {
          if (action) {
            setVoiceState('CONFIRMING');
            onActionProposed(action);
          } else {
            setVoiceState('IDLE');
          }
        });
      } else {
        if (action) {
          setVoiceState('CONFIRMING');
          onActionProposed(action);
        } else {
          setVoiceState('IDLE');
        }
      }
    } catch (err: any) {
      setVoiceState('ERROR');
      setErrorMessage(err.message || 'Could not process audio.');
      voiceService.playTone('error');
    }
  };

  const handleSendManual = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualInput.trim()) {
      const val = manualInput;
      setManualInput('');
      handleProcessVoiceInput(val);
    }
  };

  const getOrbStyle = () => {
    switch (voiceState) {
      case 'LISTENING':
        return 'scale-110 shadow-blue-500/50 bg-gradient-to-tr from-blue-600 via-blue-500 to-indigo-500 animate-pulse border border-blue-400';
      case 'UNDERSTANDING':
        return 'scale-105 shadow-blue-500/50 bg-gradient-to-tr from-blue-600 via-indigo-600 to-blue-400 animate-spin border border-blue-400';
      case 'CONFIRMING':
        return 'scale-105 shadow-amber-500/50 bg-gradient-to-tr from-amber-500 via-orange-500 to-yellow-400 border border-amber-400';
      case 'SPEAKING':
        return 'scale-110 shadow-blue-500/60 bg-gradient-to-tr from-blue-500 via-indigo-500 to-blue-400 animate-pulse border border-blue-300';
      case 'ERROR':
        return 'shadow-red-500/40 bg-gradient-to-tr from-red-600 to-red-700 border border-red-500';
      default:
        return 'shadow-blue-500/20 bg-[#1a1a1a] hover:bg-blue-600/30 border border-white/10';
    }
  };

  const getStatusLabel = () => {
    switch (voiceState) {
      case 'LISTENING':
        return 'Sun rahi hoon... (Listening)';
      case 'UNDERSTANDING':
        return 'Samajh rahi hoon... (Understanding Intent)';
      case 'CONFIRMING':
        return 'Confirmation Mang rahi hoon... (Confirming)';
      case 'SPEAKING':
        return 'Xara bol rahi hain... (Speaking)';
      case 'ERROR':
        return 'Kuch masla hua (Error)';
      default:
        return 'Ready • Click Mic or Speak';
    }
  };

  const samplePrompts = currentBusiness.profile.voicePromptsSuggestion || [
    'Ali ke khate mein 5000 jama karo',
    'Ayesha ko black suit sell kiya 3500 ka',
    'Ahmed ne kya inquiry ki thi?',
    'Total business outstanding kitna hai?',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        id="xara-voice-assistant-modal"
        className="w-full max-w-2xl rounded-2xl bg-[#161616] border border-white/10 shadow-2xl overflow-hidden flex flex-col h-[640px] max-h-[90vh] animate-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="px-6 py-4 bg-[#111111] border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-blue-600/20 border border-blue-500/40 p-0.5 flex items-center justify-center">
                <div className="w-full h-full rounded-full bg-[#111111] flex items-center justify-center font-bold text-xs text-blue-400">
                  XR
                </div>
              </div>
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-green-500 border-2 border-[#111111]" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-white tracking-wide">Xara Voice Assistant</h3>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  Active in {currentBusiness.name}
                </span>
              </div>
              <p className="text-[11px] text-gray-400">
                Natural Urdu, Roman Urdu & English Business Intelligence
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                setIsAudioMuted(!isAudioMuted);
                if (!isAudioMuted) voiceService.stopSpeaking();
              }}
              className={`p-2 rounded-xl border transition ${
                isAudioMuted
                  ? 'bg-red-500/10 border-red-500/30 text-red-400'
                  : 'bg-white/5 border-white/10 text-gray-300 hover:text-white'
              }`}
              title={isAudioMuted ? 'Unmute Xara Voice' : 'Mute Xara Voice'}
            >
              {isAudioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <button
              onClick={() => {
                voiceService.stopListening();
                voiceService.stopSpeaking();
                onClose();
              }}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/10 transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Center Animated Voice Orb Stage */}
        <div className="px-6 py-5 bg-gradient-to-b from-[#111111] to-[#161616] border-b border-white/5 flex flex-col items-center justify-center relative overflow-hidden">
          {/* Animated Background rings */}
          <div className="absolute w-72 h-72 rounded-full bg-blue-600/5 blur-3xl pointer-events-none" />

          {/* Sound wave visualizer bars */}
          <div className="h-10 flex items-center justify-center gap-1.5 mb-3">
            <div className={`w-1 bg-blue-500 rounded-full transition-all duration-150 ${voiceState === 'LISTENING' || voiceState === 'SPEAKING' ? 'h-6 animate-pulse' : 'h-2 opacity-30'}`}></div>
            <div className={`w-1 bg-blue-400 rounded-full transition-all duration-150 ${voiceState === 'LISTENING' || voiceState === 'SPEAKING' ? 'h-8 animate-bounce' : 'h-3 opacity-30'}`}></div>
            <div className={`w-1 bg-blue-600 rounded-full transition-all duration-150 ${voiceState === 'LISTENING' || voiceState === 'SPEAKING' ? 'h-10 animate-pulse' : 'h-4 opacity-30'}`}></div>
            <div className={`w-1 bg-blue-300 rounded-full transition-all duration-150 ${voiceState === 'LISTENING' || voiceState === 'SPEAKING' ? 'h-7 animate-bounce' : 'h-2 opacity-30'}`}></div>
            <div className={`w-1 bg-blue-500 rounded-full transition-all duration-150 ${voiceState === 'LISTENING' || voiceState === 'SPEAKING' ? 'h-5 animate-pulse' : 'h-3 opacity-30'}`}></div>
          </div>

          <div className="relative mb-3 flex items-center justify-center">
            {voiceState === 'LISTENING' && (
              <>
                <span className="absolute w-28 h-28 rounded-full border border-blue-500/40 animate-ping opacity-60 pointer-events-none" />
                <span className="absolute w-36 h-36 rounded-full border border-blue-400/30 animate-pulse pointer-events-none" />
              </>
            )}
            
            <button
              id="xara-main-mic-orb"
              onClick={voiceState === 'LISTENING' ? handleStopListening : handleStartListening}
              className={`w-20 h-20 rounded-full flex items-center justify-center text-white shadow-2xl transition-all duration-300 cursor-pointer ${getOrbStyle()}`}
            >
              {voiceState === 'LISTENING' ? (
                <MicOff className="w-8 h-8" />
              ) : voiceState === 'UNDERSTANDING' ? (
                <Loader2 className="w-8 h-8 animate-spin" />
              ) : (
                <Mic className="w-8 h-8 text-blue-400" />
              )}
            </button>
          </div>

          <div className="text-center">
            <span className="text-xs font-bold tracking-widest uppercase text-blue-400 block">
              {getStatusLabel()}
            </span>
            {transcript && (
              <p className="text-xs text-gray-200 mt-1 font-mono italic bg-white/5 px-3 py-1 rounded-full border border-white/10 max-w-md truncate">
                "{transcript}"
              </p>
            )}
          </div>
        </div>

        {/* Conversation Stream */}
        <div className="flex-1 p-6 overflow-y-auto space-y-3.5 bg-[#111111]">
          {messages.map((msg) => {
            const isXara = msg.sender === 'xara';
            return (
              <div
                key={msg.id}
                className={`flex items-start space-x-2.5 ${isXara ? '' : 'flex-row-reverse space-x-reverse'}`}
              >
                {isXara ? (
                  <div className="w-7 h-7 rounded-full bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-[10px] font-bold text-blue-400 flex-shrink-0 mt-0.5">
                    X
                  </div>
                ) : (
                  <div className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center text-[10px] font-bold text-gray-300 flex-shrink-0 mt-0.5">
                    You
                  </div>
                )}

                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-xs leading-relaxed ${
                    isXara
                      ? 'bg-white/5 text-gray-200 border border-white/10 rounded-tl-none shadow-sm'
                      : 'bg-blue-600 text-white rounded-tr-none shadow-md'
                  }`}
                >
                  <p>{msg.text}</p>
                  
                  {msg.actionProposal && (
                    <div className="mt-2.5 pt-2 border-t border-white/10 flex items-center justify-between">
                      <span className="text-[10px] text-yellow-500 font-bold flex items-center space-x-1 uppercase tracking-wider">
                        <Sparkles className="w-3 h-3" />
                        <span>Action proposal generated</span>
                      </span>
                      <button
                        onClick={() => onActionProposed(msg.actionProposal!)}
                        className="px-2.5 py-1 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 font-bold text-[10px] uppercase tracking-wider border border-blue-500/30 transition"
                      >
                        Review Card
                      </button>
                    </div>
                  )}

                  <span className={`text-[9px] mt-1 block font-mono ${isXara ? 'text-gray-500' : 'text-blue-200'}`}>
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            );
          })}
          
          {errorMessage && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-300 text-xs flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Sample Voice Prompts for this business */}
        <div className="px-6 py-2.5 bg-[#161616] border-t border-white/5 overflow-x-auto">
          <div className="flex items-center space-x-2 whitespace-nowrap">
            <span className="text-[10px] uppercase font-bold text-gray-500 flex-shrink-0 flex items-center space-x-1 tracking-wider">
              <Sparkles className="w-3 h-3 text-blue-400" />
              <span>Demo Prompts:</span>
            </span>
            {samplePrompts.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handleProcessVoiceInput(prompt)}
                className="text-[11px] px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/5 transition flex-shrink-0"
              >
                "{prompt}"
              </button>
            ))}
          </div>
        </div>

        {/* Bottom Input bar (Mic toggle + Keyboard input) */}
        <div className="p-4 bg-[#111111] border-t border-white/10">
          <form onSubmit={handleSendManual} className="flex items-center space-x-2">
            <button
              type="button"
              id="voice-mic-input-trigger"
              onClick={voiceState === 'LISTENING' ? handleStopListening : handleStartListening}
              className={`p-2.5 rounded-xl text-white font-bold transition ${
                voiceState === 'LISTENING'
                  ? 'bg-red-600 hover:bg-red-500 animate-pulse'
                  : 'bg-blue-600 hover:bg-blue-500'
              }`}
              title={voiceState === 'LISTENING' ? 'Stop Listening' : 'Speak Voice Command'}
            >
              {voiceState === 'LISTENING' ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            <input
              type="text"
              id="voice-manual-text-input"
              value={manualInput}
              onChange={(e) => setManualInput(e.target.value)}
              placeholder="Or type voice command in Urdu/English (e.g. Ali ke khate mein 5000 jama karo)..."
              className="flex-1 bg-[#161616] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-gray-100 placeholder-gray-500 focus:outline-none focus:border-blue-500 transition"
            />

            <button
              type="submit"
              disabled={!manualInput.trim()}
              className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white transition"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};
