import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  Printer,
  Download,
  Calendar,
  DollarSign,
  TrendingUp,
  Users,
  FileText,
  MessageCircle,
  Sparkles,
  ArrowUpRight,
  ArrowDownLeft,
} from 'lucide-react';
import { Business, Customer, Transaction } from '../types';
import { api } from '../services/api';

interface ReportsViewProps {
  currentBusiness: Business;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ currentBusiness }) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [reportRange, setReportRange] = useState<'TODAY' | 'THIS_MONTH' | 'ALL_TIME'>('THIS_MONTH');

  const loadData = async () => {
    try {
      const [custList, txList] = await Promise.all([
        api.getCustomers(currentBusiness.id),
        api.getTransactions(currentBusiness.id),
      ]);
      setCustomers(custList);
      setTransactions(txList);
    } catch (e) {
      console.error('Failed to load reports data:', e);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentBusiness.id]);

  const totalReceived = transactions.filter((t) => t.type === 'GOT').reduce((s, t) => s + t.amount, 0);
  const totalGiven = transactions.filter((t) => t.type === 'GAVE').reduce((s, t) => s + t.amount, 0);
  const totalReceivable = customers.reduce((s, c) => s + Math.max(0, c.currentBalance), 0);

  // Top Customer Ranking
  const rankedCustomers = [...customers].sort((a, b) => (b.totalPurchases || 0) - (a.totalPurchases || 0));

  const handlePrintReport = () => {
    window.print();
  };

  const handleShareSummaryWhatsApp = () => {
    const text =
      `*KhataX AI Business Summary - ${currentBusiness.name}*\n` +
      `---------------------------------\n` +
      `Category: ${currentBusiness.profile.categoryName}\n` +
      `Total Received (Jama): ${currentBusiness.currency} ${totalReceived.toLocaleString()}\n` +
      `Total Given (Udhaar): ${currentBusiness.currency} ${totalGiven.toLocaleString()}\n` +
      `Outstanding Receivables: ${currentBusiness.currency} ${totalReceivable.toLocaleString()}\n` +
      `Active Customer Accounts: ${customers.length}\n` +
      `---------------------------------\n` +
      `_Generated automatically by KhataX AI_`;
    const encoded = encodeURIComponent(text);
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Reports & Statements</h1>
            <span className="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
              Financial Summary
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Audit-ready business balance sheets, receivables aging & top customer ranking
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={handleShareSummaryWhatsApp}
            className="flex items-center space-x-1.5 px-3.5 py-2.5 rounded-xl bg-green-600 hover:bg-green-500 text-white font-bold text-xs shadow-md transition"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Share via WhatsApp</span>
          </button>

          <button
            onClick={handlePrintReport}
            className="flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-200 hover:text-white border border-white/10 font-bold text-xs transition"
          >
            <Printer className="w-4 h-4" />
            <span>Print Statement</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-[#161616] border border-white/5 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-gray-400 text-xs font-bold uppercase tracking-wider">
            <span>Total Cash Received</span>
            <div className="p-1.5 rounded-lg bg-green-500/10 text-green-400">
              <ArrowDownLeft className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-extrabold text-green-400 font-mono">
            {currentBusiness.currency} {totalReceived.toLocaleString()}
          </p>
          <p className="text-[11px] text-gray-500">Collected from all transactions</p>
        </div>

        <div className="p-5 rounded-2xl bg-[#161616] border border-white/5 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-gray-400 text-xs font-bold uppercase tracking-wider">
            <span>Outstanding Udhaar / Receivables</span>
            <div className="p-1.5 rounded-lg bg-red-500/10 text-red-400">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-extrabold text-red-400 font-mono">
            {currentBusiness.currency} {totalReceivable.toLocaleString()}
          </p>
          <p className="text-[11px] text-gray-500">Pending customer recovery</p>
        </div>

        <div className="p-5 rounded-2xl bg-[#161616] border border-white/5 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-gray-400 text-xs font-bold uppercase tracking-wider">
            <span>Net Financial Health</span>
            <div className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-extrabold text-white font-mono">
            {currentBusiness.currency} {(totalReceived - totalGiven).toLocaleString()}
          </p>
          <p className="text-[11px] text-gray-500">Overall cash flow balance</p>
        </div>
      </div>

      {/* Customer Ranking & Ledger Statement Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Top Customer Ranking (1 col) */}
        <div className="rounded-2xl bg-[#161616] border border-white/5 p-6 space-y-4 shadow-xl">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide">Top Valued Customers</h3>
              <p className="text-[11px] text-gray-400">Ranked by transaction volume</p>
            </div>
          </div>

          <div className="divide-y divide-white/5">
            {rankedCustomers.map((cust, idx) => (
              <div key={cust.id} className="py-3 flex items-center justify-between text-xs">
                <div className="flex items-center space-x-3">
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] ${
                    idx === 0 ? 'bg-blue-600 text-white' : idx === 1 ? 'bg-white/20 text-white' : 'bg-white/5 text-gray-400'
                  }`}>
                    {idx + 1}
                  </span>
                  <div>
                    <h4 className="font-bold text-white">{cust.name}</h4>
                    <p className="text-[10px] text-gray-500 font-mono">{cust.phone}</p>
                  </div>
                </div>

                <div className="text-right font-mono">
                  <span className="font-bold text-gray-200 block">
                    {currentBusiness.currency} {(cust.totalPurchases || 0).toLocaleString()}
                  </span>
                  <span className={`text-[10px] font-bold ${cust.currentBalance > 0 ? 'text-red-400' : 'text-green-400'}`}>
                    Bal: {currentBusiness.currency} {cust.currentBalance.toLocaleString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Formal Printable Statement Sheet (2 cols) */}
        <div className="lg:col-span-2 rounded-2xl bg-[#161616] border border-white/5 p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide">Complete Business Ledger Statement</h3>
              <p className="text-xs text-gray-400">{currentBusiness.name} • All-time records</p>
            </div>
            <span className="text-[10px] font-mono text-gray-400 bg-white/5 px-2.5 py-1 rounded-md border border-white/5">
              Total {transactions.length} Entries
            </span>
          </div>

          <div className="overflow-x-auto max-h-96">
            <table className="w-full text-left text-xs text-gray-300">
              <thead className="text-[10px] uppercase font-bold text-gray-400 bg-[#111111] sticky top-0 border-b border-white/5 tracking-wider font-mono">
                <tr>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3">Customer</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3 text-right">Debit (Udhaar)</th>
                  <th className="px-4 py-3 text-right">Credit (Jama)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono">
                {transactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-white/5 transition-colors">
                    <td className="px-4 py-3 text-gray-400 font-sans text-xs">
                      {new Date(tx.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3 font-semibold text-white font-sans text-xs">
                      {tx.customerName}
                    </td>
                    <td className="px-4 py-3 text-gray-400 font-sans text-xs">
                      {tx.category}
                    </td>
                    <td className="px-4 py-3 text-right font-bold text-red-400">
                      {tx.type === 'GAVE' ? `${currentBusiness.currency} ${tx.amount.toLocaleString()}` : '-'}
                    </td>
                    <td className="px-4 py-3 text-right font-bold text-green-400">
                      {tx.type === 'GOT' ? `${currentBusiness.currency} ${tx.amount.toLocaleString()}` : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>

    </div>
  );
};
