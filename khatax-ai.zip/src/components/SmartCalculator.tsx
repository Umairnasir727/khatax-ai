import React, { useState, useEffect } from 'react';
import {
  Calculator,
  Gem,
  Building2,
  Percent,
  Sparkles,
  ArrowRight,
  RotateCcw,
  CheckCircle2,
  DollarSign,
  Plus,
} from 'lucide-react';
import { Business, AIAction } from '../types';

interface SmartCalculatorProps {
  currentBusiness: Business;
  onOpenNewTransaction: () => void;
}

export const SmartCalculator: React.FC<SmartCalculatorProps> = ({
  currentBusiness,
  onOpenNewTransaction,
}) => {
  const isJewellery = currentBusiness.category === 'jewellery_gold' || currentBusiness.category === 'silver';
  const isProperty = currentBusiness.category === 'property_dealer' || currentBusiness.category === 'real_estate';

  const [activeTab, setActiveTab] = useState<'GOLD' | 'PROPERTY' | 'MARGIN'>(
    isJewellery ? 'GOLD' : isProperty ? 'PROPERTY' : 'MARGIN'
  );

  // --- GOLD CALCULATOR STATE ---
  const goldRate24kDefault = currentBusiness.rules.find((r) => r.key === 'gold_rate_24k')?.value || 248000;
  const tolaGramDefault = currentBusiness.rules.find((r) => r.key === 'tola_in_grams')?.value || 11.664;

  const [goldWeightInputType, setGoldWeightInputType] = useState<'GRAMS' | 'TOLAS'>('GRAMS');
  const [grossWeight, setGrossWeight] = useState<number>(15.5);
  const [stoneWeightGrams, setStoneWeightGrams] = useState<number>(0.5);
  const [karat, setKarat] = useState<'24K' | '22K' | '21K' | '18K'>('22K');
  const [makingCharges, setMakingCharges] = useState<number>(4500);
  const [wastageGrams, setWastageGrams] = useState<number>(0.2);
  const [goldRate24k, setGoldRate24k] = useState<number>(goldRate24kDefault);

  // --- PROPERTY CALCULATOR STATE ---
  const [propertyUnitType, setPropertyUnitType] = useState<'MARLA' | 'KANAL' | 'SQFT'>('MARLA');
  const [propertySize, setPropertySize] = useState<number>(10);
  const [ratePerMarla, setRatePerMarla] = useState<number>(1850000);
  const [commissionPercent, setCommissionPercent] = useState<number>(1);
  const [tokenBayanaPercent, setTokenBayanaPercent] = useState<number>(10);
  const [installmentMonths, setInstallmentMonths] = useState<number>(24);
  const [downPaymentPercent, setDownPaymentPercent] = useState<number>(20);

  // --- MARGIN CALCULATOR STATE ---
  const [costPrice, setCostPrice] = useState<number>(5000);
  const [markupPercent, setMarkupPercent] = useState<number>(30);
  const [discountPercent, setDiscountPercent] = useState<number>(5);

  // --- GOLD CALCULATOR MATH ---
  const actualWeightGrams =
    goldWeightInputType === 'GRAMS' ? grossWeight : grossWeight * tolaGramDefault;
  const netGoldGrams = Math.max(0, actualWeightGrams - stoneWeightGrams);
  const netTolas = netGoldGrams / tolaGramDefault;

  const karatMultiplier =
    karat === '24K' ? 1 : karat === '22K' ? 22 / 24 : karat === '21K' ? 21 / 24 : 18 / 24;

  const effectiveRatePerGram = (goldRate24k * karatMultiplier) / tolaGramDefault;
  const goldMetalCost = (netGoldGrams + wastageGrams) * effectiveRatePerGram;
  const totalGoldPrice = Math.round(goldMetalCost + makingCharges);

  // --- PROPERTY CALCULATOR MATH ---
  const totalMarlas =
    propertyUnitType === 'MARLA'
      ? propertySize
      : propertyUnitType === 'KANAL'
      ? propertySize * 20
      : propertySize / 225;

  const totalSqFt = totalMarlas * 225;
  const totalPropertyPrice = Math.round(totalMarlas * ratePerMarla);
  const commissionAmount = Math.round(totalPropertyPrice * (commissionPercent / 100));
  const tokenBayanaAmount = Math.round(totalPropertyPrice * (tokenBayanaPercent / 100));
  const downPaymentAmount = Math.round(totalPropertyPrice * (downPaymentPercent / 100));
  const remainingForInstallments = totalPropertyPrice - downPaymentAmount;
  const monthlyInstallment =
    installmentMonths > 0 ? Math.round(remainingForInstallments / installmentMonths) : 0;

  // --- MARGIN CALCULATOR MATH ---
  const calculatedSelling = Math.round(costPrice * (1 + markupPercent / 100));
  const discountedSelling = Math.round(calculatedSelling * (1 - discountPercent / 100));
  const netProfit = discountedSelling - costPrice;
  const profitMarginPercent = discountedSelling > 0 ? ((netProfit / discountedSelling) * 100).toFixed(1) : '0';

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Smart Industry Calculator</h1>
            <span className="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
              Live Formula Engine
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Instant mathematical breakdowns according to Sarafa and Real Estate industry rules
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center space-x-2 bg-[#161616] p-1.5 rounded-xl border border-white/5 self-start sm:self-auto shadow-lg">
          <button
            onClick={() => setActiveTab('GOLD')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              activeTab === 'GOLD'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Gem className="w-4 h-4" />
            <span>Sarafa Gold</span>
          </button>

          <button
            onClick={() => setActiveTab('PROPERTY')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              activeTab === 'PROPERTY'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>Property & Plots</span>
          </button>

          <button
            onClick={() => setActiveTab('MARGIN')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              activeTab === 'MARGIN'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Percent className="w-4 h-4" />
            <span>Margin & Discount</span>
          </button>
        </div>
      </div>

      {/* SARAFA GOLD CALCULATOR TAB */}
      {activeTab === 'GOLD' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Inputs (2 cols) */}
          <div className="lg:col-span-2 rounded-2xl bg-[#161616] border border-white/5 p-6 space-y-5 shadow-xl">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Gem className="w-5 h-5 text-yellow-400" />
                <span>Sarafa Gold Valuation Parameters</span>
              </h3>
              <span className="text-xs text-gray-400 font-mono">1 Tola = {tolaGramDefault}g</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              
              {/* Gross Weight */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-semibold text-gray-300">Gross Weight (Wazan)</label>
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => setGoldWeightInputType('GRAMS')}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        goldWeightInputType === 'GRAMS' ? 'bg-yellow-500 text-black' : 'bg-white/5 text-gray-400'
                      }`}
                    >
                      Grams
                    </button>
                    <button
                      onClick={() => setGoldWeightInputType('TOLAS')}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        goldWeightInputType === 'TOLAS' ? 'bg-yellow-500 text-black' : 'bg-white/5 text-gray-400'
                      }`}
                    >
                      Tolas
                    </button>
                  </div>
                </div>
                <input
                  type="number"
                  step="0.001"
                  value={grossWeight}
                  onChange={(e) => setGrossWeight(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm font-bold text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              {/* Stone / Bead Deduction */}
              <div>
                <label className="block font-semibold text-gray-300 mb-1.5">
                  Stone / Nagena Deduction (Grams)
                </label>
                <input
                  type="number"
                  step="0.001"
                  value={stoneWeightGrams}
                  onChange={(e) => setStoneWeightGrams(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              {/* Karat Selection */}
              <div>
                <label className="block font-semibold text-gray-300 mb-1.5">
                  Karat Purity Standard
                </label>
                <select
                  value={karat}
                  onChange={(e) => setKarat(e.target.value as any)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="24K">24K (100% Pure Gold)</option>
                  <option value="22K">22K (91.6% Sarafa Ornaments)</option>
                  <option value="21K">21K (87.5% Gulf Gold)</option>
                  <option value="18K">18K (75.0% Diamond Sets)</option>
                </select>
              </div>

              {/* Live 24K Sarafa Rate */}
              <div>
                <label className="block font-semibold text-gray-300 mb-1.5">
                  Sarafa Rate 24K / Tola ({currentBusiness.currency})
                </label>
                <input
                  type="number"
                  value={goldRate24k}
                  onChange={(e) => setGoldRate24k(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm font-bold text-yellow-400 focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              {/* Making Charges */}
              <div>
                <label className="block font-semibold text-gray-300 mb-1.5">
                  Making Charges / Mazdoori ({currentBusiness.currency})
                </label>
                <input
                  type="number"
                  value={makingCharges}
                  onChange={(e) => setMakingCharges(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              {/* Wastage */}
              <div>
                <label className="block font-semibold text-gray-300 mb-1.5">
                  Wastage (Khat / Ratti in Grams)
                </label>
                <input
                  type="number"
                  step="0.001"
                  value={wastageGrams}
                  onChange={(e) => setWastageGrams(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

            </div>
          </div>

          {/* Breakdown & Bill Preview (1 col) */}
          <div className="rounded-2xl bg-[#161616] border border-white/5 p-6 space-y-5 shadow-xl flex flex-col justify-between">
            <div className="space-y-4">
              <span className="text-xs uppercase font-bold text-yellow-400 tracking-wider block">
                Sarafa Price Breakdown
              </span>

              <div className="space-y-2 text-xs divide-y divide-white/5">
                <div className="flex justify-between py-1.5">
                  <span className="text-gray-400">Net Gold Weight:</span>
                  <span className="font-bold text-white font-mono">{netGoldGrams.toFixed(3)} g ({netTolas.toFixed(3)} Tola)</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-gray-400">Karat Multiplier:</span>
                  <span className="font-mono text-gray-300">{karat} ({(karatMultiplier * 100).toFixed(1)}%)</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-gray-400">Pure Gold Metal Value:</span>
                  <span className="font-bold text-gray-200 font-mono">
                    {currentBusiness.currency} {Math.round(goldMetalCost).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-gray-400">Making Charges:</span>
                  <span className="font-mono text-gray-300">
                    {currentBusiness.currency} {makingCharges.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#111111] border border-yellow-500/20 text-center">
                <span className="text-[11px] uppercase font-bold text-yellow-400 block tracking-wider">
                  Final Sarafa Quotation / Price
                </span>
                <span className="text-2xl font-black text-yellow-300 mt-1 block font-mono">
                  {currentBusiness.currency} {totalGoldPrice.toLocaleString()}
                </span>
              </div>
            </div>

            <button
              onClick={onOpenNewTransaction}
              className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition active:scale-95 flex items-center justify-center space-x-2"
            >
              <Plus className="w-4 h-4" />
              <span>Record Sale in Khata</span>
            </button>
          </div>

        </div>
      )}

      {/* PROPERTY CALCULATOR TAB */}
      {activeTab === 'PROPERTY' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Inputs (2 cols) */}
          <div className="lg:col-span-2 rounded-2xl bg-[#161616] border border-white/5 p-6 space-y-5 shadow-xl">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Building2 className="w-5 h-5 text-blue-400" />
                <span>Property Dimensions & Installment Schedule</span>
              </h3>
              <span className="text-xs text-gray-400 font-mono">1 Marla = 225 Sq. Ft.</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              
              {/* Unit Selection & Size */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-semibold text-gray-300">Property Area / Size</label>
                  <div className="flex items-center space-x-1">
                    {['MARLA', 'KANAL', 'SQFT'].map((u) => (
                      <button
                        key={u}
                        onClick={() => setPropertyUnitType(u as any)}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          propertyUnitType === u ? 'bg-blue-600 text-white' : 'bg-white/5 text-gray-400'
                        }`}
                      >
                        {u}
                      </button>
                    ))}
                  </div>
                </div>
                <input
                  type="number"
                  step="any"
                  value={propertySize}
                  onChange={(e) => setPropertySize(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm font-bold text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              {/* Rate per Marla */}
              <div>
                <label className="block font-semibold text-gray-300 mb-1.5">
                  Rate Per Marla ({currentBusiness.currency})
                </label>
                <input
                  type="number"
                  value={ratePerMarla}
                  onChange={(e) => setRatePerMarla(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm font-bold text-blue-400 focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              {/* Token Bayana % */}
              <div>
                <label className="block font-semibold text-gray-300 mb-1.5">
                  Token Bayana Advance (% of Total)
                </label>
                <input
                  type="number"
                  value={tokenBayanaPercent}
                  onChange={(e) => setTokenBayanaPercent(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              {/* Brokerage Commission % */}
              <div>
                <label className="block font-semibold text-gray-300 mb-1.5">
                  Dealer Commission / Brokerage (%)
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={commissionPercent}
                  onChange={(e) => setCommissionPercent(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              {/* Down Payment % */}
              <div>
                <label className="block font-semibold text-gray-300 mb-1.5">
                  Down Payment (% for Installments)
                </label>
                <input
                  type="number"
                  value={downPaymentPercent}
                  onChange={(e) => setDownPaymentPercent(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              {/* Installment Duration Months */}
              <div>
                <label className="block font-semibold text-gray-300 mb-1.5">
                  Installment Plan Duration (Months)
                </label>
                <input
                  type="number"
                  value={installmentMonths}
                  onChange={(e) => setInstallmentMonths(parseInt(e.target.value) || 1)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

            </div>
          </div>

          {/* Breakdown (1 col) */}
          <div className="rounded-2xl bg-[#161616] border border-white/5 p-6 space-y-5 shadow-xl flex flex-col justify-between">
            <div className="space-y-4">
              <span className="text-xs uppercase font-bold text-blue-400 tracking-wider block">
                Deal & Financial Breakdown
              </span>

              <div className="space-y-2 text-xs divide-y divide-white/5">
                <div className="flex justify-between py-1.5">
                  <span className="text-gray-400">Total Area:</span>
                  <span className="font-bold text-white font-mono">{totalMarlas} Marlas ({totalSqFt.toLocaleString()} Sq.Ft)</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-gray-400">Total Plot Value:</span>
                  <span className="font-extrabold text-blue-400 font-mono">
                    {currentBusiness.currency} {totalPropertyPrice.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-gray-400">Token Bayana ({tokenBayanaPercent}%):</span>
                  <span className="font-bold text-yellow-300 font-mono">
                    {currentBusiness.currency} {tokenBayanaAmount.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-gray-400">Dealer Brokerage ({commissionPercent}%):</span>
                  <span className="font-bold text-green-400 font-mono">
                    {currentBusiness.currency} {commissionAmount.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#111111] border border-blue-500/20 text-center space-y-1">
                <span className="text-[11px] uppercase font-bold text-blue-300 block tracking-wider">
                  Monthly Installment ({installmentMonths} Months)
                </span>
                <span className="text-2xl font-black text-blue-400 block font-mono">
                  {currentBusiness.currency} {monthlyInstallment.toLocaleString()} / mo
                </span>
                <span className="text-[10px] text-gray-400 block font-mono">
                  After Down Payment of {currentBusiness.currency} {downPaymentAmount.toLocaleString()}
                </span>
              </div>
            </div>

            <button
              onClick={onOpenNewTransaction}
              className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition active:scale-95 flex items-center justify-center space-x-2"
            >
              <Plus className="w-4 h-4" />
              <span>Record Bayana / Booking in Khata</span>
            </button>
          </div>

        </div>
      )}

      {/* MARGIN & DISCOUNT TAB */}
      {activeTab === 'MARGIN' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 rounded-2xl bg-[#161616] border border-white/5 p-6 space-y-5 shadow-xl">
            <h3 className="text-base font-bold text-white border-b border-white/5 pb-3">
              Retail Profit Margin & Discount Optimizer
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block font-semibold text-gray-300 mb-1.5">
                  Cost Price ({currentBusiness.currency})
                </label>
                <input
                  type="number"
                  value={costPrice}
                  onChange={(e) => setCostPrice(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm font-bold text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-gray-300 mb-1.5">
                  Markup (% Profit Added)
                </label>
                <input
                  type="number"
                  value={markupPercent}
                  onChange={(e) => setMarkupPercent(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-gray-300 mb-1.5">
                  Discount Offered (%)
                </label>
                <input
                  type="number"
                  value={discountPercent}
                  onChange={(e) => setDiscountPercent(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>
            </div>
          </div>

          <div className="rounded-2xl bg-[#161616] border border-white/5 p-6 space-y-4 shadow-xl flex flex-col justify-between">
            <div className="space-y-3">
              <span className="text-xs font-bold text-green-400 uppercase tracking-wider">Profit Analysis</span>
              <div className="p-4 rounded-xl bg-[#111111] border border-green-500/20 text-center">
                <span className="text-[11px] text-gray-400 block">Final Selling Price</span>
                <span className="text-2xl font-black text-white mt-0.5 block font-mono">
                  {currentBusiness.currency} {discountedSelling.toLocaleString()}
                </span>
                <span className="text-xs font-bold text-green-400 mt-1 block font-mono">
                  Net Profit: {currentBusiness.currency} {netProfit.toLocaleString()} ({profitMarginPercent}% Margin)
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
