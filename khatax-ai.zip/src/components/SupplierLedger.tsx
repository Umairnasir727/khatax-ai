import React, { useState, useEffect } from 'react';
import {
  Truck,
  Plus,
  Search,
  Phone,
  MapPin,
  ArrowUpRight,
  ArrowDownLeft,
  X,
  FileText,
  DollarSign,
} from 'lucide-react';
import { Business, Supplier } from '../types';
import { api } from '../services/api';

interface SupplierLedgerProps {
  currentBusiness: Business;
}

export const SupplierLedger: React.FC<SupplierLedgerProps> = ({ currentBusiness }) => {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form
  const [name, setName] = useState('');
  const [company, setCompany] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [category, setCategory] = useState('');
  const [balance, setBalance] = useState('');

  const loadSuppliers = async () => {
    try {
      const list = await api.getSuppliers(currentBusiness.id);
      setSuppliers(list);
    } catch (e) {
      console.error('Failed to load suppliers:', e);
    }
  };

  useEffect(() => {
    loadSuppliers();
  }, [currentBusiness.id]);

  const handleCreateSupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    await api.createSupplier({
      businessId: currentBusiness.id,
      name: name.trim(),
      company: company.trim(),
      phone: phone.trim() || '0300-0000000',
      city: city.trim() || currentBusiness.city,
      category: category.trim() || 'General Supply',
      currentBalance: parseFloat(balance) || 0,
    });

    setIsAddModalOpen(false);
    setName('');
    setCompany('');
    setPhone('');
    setBalance('');
    loadSuppliers();
  };

  const filteredSuppliers = suppliers.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.company && s.company.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const totalPayable = suppliers.reduce((sum, s) => sum + (s.currentBalance || 0), 0);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Suppliers & Payables</h1>
            <span className="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
              Vendor Khata
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Manage raw material vendors, wholesale dealers & payable bills
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Add Supplier / Vendor</span>
        </button>
      </div>

      {/* Summary KPI */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-[#161616] border border-white/5 shadow-xl">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Total Payables (Den-daar)</span>
          <p className="text-2xl font-extrabold text-red-400 mt-1 font-mono">
            {currentBusiness.currency} {totalPayable.toLocaleString()}
          </p>
          <span className="text-[11px] text-gray-500">Owed to suppliers</span>
        </div>

        <div className="p-5 rounded-2xl bg-[#161616] border border-white/5 shadow-xl">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Active Suppliers</span>
          <p className="text-2xl font-extrabold text-white mt-1 font-mono">{suppliers.length}</p>
          <span className="text-[11px] text-gray-500">Registered vendors</span>
        </div>

        <div className="p-5 rounded-2xl bg-[#161616] border border-white/5 shadow-xl">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Supply Category</span>
          <p className="text-2xl font-extrabold text-blue-400 mt-1">{currentBusiness.profile.categoryName}</p>
          <span className="text-[11px] text-gray-500">Stock procurement</span>
        </div>
      </div>

      {/* Search & List */}
      <div className="rounded-2xl bg-[#161616] border border-white/5 p-6 space-y-4 shadow-xl">
        <div className="relative max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search supplier by name or company..."
            className="w-full bg-[#111111] border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredSuppliers.length > 0 ? (
            filteredSuppliers.map((sup) => (
              <div key={sup.id} className="p-4 rounded-xl bg-[#111111] border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-sm">
                      <Truck className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">{sup.name}</h4>
                      <p className="text-xs text-gray-400">{sup.company || 'Direct Supplier'}</p>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-gray-300 font-medium border border-white/5">
                    {sup.category || 'Vendor'}
                  </span>
                </div>

                <div className="text-xs text-gray-400 space-y-1 pt-2 border-t border-white/5">
                  <div className="flex justify-between">
                    <span>Phone:</span>
                    <span className="text-gray-200 font-medium font-mono">{sup.phone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>City:</span>
                    <span className="text-gray-200">{sup.city || 'Local'}</span>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-[#161616] border border-white/5 flex justify-between items-center text-xs font-mono">
                  <span className="text-gray-400 font-sans">Balance to Pay:</span>
                  <span className={`font-bold ${sup.currentBalance > 0 ? 'text-red-400' : 'text-green-400'}`}>
                    {currentBusiness.currency} {sup.currentBalance.toLocaleString()}
                  </span>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-3 py-8 text-center text-gray-500 text-xs">
              No suppliers found. Click "+ Add Supplier" to register vendor accounts.
            </div>
          )}
        </div>
      </div>

      {/* ADD SUPPLIER MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-2xl bg-[#161616] border border-white/10 shadow-2xl overflow-hidden p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-bold text-white text-base">Add Supplier / Vendor</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-gray-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSupplier} className="space-y-3 text-xs">
              <div>
                <label className="block text-gray-300 font-semibold mb-1">Supplier Contact Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Aslam Bullion or Master Textiles"
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1">Company / Firm Name</label>
                <input
                  type="text"
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  placeholder="e.g. Lahore Bullion Traders"
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-gray-300 font-semibold mb-1">Phone</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="0300-1234567"
                    className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-gray-300 font-semibold mb-1">Starting Balance</label>
                  <input
                    type="number"
                    value={balance}
                    onChange={(e) => setBalance(e.target.value)}
                    placeholder="0"
                    className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-gray-300 bg-white/5 hover:bg-white/10 border border-white/10 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-white font-bold bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-600/20"
                >
                  Save Supplier
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
