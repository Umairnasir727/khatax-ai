import React, { useState } from 'react';
import {
  Settings,
  Save,
  Plus,
  Trash2,
  Sparkles,
  CheckCircle2,
  Sliders,
  DollarSign,
  Building2,
  Gem,
} from 'lucide-react';
import { Business, BusinessRule } from '../types';
import { api } from '../services/api';

interface SettingsViewProps {
  currentBusiness: Business;
  onBusinessUpdated: (updated: Business) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  currentBusiness,
  onBusinessUpdated,
}) => {
  const [rules, setRules] = useState<BusinessRule[]>(currentBusiness.rules || []);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // New Rule
  const [newRuleKey, setNewRuleKey] = useState('');
  const [newRuleLabel, setNewRuleLabel] = useState('');
  const [newRuleValue, setNewRuleValue] = useState('');
  const [newRuleUnit, setNewRuleUnit] = useState('');

  const handleRuleValueChange = (index: number, val: any) => {
    const updated = [...rules];
    updated[index].value = isNaN(Number(val)) ? val : Number(val);
    setRules(updated);
  };

  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRuleKey.trim() || !newRuleLabel.trim()) return;

    const newRule: BusinessRule = {
      key: newRuleKey.trim().toLowerCase().replace(/\s+/g, '_'),
      label: newRuleLabel.trim(),
      value: isNaN(Number(newRuleValue)) ? newRuleValue : Number(newRuleValue),
      unit: newRuleUnit.trim(),
      category: 'CUSTOM',
    };

    setRules((prev) => [...prev, newRule]);
    setNewRuleKey('');
    setNewRuleLabel('');
    setNewRuleValue('');
    setNewRuleUnit('');
  };

  const handleDeleteRule = (index: number) => {
    setRules((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSaveAll = async () => {
    setIsSaving(true);
    try {
      const updated = await api.updateBusinessRules(currentBusiness.id, rules);
      onBusinessUpdated(updated);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (e) {
      console.error('Failed to save settings:', e);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Business Rules & Settings</h1>
            <span className="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
              Adaptive Config
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Configure industry conversion standards, live metal rates, marla dimensions & custom logic
          </p>
        </div>

        <button
          onClick={handleSaveAll}
          disabled={isSaving}
          className="flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition active:scale-95 disabled:opacity-50"
        >
          {saveSuccess ? (
            <>
              <CheckCircle2 className="w-4 h-4 text-white" />
              <span>Rules Saved Successfully!</span>
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'Saving...' : 'Save Configuration'}</span>
            </>
          )}
        </button>
      </div>

      {/* Business Meta Info */}
      <div className="rounded-2xl bg-[#161616] border border-white/5 p-6 space-y-4 shadow-xl">
        <h3 className="text-base font-bold text-white flex items-center space-x-2">
          <Settings className="w-5 h-5 text-blue-400" />
          <span>Active Business Profile</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-[#111111] border border-white/5">
            <span className="text-gray-400 uppercase font-bold text-[10px] block tracking-wider">Business Name</span>
            <span className="text-sm font-bold text-white mt-1 block">{currentBusiness.name}</span>
          </div>

          <div className="p-4 rounded-xl bg-[#111111] border border-white/5">
            <span className="text-gray-400 uppercase font-bold text-[10px] block tracking-wider">Industry Category</span>
            <span className="text-sm font-bold text-blue-400 mt-1 block">
              {currentBusiness.profile.categoryName}
            </span>
          </div>

          <div className="p-4 rounded-xl bg-[#111111] border border-white/5">
            <span className="text-gray-400 uppercase font-bold text-[10px] block tracking-wider">Base Currency & City</span>
            <span className="text-sm font-bold text-white mt-1 block">
              {currentBusiness.currency} • {currentBusiness.city}
            </span>
          </div>
        </div>
      </div>

      {/* Live Business Rules Table */}
      <div className="rounded-2xl bg-[#161616] border border-white/5 p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center space-x-2">
              <Sliders className="w-5 h-5 text-blue-400" />
              <span>Conversion Rates & Mathematical Formulas</span>
            </h3>
            <p className="text-xs text-gray-400">Values used by Xara Voice AI and Smart Calculators</p>
          </div>
        </div>

        <div className="space-y-3">
          {rules.map((rule, idx) => (
            <div
              key={rule.key || idx}
              className="p-4 rounded-xl bg-[#111111] border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
            >
              <div className="space-y-0.5">
                <span className="font-bold text-white text-sm">{rule.label}</span>
                <p className="text-[11px] text-gray-500 font-mono">key: {rule.key}</p>
              </div>

              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    step="any"
                    value={rule.value}
                    onChange={(e) => handleRuleValueChange(idx, e.target.value)}
                    className="w-36 bg-[#161616] border border-white/10 rounded-xl px-3 py-1.5 text-sm font-bold text-blue-400 focus:outline-none focus:border-blue-500 font-mono"
                  />
                  {rule.unit && (
                    <span className="text-xs text-gray-400 font-semibold">{rule.unit}</span>
                  )}
                </div>

                <button
                  onClick={() => handleDeleteRule(idx)}
                  className="p-2 rounded-xl text-gray-500 hover:text-red-400 hover:bg-white/5 transition"
                  title="Remove rule"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Add New Custom Rule Form */}
        <div className="pt-4 border-t border-white/10">
          <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
            + Add Custom Business Rule
          </h4>
          <form onSubmit={handleAddRule} className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
            <input
              type="text"
              required
              value={newRuleLabel}
              onChange={(e) => setNewRuleLabel(e.target.value)}
              placeholder="Rule Label (e.g. Silver Rate / Tola)"
              className="bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-blue-500"
            />
            <input
              type="text"
              required
              value={newRuleKey}
              onChange={(e) => setNewRuleKey(e.target.value)}
              placeholder="Unique Key (e.g. silver_rate)"
              className="bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none font-mono focus:border-blue-500"
            />
            <input
              type="number"
              step="any"
              required
              value={newRuleValue}
              onChange={(e) => setNewRuleValue(e.target.value)}
              placeholder="Value (e.g. 2850)"
              className="bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none font-mono font-bold focus:border-blue-500"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-blue-400 font-bold border border-white/10 transition"
            >
              + Add Rule
            </button>
          </form>
        </div>

      </div>

    </div>
  );
};
