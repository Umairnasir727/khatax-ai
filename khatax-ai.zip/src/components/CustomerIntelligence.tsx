import React, { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Plus,
  Phone,
  MapPin,
  Sparkles,
  ArrowRight,
  TrendingUp,
  MessageCircle,
  Clock,
  CheckCircle2,
  AlertTriangle,
  X,
  FileText,
  DollarSign,
  HelpCircle,
} from 'lucide-react';
import { Business, Customer, Transaction, Inquiry } from '../types';
import { api } from '../services/api';

interface CustomerIntelligenceProps {
  currentBusiness: Business;
  onOpenVoiceModal: () => void;
}

export const CustomerIntelligence: React.FC<CustomerIntelligenceProps> = ({
  currentBusiness,
  onOpenVoiceModal,
}) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [customerIntel, setCustomerIntel] = useState<any>(null);
  const [customerTxList, setCustomerTxList] = useState<Transaction[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isLoadingIntel, setIsLoadingIntel] = useState(false);

  // Form State
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');

  const loadCustomers = async () => {
    try {
      const list = await api.getCustomers(currentBusiness.id);
      setCustomers(list);
      if (list.length > 0 && !selectedCustomer) {
        handleSelectCustomer(list[0]);
      }
    } catch (e) {
      console.error('Failed to load customers:', e);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, [currentBusiness.id]);

  const handleSelectCustomer = async (cust: Customer) => {
    setSelectedCustomer(cust);
    setIsLoadingIntel(true);
    try {
      const [intel, txs] = await Promise.all([
        api.getCustomerIntelligence(cust.id),
        api.getTransactions(currentBusiness.id, cust.id),
      ]);
      setCustomerIntel(intel);
      setCustomerTxList(txs);
    } catch (e) {
      console.error('Failed to load customer intel:', e);
    } finally {
      setIsLoadingIntel(false);
    }
  };

  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const created = await api.createCustomer({
      businessId: currentBusiness.id,
      name: name.trim(),
      phone: phone.trim() || '0300-0000000',
      city: city.trim() || currentBusiness.city,
      address: address.trim(),
      notes: notes.trim(),
      currentBalance: 0,
      tags: ['Regular'],
    });

    setIsAddModalOpen(false);
    setName('');
    setPhone('');
    setAddress('');
    setNotes('');
    await loadCustomers();
    handleSelectCustomer(created);
  };

  const handleSendWhatsAppReminder = (cust: Customer) => {
    const text =
      `*Assalam-o-Alaikum ${cust.name} Bhai*\n\n` +
      `Yeh *${currentBusiness.name}* ki taraf se ledger update message hai.\n` +
      `Aapke khate ka baqaya balance: *${currentBusiness.currency} ${cust.currentBalance.toLocaleString()}* hai.\n\n` +
      `Baraye meherbani payment clear kar dein ya koi sawal ho to rabta karein.\n` +
      `Shukriya!\n_KhataX AI Platform_`;
    const encoded = encodeURIComponent(text);
    window.open(`https://api.whatsapp.com/send?phone=${cust.phone.replace(/[^0-9]/g, '')}&text=${encoded}`, '_blank');
  };

  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.includes(searchQuery) ||
      (c.city && c.city.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Customer Intelligence</h1>
            <span className="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
              AI Profiles
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Deep insights into customer buying behavior, trust scores & ledger history
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Naya Customer Add Karein</span>
        </button>
      </div>

      {/* 2-Column Split: Customer Directory + Intelligence Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Customer Directory (1 Col) */}
        <div className="rounded-2xl bg-[#161616] border border-white/5 p-4 space-y-4 shadow-xl flex flex-col h-[700px]">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search customer name, phone..."
              className="w-full bg-[#111111] border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
            {filteredCustomers.length > 0 ? (
              filteredCustomers.map((cust) => {
                const isSelected = selectedCustomer?.id === cust.id;
                return (
                  <button
                    key={cust.id}
                    onClick={() => handleSelectCustomer(cust)}
                    className={`w-full p-3 rounded-xl text-left transition flex items-center justify-between border ${
                      isSelected
                        ? 'bg-blue-600/10 border-blue-500/40 shadow-md'
                        : 'bg-[#111111] hover:bg-white/5 border-white/5'
                    }`}
                  >
                    <div className="flex items-center space-x-3 truncate">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs flex-shrink-0 ${
                        isSelected ? 'bg-blue-600 text-white' : 'bg-white/5 text-gray-300'
                      }`}>
                        {cust.name.charAt(0)}
                      </div>
                      <div className="truncate">
                        <h4 className="text-xs font-bold text-white truncate">{cust.name}</h4>
                        <p className="text-[11px] text-gray-400 truncate font-mono">{cust.phone}</p>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0 ml-2 font-mono">
                      <span className={`text-xs font-bold block ${
                        cust.currentBalance > 0 ? 'text-red-400' : 'text-green-400'
                      }`}>
                        {currentBusiness.currency} {cust.currentBalance.toLocaleString()}
                      </span>
                      <span className="text-[9px] text-gray-500 font-sans">
                        {cust.currentBalance > 0 ? 'Udhaar' : 'Clear'}
                      </span>
                    </div>
                  </button>
                );
              })
            ) : (
              <div className="text-center py-8 text-gray-500 text-xs">
                No customer found.
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Deep Customer Intelligence (2 Cols) */}
        <div className="lg:col-span-2 rounded-2xl bg-[#161616] border border-white/5 p-6 space-y-6 shadow-xl overflow-y-auto custom-scrollbar">
          {selectedCustomer ? (
            <>
              {/* Customer Hero Card */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-[#111111] border border-white/5">
                <div className="flex items-center space-x-4">
                  <div className="w-14 h-14 rounded-2xl bg-blue-600 flex items-center justify-center text-xl font-black text-white shadow-lg shadow-blue-600/20">
                    {selectedCustomer.name.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h2 className="text-lg font-extrabold text-white">{selectedCustomer.name}</h2>
                      <span className="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                        Active Account
                      </span>
                    </div>
                    <div className="flex items-center space-x-3 text-xs text-gray-400 mt-1">
                      <span className="flex items-center space-x-1 font-mono">
                        <Phone className="w-3.5 h-3.5 text-gray-500" />
                        <span>{selectedCustomer.phone}</span>
                      </span>
                      {selectedCustomer.city && (
                        <span className="flex items-center space-x-1">
                          <MapPin className="w-3.5 h-3.5 text-gray-500" />
                          <span>{selectedCustomer.city}</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2 self-end sm:self-center">
                  <button
                    onClick={() => handleSendWhatsAppReminder(selectedCustomer)}
                    className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-green-600 hover:bg-green-500 text-white text-xs font-bold transition shadow-md"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>WhatsApp Reminder</span>
                  </button>
                </div>
              </div>

              {/* Financial Metrics Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-4 rounded-xl bg-[#111111] border border-white/5">
                  <span className="text-[10px] uppercase tracking-wider text-gray-400 font-bold block">
                    Current Balance (Udhaar)
                  </span>
                  <span className={`text-xl font-extrabold mt-1 block font-mono ${
                    selectedCustomer.currentBalance > 0 ? 'text-red-400' : 'text-green-400'
                  }`}>
                    {currentBusiness.currency} {selectedCustomer.currentBalance.toLocaleString()}
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-[#111111] border border-white/5">
                  <span className="text-[10px] uppercase tracking-wider text-gray-400 font-bold block">
                    Total Lifetime Volume
                  </span>
                  <span className="text-xl font-extrabold text-blue-400 mt-1 block font-mono">
                    {currentBusiness.currency} {(customerIntel?.lifetimeVolume || selectedCustomer.totalPurchases || 0).toLocaleString()}
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-[#111111] border border-white/5 col-span-2 sm:col-span-1">
                  <span className="text-[10px] uppercase tracking-wider text-gray-400 font-bold block">
                    Khata Transactions
                  </span>
                  <span className="text-xl font-extrabold text-white mt-1 block font-mono">
                    {customerTxList.length} Entries
                  </span>
                </div>
              </div>

              {/* AI Deep Analysis Box */}
              <div className="p-5 rounded-2xl bg-[#111111] border border-blue-500/20 space-y-2">
                <div className="flex items-center space-x-2 text-blue-400 text-xs font-bold uppercase tracking-wider">
                  <Sparkles className="w-4 h-4" />
                  <span>Gemini AI Customer Behavioral Profile</span>
                </div>
                <p className="text-xs sm:text-sm text-gray-300 leading-relaxed font-sans">
                  {customerIntel?.aiSummary ||
                    `${selectedCustomer.name} is a valued client of ${currentBusiness.name}. Ledger shows regular transaction settlement.`}
                </p>
              </div>

              {/* Transaction History Table for this customer */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-gray-400" />
                  <span>Statement / Transaction History</span>
                </h3>

                <div className="divide-y divide-white/5 rounded-2xl bg-[#111111] border border-white/5 overflow-hidden">
                  {customerTxList.length > 0 ? (
                    customerTxList.map((tx) => (
                      <div key={tx.id} className="p-3.5 flex items-center justify-between hover:bg-white/5 text-xs">
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                              tx.type === 'GOT' ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'
                            }`}>
                              {tx.type === 'GOT' ? 'Payment (+)' : 'Udhaar (-)'}
                            </span>
                            <span className="font-semibold text-white">{tx.category || 'Khata Entry'}</span>
                          </div>
                          {tx.notes && <p className="text-[11px] text-gray-400 mt-0.5">{tx.notes}</p>}
                        </div>

                        <div className="text-right font-mono">
                          <span className={`font-bold ${tx.type === 'GOT' ? 'text-green-400' : 'text-red-400'}`}>
                            {currentBusiness.currency} {tx.amount.toLocaleString()}
                          </span>
                          <span className="text-[10px] text-gray-500 block font-sans">
                            {new Date(tx.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="py-6 text-center text-gray-500 text-xs">
                      No transaction history recorded yet for this customer.
                    </div>
                  )}
                </div>
              </div>

            </>
          ) : (
            <div className="py-20 text-center text-gray-500 text-xs">
              Select a customer to view their AI profile.
            </div>
          )}
        </div>

      </div>

      {/* ADD NEW CUSTOMER MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-2xl bg-[#161616] border border-white/10 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="px-6 py-4 bg-[#111111] border-b border-white/10 flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Users className="w-5 h-5 text-blue-400" />
                <span>Naya Customer Add Karein</span>
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-gray-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-gray-300 font-semibold mb-1">Customer Name (Naam) *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Haji Rasheed Sahib"
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1">Phone / WhatsApp Number</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="0300-1234567"
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-gray-300 font-semibold mb-1">City / Sheher</label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Lahore"
                    className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-gray-300 font-semibold mb-1">Area / Address</label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Gulberg III"
                    className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1">Notes / Preferences</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Customer preference notes (e.g. Buys 22K bridal sets or interested in commercial plots)"
                  className="w-full bg-[#111111] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="pt-2 flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-gray-300 bg-white/5 hover:bg-white/10 border border-white/10 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-white font-bold bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-600/20"
                >
                  Save Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
