import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Search,
  Clock,
  Sparkles,
  User,
  CheckCircle2,
  AlertTriangle,
  FileCode,
} from 'lucide-react';
import { Business, AuditLog } from '../types';
import { api } from '../services/api';

interface AuditLogsViewProps {
  currentBusiness: Business;
}

export const AuditLogsView: React.FC<AuditLogsViewProps> = ({ currentBusiness }) => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  const loadLogs = async () => {
    try {
      const data = await api.getAuditLogs(currentBusiness.id);
      setLogs(data);
    } catch (e) {
      console.error('Failed to load audit logs:', e);
    }
  };

  useEffect(() => {
    loadLogs();
  }, [currentBusiness.id]);

  const filteredLogs = logs.filter(
    (l) =>
      l.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.actionType.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-extrabold text-white tracking-tight">AI Security & Audit Trail</h1>
            <span className="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full bg-green-500/10 text-green-400 border border-green-500/20">
              Immutable Log
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Full transparent audit history of all voice entries, AI action confirmations, and ledger modifications
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs font-semibold text-green-400 bg-green-500/10 px-3.5 py-2 rounded-xl border border-green-500/20 shadow-lg">
          <ShieldCheck className="w-4 h-4" />
          <span>Zero Unconfirmed Writes Policy Active</span>
        </div>
      </div>

      {/* Logs Table Card */}
      <div className="rounded-2xl bg-[#161616] border border-white/5 p-6 space-y-4 shadow-xl">
        <div className="relative max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search audit trail by action or details..."
            className="w-full bg-[#111111] border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="divide-y divide-white/5">
          {filteredLogs.length > 0 ? (
            filteredLogs.map((log) => {
              const isVoice = log.source === 'AI_VOICE';
              const isConfirmed = log.status === 'CONFIRMED' || log.status === 'EXECUTED';
              return (
                <div key={log.id} className="py-4 flex items-start justify-between text-xs hover:bg-white/[0.02] px-3 rounded-xl transition">
                  <div className="flex items-start space-x-3">
                    <div className={`p-2 rounded-xl mt-0.5 ${
                      isVoice ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'bg-white/5 text-gray-300 border border-white/5'
                    }`}>
                      {isVoice ? <Sparkles className="w-4 h-4" /> : <User className="w-4 h-4" />}
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-white text-sm">{log.actionType}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                          isConfirmed ? 'bg-green-500/10 text-green-400 border-green-500/20' : 'bg-white/5 text-gray-400 border-white/5'
                        }`}>
                          {log.status}
                        </span>
                      </div>
                      <p className="text-gray-300 mt-1">{log.details}</p>
                      {log.sourceTranscript && (
                        <p className="text-[11px] text-gray-400 font-mono mt-1.5 bg-[#111111] px-3 py-1.5 rounded-lg border border-white/5 w-fit">
                          Source Audio: "{log.sourceTranscript}"
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="text-right flex-shrink-0 ml-4">
                    <span className="text-[10px] text-gray-500 block font-mono">
                      {new Date(log.timestamp).toLocaleString()}
                    </span>
                    <span className="text-[9px] uppercase px-2 py-0.5 rounded-full bg-white/5 text-gray-400 mt-1 inline-block border border-white/5 font-semibold">
                      {log.source}
                    </span>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="py-12 text-center text-gray-500 text-xs">
              No audit logs recorded yet.
            </div>
          )}
        </div>
      </div>

    </div>
  );
};
