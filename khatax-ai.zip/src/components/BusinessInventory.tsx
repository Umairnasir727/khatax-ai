import React, { useState, useEffect } from 'react';
import {
  Package,
  Plus,
  Search,
  Gem,
  Building2,
  Shirt,
  Pill,
  Filter,
  DollarSign,
  AlertTriangle,
  X,
  Sparkles,
  Layers,
  MapPin,
  CheckCircle2,
} from 'lucide-react';
import { Business, Product, Property } from '../types';
import { api } from '../services/api';

interface BusinessInventoryProps {
  currentBusiness: Business;
  onOpenVoiceModal: () => void;
}

export const BusinessInventory: React.FC<BusinessInventoryProps> = ({
  currentBusiness,
  onOpenVoiceModal,
}) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [properties, setProperties] = useState<Property[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('ALL');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form State for Jewellery / General Product
  const [itemName, setItemName] = useState('');
  const [itemCategory, setItemCategory] = useState('');
  const [unit, setUnit] = useState('Piece');
  const [stockQuantity, setStockQuantity] = useState('1');
  const [costPrice, setCostPrice] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  
  // Jewellery Specific
  const [goldWeightGrams, setGoldWeightGrams] = useState('');
  const [goldKarat, setGoldKarat] = useState('22K');
  const [makingCharges, setMakingCharges] = useState('');
  const [purityPercentage, setPurityPercentage] = useState('91.6');

  // Property Specific
  const [propertyTitle, setPropertyTitle] = useState('');
  const [propertyType, setPropertyType] = useState<'PLOT' | 'HOUSE' | 'COMMERCIAL' | 'FILE'>('PLOT');
  const [society, setSociety] = useState('');
  const [plotNumber, setPlotNumber] = useState('');
  const [sizeMarla, setSizeMarla] = useState('10');
  const [totalPrice, setTotalPrice] = useState('');

  const isJewellery = currentBusiness.category === 'jewellery_gold' || currentBusiness.category === 'silver';
  const isProperty = currentBusiness.category === 'property_dealer' || currentBusiness.category === 'real_estate';
  const isClothing = currentBusiness.category === 'clothing_garments';

  const goldRate24k = currentBusiness.rules.find((r) => r.key === 'gold_rate_24k')?.value || 248000;
  const tolaGram = currentBusiness.rules.find((r) => r.key === 'tola_in_grams')?.value || 11.664;

  const loadInventory = async () => {
    try {
      if (isProperty) {
        const propList = await api.getProperties(currentBusiness.id);
        setProperties(propList);
      } else {
        const prodList = await api.getProducts(currentBusiness.id);
        setProducts(prodList);
      }
    } catch (e) {
      console.error('Failed to load inventory:', e);
    }
  };

  useEffect(() => {
    loadInventory();
  }, [currentBusiness.id, isProperty]);

  const handleCreateItem = async (e: React.FormEvent) => {
    e.preventDefault();

    if (isProperty) {
      if (!propertyTitle.trim() || !totalPrice) return;
      await api.createProperty({
        businessId: currentBusiness.id,
        title: propertyTitle.trim(),
        type: propertyType,
        society: society.trim() || 'Central Society',
        plotNumber: plotNumber.trim(),
        sizeMarla: parseFloat(sizeMarla) || 5,
        totalPrice: parseFloat(totalPrice) || 0,
        status: 'AVAILABLE',
      });
    } else {
      if (!itemName.trim() || !sellingPrice) return;
      const customProps: Record<string, any> = {};
      if (isJewellery) {
        customProps.goldWeightGrams = parseFloat(goldWeightGrams) || 0;
        customProps.tola = (parseFloat(goldWeightGrams) / tolaGram).toFixed(3);
        customProps.karat = goldKarat;
        customProps.makingCharges = parseFloat(makingCharges) || 0;
      }

      await api.createProduct({
        businessId: currentBusiness.id,
        name: itemName.trim(),
        category: itemCategory.trim() || (isJewellery ? 'Gold Ornaments' : 'General'),
        unit: isJewellery ? 'Tola' : unit,
        stockQuantity: parseFloat(stockQuantity) || 1,
        costPrice: parseFloat(costPrice) || 0,
        sellingPrice: parseFloat(sellingPrice) || 0,
        customProperties: customProps,
      });
    }

    setIsAddModalOpen(false);
    resetForm();
    loadInventory();
  };

  const resetForm = () => {
    setItemName('');
    setSellingPrice('');
    setCostPrice('');
    setGoldWeightGrams('');
    setPropertyTitle('');
    setTotalPrice('');
    setPlotNumber('');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-extrabold text-white tracking-tight">
              {isJewellery
                ? 'Gold & Silver Vault Inventory'
                : isProperty
                ? 'Property Portfolio & Listings'
                : isClothing
                ? 'Garments & Apparel Inventory'
                : 'Products & Stock Inventory'}
            </h1>
            <span className="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full bg-white/5 text-gray-400 border border-white/10">
              {currentBusiness.profile.categoryName}
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            {isJewellery
              ? 'Tola & gram weights, 24K/22K karat specifications and live valuation'
              : isProperty
              ? 'Plots, houses, commercial units & files tracking'
              : 'SKUs, stock quantities, pricing and sizes'}
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>
            {isJewellery
              ? '+ Add Gold / Jewellery Item'
              : isProperty
              ? '+ Add Property Listing'
              : '+ Add New Product'}
          </span>
        </button>
      </div>

      {/* JEWELLERY VAULT VIEW */}
      {isJewellery && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-[#161616] border border-white/5">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Live 24K Gold Rate / Tola</span>
              <p className="text-2xl font-extrabold text-yellow-400 mt-2 font-mono">
                {currentBusiness.currency} {goldRate24k.toLocaleString()}
              </p>
              <span className="text-[11px] text-gray-500 mt-1 block">1 Tola = {tolaGram} Grams</span>
            </div>

            <div className="p-5 rounded-2xl bg-[#161616] border border-white/5">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Vault Gold Articles</span>
              <p className="text-2xl font-extrabold text-white mt-2 font-mono">{products.length} Items</p>
              <span className="text-[11px] text-gray-500 mt-1 block">Ornaments in catalog</span>
            </div>

            <div className="p-5 rounded-2xl bg-[#161616] border border-white/5">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Total Vault Valuation</span>
              <p className="text-2xl font-extrabold text-green-400 mt-2 font-mono">
                {currentBusiness.currency} {products.reduce((s, p) => s + p.sellingPrice * p.stockQuantity, 0).toLocaleString()}
              </p>
              <span className="text-[11px] text-gray-500 mt-1 block">Estimated retail value</span>
            </div>
          </div>

          {/* Jewellery Items Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {products.map((prod) => {
              const weightGrams = prod.customProperties?.goldWeightGrams || 0;
              const tolas = (weightGrams / tolaGram).toFixed(3);
              const karat = prod.customProperties?.karat || '22K';
              return (
                <div key={prod.id} className="p-5 rounded-2xl bg-[#161616] border border-white/5 shadow-xl space-y-4 hover:border-white/20 transition">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-xl bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center text-yellow-400 font-bold">
                        <Gem className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">{prod.name}</h4>
                        <span className="text-[11px] text-gray-400">{prod.category}</span>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded-full bg-yellow-500/10 text-yellow-400 font-bold text-[10px] border border-yellow-500/20">
                      {karat} Gold
                    </span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#111111] border border-white/5 grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-gray-400 block text-[11px]">Weight:</span>
                      <span className="font-bold text-white font-mono">{weightGrams}g ({tolas} Tola)</span>
                    </div>
                    <div>
                      <span className="text-gray-400 block text-[11px]">Stock Qty:</span>
                      <span className="font-bold text-green-400 font-mono">{prod.stockQuantity} Pcs</span>
                    </div>
                    {prod.customProperties?.makingCharges && (
                      <div className="col-span-2 pt-2 border-t border-white/5 flex justify-between">
                        <span className="text-gray-400">Making (Mazdoori):</span>
                        <span className="font-mono text-gray-200">Rs. {prod.customProperties.makingCharges.toLocaleString()}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-xs text-gray-400">Price / Tag:</span>
                    <span className="text-base font-extrabold text-yellow-400 font-mono">
                      {currentBusiness.currency} {prod.sellingPrice.toLocaleString()}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* PROPERTY PORTFOLIO VIEW */}
      {isProperty && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-[#161616] border border-white/5">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Available Properties</span>
              <p className="text-2xl font-extrabold text-blue-400 mt-2 font-mono">
                {properties.filter((p) => p.status === 'AVAILABLE').length} Units
              </p>
              <span className="text-[11px] text-gray-500 mt-1 block">Ready for sale</span>
            </div>

            <div className="p-5 rounded-2xl bg-[#161616] border border-white/5">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Booked / Token Bayana</span>
              <p className="text-2xl font-extrabold text-yellow-400 mt-2 font-mono">
                {properties.filter((p) => p.status === 'BOOKED').length} Units
              </p>
              <span className="text-[11px] text-gray-500 mt-1 block">Deal in progress</span>
            </div>

            <div className="p-5 rounded-2xl bg-[#161616] border border-white/5">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Total Portfolio Value</span>
              <p className="text-2xl font-extrabold text-white mt-2 font-mono">
                {currentBusiness.currency} {properties.reduce((s, p) => s + p.totalPrice, 0).toLocaleString()}
              </p>
              <span className="text-[11px] text-gray-500 mt-1 block">Aggregate property catalog</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {properties.map((prop) => (
              <div key={prop.id} className="p-5 rounded-2xl bg-[#161616] border border-white/5 shadow-xl space-y-4 hover:border-white/20 transition">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center text-blue-400 font-bold">
                      <Building2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">{prop.title}</h4>
                      <p className="text-xs text-gray-400">{prop.society}</p>
                    </div>
                  </div>
                  <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                    prop.status === 'AVAILABLE'
                      ? 'bg-green-500/10 text-green-400 border border-green-500/20'
                      : 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
                  }`}>
                    {prop.status}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-[#111111] border border-white/5 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Plot / Unit #:</span>
                    <span className="font-bold text-white font-mono">{prop.plotNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Size:</span>
                    <span className="font-bold text-blue-400 font-mono">{prop.sizeMarla} Marla ({prop.sizeMarla * 225} Sq.Ft)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Type:</span>
                    <span className="text-gray-200">{prop.type}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-xs text-gray-400">Demand / Price:</span>
                  <span className="text-base font-extrabold text-blue-400 font-mono">
                    {currentBusiness.currency} {prop.totalPrice.toLocaleString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* GENERAL / CLOTHING / PHARMACY VIEW */}
      {!isJewellery && !isProperty && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {products.map((prod) => (
              <div key={prod.id} className="p-5 rounded-2xl bg-[#161616] border border-white/5 shadow-xl space-y-4 hover:border-white/20 transition">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-blue-400 font-bold">
                      <Shirt className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">{prod.name}</h4>
                      <p className="text-xs text-gray-400">{prod.category}</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-white/5 text-gray-300 font-bold text-[10px]">
                    {prod.unit}
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-[#111111] border border-white/5 flex justify-between text-xs">
                  <div>
                    <span className="text-gray-400 block text-[11px]">Stock in Hand:</span>
                    <span className="font-bold text-green-400 font-mono">{prod.stockQuantity} {prod.unit}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-gray-400 block text-[11px]">Selling Price:</span>
                    <span className="font-extrabold text-white font-mono">
                      {currentBusiness.currency} {prod.sellingPrice.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ADD ITEM MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg rounded-2xl bg-[#161616] border border-white/10 shadow-2xl overflow-hidden p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-bold text-white text-base">
                {isJewellery ? 'Add Gold / Silver Item' : isProperty ? 'Add Property Listing' : 'Add Product'}
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-gray-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateItem} className="space-y-3.5 text-xs">
              {isProperty ? (
                <>
                  <div>
                    <label className="block text-gray-300 font-semibold mb-1">Property Title / Description *</label>
                    <input
                      type="text"
                      required
                      value={propertyTitle}
                      onChange={(e) => setPropertyTitle(e.target.value)}
                      placeholder="e.g. 10 Marla Corner Plot - Block B"
                      className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-gray-300 font-semibold mb-1">Society / Scheme</label>
                      <input
                        type="text"
                        value={society}
                        onChange={(e) => setSociety(e.target.value)}
                        placeholder="DHA Phase 6"
                        className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-300 font-semibold mb-1">Plot / Unit #</label>
                      <input
                        type="text"
                        value={plotNumber}
                        onChange={(e) => setPlotNumber(e.target.value)}
                        placeholder="Plot # 245"
                        className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-gray-300 font-semibold mb-1">Size in Marlas</label>
                      <input
                        type="number"
                        step="0.5"
                        value={sizeMarla}
                        onChange={(e) => setSizeMarla(e.target.value)}
                        className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-300 font-semibold mb-1">Total Demand ({currentBusiness.currency}) *</label>
                      <input
                        type="number"
                        required
                        value={totalPrice}
                        onChange={(e) => setTotalPrice(e.target.value)}
                        placeholder="18500000"
                        className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white font-mono font-bold focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <label className="block text-gray-300 font-semibold mb-1">Item Name *</label>
                    <input
                      type="text"
                      required
                      value={itemName}
                      onChange={(e) => setItemName(e.target.value)}
                      placeholder={isJewellery ? 'e.g. 22K Bridal Necklace Set' : 'e.g. Silk Kurti'}
                      className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  {isJewellery && (
                    <div className="p-3.5 rounded-xl bg-yellow-500/10 border border-yellow-500/20 grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] text-yellow-300 font-semibold mb-1">Weight (Grams) *</label>
                        <input
                          type="number"
                          step="0.001"
                          required
                          value={goldWeightGrams}
                          onChange={(e) => setGoldWeightGrams(e.target.value)}
                          placeholder="11.664"
                          className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-yellow-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-yellow-300 font-semibold mb-1">Karat</label>
                        <select
                          value={goldKarat}
                          onChange={(e) => setGoldKarat(e.target.value)}
                          className="w-full bg-[#111111] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-yellow-500"
                        >
                          <option value="24K">24K (Pure)</option>
                          <option value="22K">22K (Sarafa)</option>
                          <option value="21K">21K (Gulf)</option>
                          <option value="18K">18K (Diamond)</option>
                        </select>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-gray-300 font-semibold mb-1">Stock Quantity</label>
                      <input
                        type="number"
                        value={stockQuantity}
                        onChange={(e) => setStockQuantity(e.target.value)}
                        className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-300 font-semibold mb-1">Selling Price ({currentBusiness.currency}) *</label>
                      <input
                        type="number"
                        required
                        value={sellingPrice}
                        onChange={(e) => setSellingPrice(e.target.value)}
                        placeholder="450000"
                        className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white font-mono font-bold focus:outline-none"
                      />
                    </div>
                  </div>
                </>
              )}

              <div className="pt-3 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-gray-300 bg-white/5 hover:bg-white/10 border border-white/10"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-white font-bold bg-blue-600 hover:bg-blue-500"
                >
                  Save Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
