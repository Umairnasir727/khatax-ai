import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  X,
  Send,
  Loader2,
  Bot,
  User,
  HelpCircle,
  TrendingUp,
} from 'lucide-react';
import { Business, AIAction } from '../types';
import { api } from '../services/api';

interface AIChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentBusiness: Business;
  onActionProposed: (action: AIAction) => void;
}

interface ChatMessage {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  actionProposal?: AIAction;
  timestamp: string;
}

export const AIChatDrawer: React.FC<AIChatDrawerProps> = ({
  isOpen,
  onClose,
  currentBusiness,
  onActionProposed,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: `Assalam-o-Alaikum! Main ${currentBusiness.name} ka KhataX AI Business Brain hoon. Aap mujhse kisi bhi khata, customer, inquiry ya inventory ka hisaab pooch sakte hain.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isOpen, messages, isLoading]);

  if (!isOpen) return null;

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;

    const userQuery = inputText.trim();
    setInputText('');

    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: userQuery,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const res = await api.sendChatMessage(currentBusiness.id, userQuery);
      const aiMsg: ChatMessage = {
        id: `ai_${Date.now()}`,
        sender: 'ai',
        text: res.reply || 'Main samajh gaya.',
        actionProposal: res.actionProposal,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          sender: 'ai',
          text: 'Maazrat, request process nahi ho saki. Please try again.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const sampleQuestions = [
    'Total khata udhaar kitna baqi hai?',
    'Sab se zyada purchases kis customer ne ki hain?',
    'Ali ke khate ka current balance kya hai?',
    'Sarafa gold rate update kaise karun?',
  ];

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[480px] bg-[#111111] border-l border-white/10 shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
      
      {/* Drawer Header */}
      <div className="px-6 py-4 bg-[#161616] border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 font-bold shadow-md shadow-blue-500/10">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white tracking-tight">KhataX AI Business Brain</h3>
            <span className="text-[10px] text-blue-400 font-medium">
              Live context: {currentBusiness.name}
            </span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Messages Stream */}
      <div className="flex-1 p-5 overflow-y-auto space-y-3.5 bg-[#0a0a0a] text-xs">
        {messages.map((msg) => {
          const isAI = msg.sender === 'ai';
          return (
            <div
              key={msg.id}
              className={`flex items-start space-x-2.5 ${isAI ? '' : 'flex-row-reverse space-x-reverse'}`}
            >
              <div
                className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-[10px] flex-shrink-0 mt-0.5 ${
                  isAI ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'bg-white/5 text-gray-200 border border-white/10'
                }`}
              >
                {isAI ? <Sparkles className="w-3.5 h-3.5" /> : <User className="w-3.5 h-3.5" />}
              </div>

              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 leading-relaxed ${
                  isAI
                    ? 'bg-[#161616] text-gray-100 border border-white/5 rounded-tl-none shadow-md'
                    : 'bg-blue-600 text-white rounded-tr-none shadow-md'
                }`}
              >
                <p className="whitespace-pre-wrap">{msg.text}</p>

                {msg.actionProposal && (
                  <div className="mt-2.5 pt-2 border-t border-white/10 flex items-center justify-between">
                    <span className="text-[10px] text-yellow-300 font-semibold">
                      Proposed Ledger Action
                    </span>
                    <button
                      onClick={() => onActionProposed(msg.actionProposal!)}
                      className="px-2.5 py-1 rounded-lg bg-green-500/10 hover:bg-green-500/20 text-green-400 font-bold text-[10px] border border-green-500/20 transition"
                    >
                      Review & Confirm
                    </button>
                  </div>
                )}

                <span className={`text-[9px] mt-1.5 block font-mono ${isAI ? 'text-gray-500' : 'text-blue-200'}`}>
                  {msg.timestamp}
                </span>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center space-x-2 text-gray-400 p-3 rounded-2xl bg-[#161616] border border-white/5 w-fit">
            <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
            <span>Thinking with business records...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Questions */}
      <div className="px-5 py-2.5 bg-[#111111] border-t border-white/5 overflow-x-auto">
        <div className="flex items-center space-x-2 whitespace-nowrap">
          {sampleQuestions.map((q, i) => (
            <button
              key={i}
              onClick={() => {
                setInputText(q);
              }}
              className="text-[11px] px-3 py-1 rounded-full bg-[#161616] hover:bg-white/5 text-gray-300 hover:text-white border border-white/10 transition flex-shrink-0"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Input Box */}
      <div className="p-4 bg-[#161616] border-t border-white/10">
        <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
          <input
            type="text"
            id="ai-chat-input-field"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Ask anything about your khata, sales, or stock..."
            className="flex-1 bg-[#111111] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || isLoading}
            className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white font-bold transition shadow-lg shadow-blue-600/20"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>

    </div>
  );
};
