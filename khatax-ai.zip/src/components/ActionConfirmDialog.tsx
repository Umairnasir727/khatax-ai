import React from 'react';
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ArrowRight,
  ShieldAlert,
  Loader2,
} from 'lucide-react';
import { AIAction, Business } from '../types';
import confetti from 'canvas-confetti';
import { voiceService } from '../services/voice';

interface ActionConfirmDialogProps {
  action: AIAction | null;
  currentBusiness: Business;
  onConfirm: (action: AIAction) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}

export const ActionConfirmDialog: React.FC<ActionConfirmDialogProps> = ({
  action,
  currentBusiness,
  onConfirm,
  onCancel,
  isLoading = false,
}) => {
  if (!action) return null;

  const handleConfirm = async () => {
    try {
      await onConfirm(action);
      voiceService.playTone('confirm');
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });
    } catch (e) {
      voiceService.playTone('error');
    }
  };

  const getActionColor = () => {
    if (action.actionType.includes('payment')) return 'from-green-500/10 to-transparent border-green-500/30 text-green-400';
    if (action.actionType.includes('sale')) return 'from-blue-500/10 to-transparent border-blue-500/30 text-blue-400';
    if (action.actionType.includes('credit')) return 'from-yellow-500/10 to-transparent border-yellow-500/30 text-yellow-400';
    return 'from-purple-500/10 to-transparent border-purple-500/30 text-purple-400';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        id="action-confirmation-modal"
        className="w-full max-w-lg rounded-2xl bg-[#161616] border border-white/10 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="px-6 py-4 bg-[#111111] border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-yellow-500/10 border border-yellow-500/20 text-yellow-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                Action Confirmation Required
              </h3>
              <p className="text-xs text-gray-400">
                Source: {action.source === 'AI_VOICE' ? '🎙 Xara Voice Assistant' : '✨ AI Chat Brain'}
              </p>
            </div>
          </div>
          <button
            onClick={onCancel}
            disabled={isLoading}
            className="text-gray-400 hover:text-white transition"
          >
            <XCircle className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4">
          
          {/* Action Summary Banner */}
          <div className={`p-4 rounded-xl bg-gradient-to-r ${getActionColor()} border`}>
            <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400">
              Proposed Operation
            </p>
            <h4 className="text-base font-bold text-white mt-0.5">
              {action.title}
            </h4>
            <p className="text-xs text-gray-300 mt-1 leading-relaxed">
              {action.summary}
            </p>
          </div>

          {/* Balance / Financial Preview */}
          {(action.preview.previousBalance !== undefined || action.preview.newBalance !== undefined) && (
            <div className="p-4 rounded-xl bg-[#111111] border border-white/5 space-y-3">
              <span className="text-[11px] uppercase tracking-wider text-gray-400 font-semibold block">
                Digital Khata Impact
              </span>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 rounded-xl bg-[#161616] border border-white/5">
                  <span className="text-[11px] text-gray-400 block">Previous Balance</span>
                  <span className="text-sm font-bold text-gray-200">
                    {currentBusiness.currency} {(action.preview.previousBalance || 0).toLocaleString()}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-[#161616] border border-green-500/30">
                  <span className="text-[11px] text-green-400 font-medium block">New Balance</span>
                  <span className="text-sm font-bold text-green-400">
                    {currentBusiness.currency} {(action.preview.newBalance || 0).toLocaleString()}
                  </span>
                </div>
              </div>

              {action.preview.breakdownText && (
                <p className="text-xs text-gray-400 font-mono bg-[#161616] p-2.5 rounded-lg border border-white/5">
                  {action.preview.breakdownText}
                </p>
              )}
            </div>
          )}

          {/* Details list */}
          {action.preview.detailsList && action.preview.detailsList.length > 0 && (
            <div className="space-y-1.5">
              <span className="text-[11px] uppercase tracking-wider text-gray-400 font-semibold block">
                Structured Parameters
              </span>
              <div className="divide-y divide-white/5 rounded-xl bg-[#111111] border border-white/5 overflow-hidden text-xs">
                {action.preview.detailsList.map((d, idx) => (
                  <div key={idx} className="px-3.5 py-2 flex justify-between items-center">
                    <span className="text-gray-400 font-medium">{d.label}</span>
                    <span className="text-gray-100 font-semibold">{d.value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex items-center space-x-2 text-[11px] text-gray-400 bg-[#111111] p-2.5 rounded-xl border border-white/5">
            <AlertTriangle className="w-4 h-4 text-yellow-400 flex-shrink-0" />
            <span>
              This will update your permanent digital ledger and customer history securely.
            </span>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-[#111111] border-t border-white/5 flex items-center justify-end space-x-3">
          <button
            id="cancel-action-btn"
            type="button"
            onClick={onCancel}
            disabled={isLoading}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-gray-300 hover:text-white bg-[#161616] hover:bg-white/5 border border-white/10 transition"
          >
            Cancel
          </button>

          <button
            id="confirm-action-btn"
            type="button"
            onClick={handleConfirm}
            disabled={isLoading}
            className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-600/20 flex items-center space-x-2 transition active:scale-95 disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Executing Action...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Confirm & Save</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
