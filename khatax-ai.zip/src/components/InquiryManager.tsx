import React, { useState, useEffect } from 'react';
import {
  HelpCircle,
  Plus,
  Search,
  Calendar,
  DollarSign,
  Phone,
  User,
  CheckCircle2,
  Clock,
  Sparkles,
  X,
  MessageCircle,
} from 'lucide-react';
import { Business, Customer, Inquiry } from '../types';
import { api } from '../services/api';

interface InquiryManagerProps {
  currentBusiness: Business;
  onOpenVoiceModal: () => void;
}

export const InquiryManager: React.FC<InquiryManagerProps> = ({
  currentBusiness,
  onOpenVoiceModal,
}) => {
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form State
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [requirement, setRequirement] = useState('');
  const [category, setCategory] = useState(currentBusiness.profile.categoryName);
  const [budget, setBudget] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');
  const [notes, setNotes] = useState('');

  const loadInquiries = async () => {
    try {
      const [inqList, custList] = await Promise.all([
        api.getInquiries(currentBusiness.id),
        api.getCustomers(currentBusiness.id),
      ]);
      setInquiries(inqList);
      setCustomers(custList);
    } catch (e) {
      console.error('Failed to load inquiries:', e);
    }
  };

  useEffect(() => {
    loadInquiries();
  }, [currentBusiness.id]);

  const handleCreateInquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !requirement.trim()) return;

    await api.createInquiry({
      businessId: currentBusiness.id,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim() || '0300-0000000',
      requirement: requirement.trim(),
      category: category.trim() || currentBusiness.profile.categoryName,
      budget: parseFloat(budget) || undefined,
      followUpDate: followUpDate || new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
      status: 'NEW',
      notes: notes.trim(),
    });

    setIsAddModalOpen(false);
    resetForm();
    loadInquiries();
  };

  const handleUpdateStatus = async (inqId: string, newStatus: any) => {
    await api.updateInquiry(inqId, { status: newStatus });
    loadInquiries();
  };

  const resetForm = () => {
    setCustomerName('');
    setCustomerPhone('');
    setRequirement('');
    setBudget('');
    setFollowUpDate('');
    setNotes('');
  };

  const filteredInquiries = inquiries.filter((inq) => {
    const matchesSearch =
      inq.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inq.requirement.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (inq.notes && inq.notes.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesStatus = statusFilter === 'ALL' || inq.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Smart Customer Inquiries</h1>
            <span className="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
              AI Memory Engine
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Never lose a customer lead. AI remembers customer preferences, plots, sizes & bridal requirements.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={onOpenVoiceModal}
            className="flex items-center space-x-1.5 px-3.5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-blue-400 border border-white/10 text-xs font-bold transition"
          >
            <Sparkles className="w-4 h-4" />
            <span>Voice Recall (Xara)</span>
          </button>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>+ Log New Inquiry</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="p-4 rounded-2xl bg-[#161616] border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xl">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search inquiries (e.g. 10 Marla plot or 22K gold set)..."
            className="w-full bg-[#111111] border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center space-x-2 overflow-x-auto">
          {['ALL', 'NEW', 'FOLLOW_UP', 'CONVERTED', 'LOST'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex-shrink-0 ${
                statusFilter === st
                  ? 'bg-blue-600 text-white'
                  : 'bg-[#111111] text-gray-400 border border-white/5 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Inquiries Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredInquiries.length > 0 ? (
          filteredInquiries.map((inq) => (
            <div
              key={inq.id}
              className="p-5 rounded-2xl bg-[#161616] border border-white/5 shadow-xl space-y-4 hover:border-blue-500/40 transition flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-white text-sm">{inq.customerName}</h3>
                    <p className="text-xs text-gray-400 font-mono">{inq.customerPhone}</p>
                  </div>
                  <select
                    value={inq.status}
                    onChange={(e) => handleUpdateStatus(inq.id, e.target.value)}
                    className="text-[10px] font-bold uppercase rounded-lg px-2 py-1 bg-[#111111] border border-white/10 text-blue-400 focus:outline-none"
                  >
                    <option value="NEW">New Lead</option>
                    <option value="CONTACTED">Contacted</option>
                    <option value="FOLLOW_UP">Follow Up</option>
                    <option value="CONVERTED">Converted (Deal Done)</option>
                    <option value="LOST">Lost</option>
                  </select>
                </div>

                <div className="p-3.5 rounded-xl bg-[#111111] border border-white/5 space-y-2 text-xs">
                  <div>
                    <span className="text-[11px] text-blue-400 font-bold uppercase tracking-wider block">Requirement / Demand:</span>
                    <p className="text-white font-medium mt-0.5">{inq.requirement}</p>
                  </div>

                  {inq.budget && (
                    <div className="flex justify-between pt-1.5 border-t border-white/5 font-mono">
                      <span className="text-gray-400 font-sans">Budget:</span>
                      <span className="font-bold text-green-400">
                        {currentBusiness.currency} {inq.budget.toLocaleString()}
                      </span>
                    </div>
                  )}

                  {inq.followUpDate && (
                    <div className="flex justify-between font-mono">
                      <span className="text-gray-400 font-sans">Follow-up Date:</span>
                      <span className="font-semibold text-yellow-400">{inq.followUpDate}</span>
                    </div>
                  )}
                </div>

                {inq.notes && (
                  <p className="text-[11px] text-gray-400 italic bg-[#111111] p-2.5 rounded-xl border border-white/5">
                    "{inq.notes}"
                  </p>
                )}
              </div>

              <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs">
                <span className="text-[10px] text-gray-500 font-mono">
                  {new Date(inq.createdAt).toLocaleDateString()}
                </span>

                <a
                  href={`https://api.whatsapp.com/send?phone=${inq.customerPhone.replace(/[^0-9]/g, '')}&text=${encodeURIComponent(`Assalam-o-Alaikum ${inq.customerName} Bhai, yeh ${currentBusiness.name} se inquiry update hai regarding: ${inq.requirement}`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center space-x-1 text-green-400 hover:text-green-300 font-bold text-xs"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp Lead</span>
                </a>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-3 py-12 text-center text-gray-500 text-xs">
            No inquiries match. Try voice command: "Ahmed ne kya inquiry ki thi?"
          </div>
        )}
      </div>

      {/* ADD INQUIRY MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-2xl bg-[#161616] border border-white/10 shadow-2xl overflow-hidden p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-bold text-white text-base">Record Customer Inquiry</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-gray-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateInquiry} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-gray-300 font-semibold mb-1">Customer Name *</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Bilal Raza"
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1">Phone / WhatsApp</label>
                <input
                  type="text"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="0300-1234567"
                  className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1">Inquiry / Demand *</label>
                <textarea
                  rows={2}
                  required
                  value={requirement}
                  onChange={(e) => setRequirement(e.target.value)}
                  placeholder={
                    currentBusiness.category === 'jewellery_gold'
                      ? 'e.g. Looking for 3 Tola 22K bridal necklace set under 7 Lacs'
                      : 'e.g. Interested in 10 Marla plot in Block B, DHA Phase 6'
                  }
                  className="w-full bg-[#111111] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-gray-300 font-semibold mb-1">Target Budget ({currentBusiness.currency})</label>
                  <input
                    type="number"
                    value={budget}
                    onChange={(e) => setBudget(e.target.value)}
                    placeholder="750000"
                    className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-gray-300 font-semibold mb-1">Follow-up Date</label>
                  <input
                    type="date"
                    value={followUpDate}
                    onChange={(e) => setFollowUpDate(e.target.value)}
                    className="w-full bg-[#111111] border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-gray-300 bg-white/5 hover:bg-white/10 border border-white/10 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-white font-bold bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-600/20"
                >
                  Save Inquiry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
