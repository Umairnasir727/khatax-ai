import {
  Business,
  Customer,
  Supplier,
  Transaction,
  Product,
  Property,
  Inquiry,
  AIAction,
  AuditLog,
  BusinessRule,
} from '../types';

export const api = {
  // Businesses
  async getBusinesses(): Promise<Business[]> {
    const res = await fetch('/api/businesses');
    const json = await res.json();
    return json.data || [];
  },

  async getBusiness(id: string): Promise<Business> {
    const res = await fetch(`/api/businesses/${id}`);
    const json = await res.json();
    return json.data;
  },

  async analyzeBusinessDescription(payload: {
    description: string;
    category?: string;
    businessName?: string;
  }) {
    const res = await fetch('/api/businesses/analyze-description', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const json = await res.json();
    return json.data;
  },

  async createBusiness(data: Partial<Business>): Promise<Business> {
    const res = await fetch('/api/businesses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    return json.data;
  },

  async updateBusinessRules(businessId: string, rules: BusinessRule[]): Promise<Business> {
    const res = await fetch(`/api/businesses/${businessId}/rules`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rules }),
    });
    const json = await res.json();
    return json.data;
  },

  // Customers
  async getCustomers(businessId: string): Promise<Customer[]> {
    const res = await fetch(`/api/customers?businessId=${businessId}`);
    const json = await res.json();
    return json.data || [];
  },

  async createCustomer(data: Partial<Customer>): Promise<Customer> {
    const res = await fetch('/api/customers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    return json.data;
  },

  async updateCustomer(id: string, data: Partial<Customer>): Promise<Customer> {
    const res = await fetch(`/api/customers/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    return json.data;
  },

  async getCustomerIntelligence(customerId: string) {
    const res = await fetch(`/api/customers/${customerId}/intelligence`);
    const json = await res.json();
    return json.data;
  },

  // Suppliers
  async getSuppliers(businessId: string): Promise<Supplier[]> {
    const res = await fetch(`/api/suppliers?businessId=${businessId}`);
    const json = await res.json();
    return json.data || [];
  },

  async createSupplier(data: Partial<Supplier>): Promise<Supplier> {
    const res = await fetch('/api/suppliers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    return json.data;
  },

  // Products
  async getProducts(businessId: string): Promise<Product[]> {
    const res = await fetch(`/api/products?businessId=${businessId}`);
    const json = await res.json();
    return json.data || [];
  },

  async createProduct(data: Partial<Product>): Promise<Product> {
    const res = await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    return json.data;
  },

  async updateProduct(id: string, data: Partial<Product>): Promise<Product> {
    const res = await fetch(`/api/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    return json.data;
  },

  // Properties
  async getProperties(businessId: string): Promise<Property[]> {
    const res = await fetch(`/api/properties?businessId=${businessId}`);
    const json = await res.json();
    return json.data || [];
  },

  async createProperty(data: Partial<Property>): Promise<Property> {
    const res = await fetch('/api/properties', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    return json.data;
  },

  async updateProperty(id: string, data: Partial<Property>): Promise<Property> {
    const res = await fetch(`/api/properties/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    return json.data;
  },

  // Inquiries
  async getInquiries(businessId: string): Promise<Inquiry[]> {
    const res = await fetch(`/api/inquiries?businessId=${businessId}`);
    const json = await res.json();
    return json.data || [];
  },

  async createInquiry(data: Partial<Inquiry>): Promise<Inquiry> {
    const res = await fetch('/api/inquiries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    return json.data;
  },

  async updateInquiry(id: string, data: Partial<Inquiry>): Promise<Inquiry> {
    const res = await fetch(`/api/inquiries/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    return json.data;
  },

  // Transactions
  async getTransactions(businessId: string, customerId?: string): Promise<Transaction[]> {
    const query = new URLSearchParams({ businessId });
    if (customerId) query.append('customerId', customerId);
    const res = await fetch(`/api/transactions?${query.toString()}`);
    const json = await res.json();
    return json.data || [];
  },

  async createTransaction(data: Partial<Transaction>): Promise<Transaction> {
    const res = await fetch('/api/transactions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    return json.data;
  },

  // Dashboard summary
  async getDashboardSummary(businessId: string) {
    const res = await fetch(`/api/dashboard-summary?businessId=${businessId}`);
    const json = await res.json();
    return json.data;
  },

  // Audit Logs
  async getAuditLogs(businessId: string): Promise<AuditLog[]> {
    const res = await fetch(`/api/audit-logs?businessId=${businessId}`);
    const json = await res.json();
    return json.data || [];
  },

  // AI Chat
  async sendChatMessage(businessId: string, message: string) {
    const res = await fetch('/api/ai/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ businessId, message }),
    });
    const json = await res.json();
    return json.data;
  },

  // Voice Assistant Intent
  async processVoiceTranscript(businessId: string, transcript: string) {
    const res = await fetch('/api/ai/voice-intent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ businessId, transcript }),
    });
    const json = await res.json();
    return json.data;
  },

  // Execute Confirmed Action
  async executeAIAction(actionProposal: AIAction) {
    const res = await fetch('/api/ai/execute-action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ actionProposal }),
    });
    const json = await res.json();
    return json.data;
  },

  // Smart Calculator
  async calculateSmart(businessId: string, calculatorType: string, params: Record<string, any>) {
    const res = await fetch('/api/ai/smart-calculator', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ businessId, calculatorType, params }),
    });
    const json = await res.json();
    return json.data;
  },
};
