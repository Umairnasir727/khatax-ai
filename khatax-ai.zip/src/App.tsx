import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar, TabType } from './components/Sidebar';
import { DynamicDashboard } from './components/DynamicDashboard';
import { KhataLedger } from './components/KhataLedger';
import { CustomerIntelligence } from './components/CustomerIntelligence';
import { SupplierLedger } from './components/SupplierLedger';
import { BusinessInventory } from './components/BusinessInventory';
import { InquiryManager } from './components/InquiryManager';
import { SmartCalculator } from './components/SmartCalculator';
import { VoiceHubView } from './components/VoiceHubView';
import { ReportsView } from './components/ReportsView';
import { AuditLogsView } from './components/AuditLogsView';
import { SettingsView } from './components/SettingsView';
import { VoiceAssistantModal } from './components/VoiceAssistantModal';
import { ActionConfirmDialog } from './components/ActionConfirmDialog';
import { OnboardingModal } from './components/OnboardingModal';
import { AIChatDrawer } from './components/AIChatDrawer';
import { Business, AIAction } from './types';
import { api } from './services/api';
import { Loader2, Sparkles, Mic } from 'lucide-react';

export function App() {
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [currentBusiness, setCurrentBusiness] = useState<Business | null>(null);
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [isLoading, setIsLoading] = useState(true);

  // Modals and Drawers
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isAIChatOpen, setIsAIChatOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<AIAction | null>(null);
  const [isExecutingAction, setIsExecutingAction] = useState(false);

  // Load Businesses
  const loadBusinesses = async (selectBizId?: string) => {
    try {
      const list = await api.getBusinesses();
      setBusinesses(list);
      if (list.length > 0) {
        if (selectBizId) {
          const match = list.find((b) => b.id === selectBizId);
          setCurrentBusiness(match || list[0]);
        } else if (!currentBusiness) {
          setCurrentBusiness(list[0]);
        }
      }
    } catch (e) {
      console.error('Failed to load businesses:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadBusinesses();
  }, []);

  // Action Confirmation execution
  const handleConfirmAction = async (action: AIAction) => {
    setIsExecutingAction(true);
    try {
      await api.executeAIAction(action);
      setPendingAction(null);
      // Refresh current business records
      if (currentBusiness) {
        const updatedBiz = await api.getBusiness(currentBusiness.id);
        setCurrentBusiness(updatedBiz);
      }
    } catch (e) {
      console.error('Action execution failed:', e);
    } finally {
      setIsExecutingAction(false);
    }
  };

  const handleBusinessCreated = (newBiz: Business) => {
    setBusinesses((prev) => [...prev, newBiz]);
    setCurrentBusiness(newBiz);
    setActiveTab('dashboard');
  };

  if (isLoading || !currentBusiness) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex flex-col items-center justify-center text-gray-100 space-y-4">
        <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center font-bold text-white shadow-xl shadow-blue-600/20 text-xl tracking-tight uppercase animate-pulse">
          KX
        </div>
        <div className="flex items-center space-x-2 text-sm text-gray-400">
          <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
          <span>Loading KhataX AI Workspaces...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-100 flex flex-col antialiased selection:bg-blue-600 selection:text-white">
      
      {/* Top Navbar with Brand & Business Switcher */}
      <Navbar
        currentBusiness={currentBusiness}
        allBusinesses={businesses}
        onSelectBusiness={(biz) => {
          setCurrentBusiness(biz);
          setActiveTab('dashboard');
        }}
        onOpenNewBusinessModal={() => setIsOnboardingOpen(true)}
        onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
        onOpenAIChat={() => setIsAIChatOpen(true)}
        onOpenCalculator={() => setActiveTab('calculator')}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Adaptive Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={(tab) => setActiveTab(tab)}
          currentBusiness={currentBusiness}
        />

        {/* Dynamic Tab Workspace View */}
        <main className="flex-1 overflow-y-auto bg-[#0e0e0e]">
          {activeTab === 'dashboard' && (
            <DynamicDashboard
              currentBusiness={currentBusiness}
              onNavigateTab={(tab) => setActiveTab(tab)}
              onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
              onOpenActionDialog={(action) => setPendingAction(action)}
              onOpenNewTransaction={() => setActiveTab('khata')}
              onOpenNewCustomer={() => setActiveTab('customers')}
              onOpenNewInquiry={() => setActiveTab('inquiries')}
            />
          )}

          {activeTab === 'khata' && (
            <KhataLedger
              currentBusiness={currentBusiness}
              onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
              onOpenActionDialog={(action) => setPendingAction(action)}
            />
          )}

          {activeTab === 'customers' && (
            <CustomerIntelligence
              currentBusiness={currentBusiness}
              onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
            />
          )}

          {activeTab === 'suppliers' && (
            <SupplierLedger currentBusiness={currentBusiness} />
          )}

          {activeTab === 'inventory' && (
            <BusinessInventory
              currentBusiness={currentBusiness}
              onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
            />
          )}

          {activeTab === 'inquiries' && (
            <InquiryManager
              currentBusiness={currentBusiness}
              onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
            />
          )}

          {activeTab === 'calculator' && (
            <SmartCalculator
              currentBusiness={currentBusiness}
              onOpenNewTransaction={() => setActiveTab('khata')}
            />
          )}

          {activeTab === 'voice_hub' && (
            <VoiceHubView
              currentBusiness={currentBusiness}
              onActionProposed={(action) => setPendingAction(action)}
            />
          )}

          {activeTab === 'reports' && (
            <ReportsView currentBusiness={currentBusiness} />
          )}

          {activeTab === 'audit_logs' && (
            <AuditLogsView currentBusiness={currentBusiness} />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              currentBusiness={currentBusiness}
              onBusinessUpdated={(updated) => setCurrentBusiness(updated)}
            />
          )}
        </main>
      </div>

      {/* Floating Xara Voice Assistant Trigger (bottom-right) */}
      <button
        id="floating-xara-trigger"
        onClick={() => setIsVoiceModalOpen(true)}
        className="fixed bottom-6 right-6 z-40 px-4 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white shadow-2xl shadow-blue-500/25 hover:scale-105 active:scale-95 transition-all group flex items-center space-x-2.5 font-bold text-xs uppercase tracking-wider border border-white/10"
        title="Talk to Xara Voice Assistant"
      >
        <span className="relative flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500"></span>
        </span>
        <Mic className="w-4 h-4 group-hover:scale-110 transition-transform" />
        <span className="hidden sm:inline">Talk to Xara</span>
      </button>

      {/* MODALS & DRAWERS */}

      {/* 1. Interactive Xara Voice Modal */}
      <VoiceAssistantModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        currentBusiness={currentBusiness}
        onActionProposed={(action) => {
          setPendingAction(action);
        }}
      />

      {/* 2. Mandatory Action Confirmation Dialog */}
      <ActionConfirmDialog
        action={pendingAction}
        currentBusiness={currentBusiness}
        onConfirm={handleConfirmAction}
        onCancel={() => setPendingAction(null)}
        isLoading={isExecutingAction}
      />

      {/* 3. Multi-Business Onboarding Modal */}
      <OnboardingModal
        isOpen={isOnboardingOpen}
        onClose={() => setIsOnboardingOpen(false)}
        onBusinessCreated={handleBusinessCreated}
      />

      {/* 4. AI Business Brain Chat Drawer */}
      <AIChatDrawer
        isOpen={isAIChatOpen}
        onClose={() => setIsAIChatOpen(false)}
        currentBusiness={currentBusiness}
        onActionProposed={(action) => setPendingAction(action)}
      />

    </div>
  );
}

export default App;
